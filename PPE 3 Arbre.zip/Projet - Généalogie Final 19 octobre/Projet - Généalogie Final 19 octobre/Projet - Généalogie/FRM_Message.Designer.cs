﻿namespace GestionDErreurs
{
    partial class MessagePopup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MessagePopup));
            this.TMR_Popup = new System.Windows.Forms.Timer(this.components);
            this.PNL_Fenetre = new System.Windows.Forms.Panel();
            this.B_Valider = new System.Windows.Forms.Button();
            this.B_Annuler = new System.Windows.Forms.Button();
            this.PNL_Fenetre.SuspendLayout();
            this.SuspendLayout();
            // 
            // TMR_Popup
            // 
            this.TMR_Popup.Interval = 10000;
            this.TMR_Popup.Tick += new System.EventHandler(this.TMR_Popup_Tick);
            // 
            // PNL_Fenetre
            // 
            this.PNL_Fenetre.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.PNL_Fenetre.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PNL_Fenetre.BackgroundImage")));
            this.PNL_Fenetre.Controls.Add(this.B_Valider);
            this.PNL_Fenetre.Controls.Add(this.B_Annuler);
            this.PNL_Fenetre.Location = new System.Drawing.Point(12, 12);
            this.PNL_Fenetre.Name = "PNL_Fenetre";
            this.PNL_Fenetre.Size = new System.Drawing.Size(500, 493);
            this.PNL_Fenetre.TabIndex = 44;
            this.PNL_Fenetre.Paint += new System.Windows.Forms.PaintEventHandler(this.PNL_Fenetre_Paint);
            // 
            // B_Valider
            // 
            this.B_Valider.BackColor = System.Drawing.Color.Transparent;
            this.B_Valider.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("B_Valider.BackgroundImage")));
            this.B_Valider.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B_Valider.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.B_Valider.FlatAppearance.BorderSize = 0;
            this.B_Valider.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_Valider.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_Valider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Valider.Font = new System.Drawing.Font("Footlight MT Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Valider.ForeColor = System.Drawing.Color.Transparent;
            this.B_Valider.Location = new System.Drawing.Point(109, 396);
            this.B_Valider.Name = "B_Valider";
            this.B_Valider.Size = new System.Drawing.Size(100, 100);
            this.B_Valider.TabIndex = 9;
            this.B_Valider.UseVisualStyleBackColor = false;
            this.B_Valider.Visible = false;
            this.B_Valider.Click += new System.EventHandler(this.B_Valider_Click);
            this.B_Valider.Paint += new System.Windows.Forms.PaintEventHandler(this.B_Valider_Paint);
            // 
            // B_Annuler
            // 
            this.B_Annuler.BackColor = System.Drawing.Color.Transparent;
            this.B_Annuler.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("B_Annuler.BackgroundImage")));
            this.B_Annuler.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B_Annuler.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.B_Annuler.FlatAppearance.BorderSize = 0;
            this.B_Annuler.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_Annuler.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_Annuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Annuler.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Annuler.ForeColor = System.Drawing.Color.White;
            this.B_Annuler.Location = new System.Drawing.Point(3, 395);
            this.B_Annuler.Name = "B_Annuler";
            this.B_Annuler.Size = new System.Drawing.Size(100, 100);
            this.B_Annuler.TabIndex = 7;
            this.B_Annuler.UseVisualStyleBackColor = false;
            this.B_Annuler.Visible = false;
            this.B_Annuler.Click += new System.EventHandler(this.B_Annuler_Click);
            this.B_Annuler.Paint += new System.Windows.Forms.PaintEventHandler(this.B_Annuler_Paint);
            // 
            // MessagePopup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(550, 508);
            this.Controls.Add(this.PNL_Fenetre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "MessagePopup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MessagePopup";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MessagePopup_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Accueil_KeyDown);
            this.PNL_Fenetre.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer TMR_Popup;
        private System.Windows.Forms.Panel PNL_Fenetre;
        private System.Windows.Forms.Button B_Valider;
        private System.Windows.Forms.Button B_Annuler;
    }
}