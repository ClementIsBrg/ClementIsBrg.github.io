﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class FamilyInfo
    {
        public int FamilyId { get; set; }
    }
}
