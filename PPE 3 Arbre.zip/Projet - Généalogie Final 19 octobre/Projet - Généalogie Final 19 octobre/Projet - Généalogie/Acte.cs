﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class Acte
    {
        public int Id { get; set; }
        public DateTime DateActe { get; set; }
        public int IdTypeActe { get; set; }
        public string TypeActe { get; set; }
        public int IdVille { get; set; }

        public Acte(int id, DateTime dateActe, int idTypeActe, string typeActe, int idVille)
        {
            Id = id;
            DateActe = dateActe;
            IdTypeActe = idTypeActe;
            TypeActe = typeActe;
            IdVille = idVille;
        }

        public Acte() : this(0, DateTime.Parse("01/01/0001"), 0, " ", 0) { }
        public override string ToString()
        {
            return Id + " " + DateActe.ToString("yyyy/MM/dd") + " " + IdTypeActe + " " + IdVille;
        }


    }
}
