﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class Liste_Individu
    {
        public int IdPersonne { get; set; }
        public int IdActe { get; set; }
        public int IdTypeIndividu { get; set; }

        public Liste_Individu(int idPersonne, int idActe, int idTypeIndividu)
        {
            IdPersonne = idPersonne;
            IdActe = idActe;
            IdTypeIndividu = idTypeIndividu;
        }

        public Liste_Individu() : this(0, 0, 0) { }
        public override string ToString()
        {
            return IdPersonne + " " + IdActe + " " + IdTypeIndividu;
        }

    }
}
