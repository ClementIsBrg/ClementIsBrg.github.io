﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet___Généalogie
{
    [Serializable]
    public class Global
    {
        /*        public string chemin = Application.StartupPath;      // Path de l'application
                        public static int WEcran = Screen.PrimaryScreen.Bounds.Width; //largeur de l'ecran
                        public static int HEcran = Screen.PrimaryScreen.Bounds.Height;//hauteur de l'ecran*/

        public string Racine { get; set; }
        public string Chemin { get; set; }
        public string Repertoire { get; set; }
        public string Dossier { get; set; }
        public string Famille { get; set; }
        public string NomFichier { get; set; }

        public Global(string racine, string chemin, string repertoire, string dossier, string famille, string nomfichier)
        {
            Racine = racine;
            Chemin = chemin;
            Repertoire = repertoire;
            Dossier = dossier;
            Famille = famille;
            NomFichier = nomfichier;
        }
        //public Global() : this("C:\\", "Fichiers\\", "Personnes") { }
        public Global() : this(Application.StartupPath, "\\", "Resources\\", "nomdelabase\\", "Personnes\\", "individus") { }

        public override string ToString()
        {
            return Racine + Chemin + Repertoire + Dossier + Famille + NomFichier;
        }
    }
}
