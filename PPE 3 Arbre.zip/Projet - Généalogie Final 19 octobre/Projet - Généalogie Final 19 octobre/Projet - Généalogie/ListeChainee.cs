﻿using System;
using System.Windows.Forms;
using System.Windows;
using System.Collections;
using System.Collections.Generic;

namespace Projet___Généalogie
{
    [Serializable]
    class ListeChainee
    {
        public CelluleEntier2 tete;
        private CelluleEntier2 courant;

        public ListeChainee() { tete = null; courant = null; }

        public bool EstVide() { return (tete == null); }

        public void InitialiseListe(string e) { tete = new CelluleEntier2(e, null); }

        public void AjouterTete(string e) { CelluleEntier2 individu = new CelluleEntier2(e, tete); tete = individu; }

        public void SupprimerTete() { if (tete != null) tete = tete.AccesSuivant(); }

        public string RetourneElementTete() { return tete.AccesElement(); }

        public bool RechercheElementLC(CelluleEntier2 ptr, string e) //parcours profondeur préfixe avec recherche d'1 élément
        {
            bool flag = false;
            while ((ptr.AccesSuivant() != null) && (ptr.AccesElement() != e)) ptr = ptr.AccesSuivant();
            if (ptr.AccesElement() == e) flag = true;
            return flag;
        }


        /*public CelluleEntier2 RechercheElement(string e)
        {
            Queue q = new Queue();
            CelluleEntier2 ptr = tete;           
            q.Enqueue(ptr);
            while ((q.Count != 0) && (ptr.AccesElement() != e))
            {
                ptr = (CelluleEntier2)q.Dequeue();
                if (ptr != null)
                {
                    q.Enqueue(ptr.AccesSuivantPere());
                    q.Enqueue(ptr.AccesSuivantMere());
                }
            }
            return ptr;
        }*/

        /*public void ParcoursPrefixe(CelluleEntier2 tete) //parcours profondeur préfixe
        {
            CelluleEntier ptr = tete;
            if (ptr == null) return;
            MessageBox.Show("" + ptr.AccesElement());
            ParcoursPrefixe(ptr.AccesSuivant());
        }*/


        //public int GetCourant() { return courant.AccesElement(); }

        //public bool EnFinCourant() { return courant == null; }

        //public void RazCourant() { courant = tete; }

        //public void NextCourant() { /*courant = courant.AccesSuivant();*/ }

        /*public int Size()
        {
            int i = 0;
            CelluleEntier c = courant;
            RazCourant();
            while (EnFinCourant())
            {
                NextCourant();
                i++;
            }
            courant = c;
            return i;
        }*/
    }
}
