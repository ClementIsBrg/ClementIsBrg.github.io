﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class TypeIndividu
    {
        public int Id_TypeIndividu { get; set; }
        public string Nom_TypeIndividu { get; set; }


        public TypeIndividu(int id, string nom)
        {
            Id_TypeIndividu = id;
            Nom_TypeIndividu = nom;
        }

        public TypeIndividu() : this(0, "no_name") { }
        public override string ToString()
        {
            return Id_TypeIndividu + " " + Nom_TypeIndividu;
        }
    }
}
