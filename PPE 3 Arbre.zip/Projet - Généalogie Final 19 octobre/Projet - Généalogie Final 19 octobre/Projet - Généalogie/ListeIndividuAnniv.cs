﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class ListeIndividuAnniv
    {
        public int IdPersonne { get; set; }
        public string NomPersonne { get; set; }
        public string PrenomPersonne { get; set; }
        public DateTime DateActe { get; set; }

        public ListeIndividuAnniv(int idPersonne, string nomPersonne, string prenomPersonne, DateTime dateActe)
        {
            IdPersonne = idPersonne;
            NomPersonne = nomPersonne;
            PrenomPersonne = prenomPersonne;
            DateActe = dateActe;
        }

        public ListeIndividuAnniv() : this(0, "", "", DateTime.Parse("01/01/0001")) { }
        public override string ToString()
        {
            return IdPersonne + " " + NomPersonne + " " + PrenomPersonne + " " + DateActe.ToString("yyyy/MM/dd");
        }
    }
}
