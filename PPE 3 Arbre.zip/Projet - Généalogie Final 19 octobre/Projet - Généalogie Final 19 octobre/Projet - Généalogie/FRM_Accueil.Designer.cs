﻿namespace Projet___Généalogie
{
    partial class FRM_Accueil
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRM_Accueil));
            this.LB_individu = new System.Windows.Forms.ListBox();
            this.TXT_Nom = new System.Windows.Forms.TextBox();
            this.TXT_Prenom = new System.Windows.Forms.TextBox();
            this.LBL_Nom = new System.Windows.Forms.Label();
            this.LBL_Prenom = new System.Windows.Forms.Label();
            this.LB_Frere = new System.Windows.Forms.ListBox();
            this.LB_GrandsParents = new System.Windows.Forms.ListBox();
            this.LB_OnclesTantes = new System.Windows.Forms.ListBox();
            this.LBL_Enfants = new System.Windows.Forms.Label();
            this.LB_Enfants = new System.Windows.Forms.ListBox();
            this.GPX_Individu = new System.Windows.Forms.GroupBox();
            this.GPX_Famille = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LB_Parents = new System.Windows.Forms.ListBox();
            this.LBL_Mere = new System.Windows.Forms.Label();
            this.LB_PersonnePCS = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.LBL_Famille = new System.Windows.Forms.Label();
            this.LBL_LieuDc = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.B_Arbre = new System.Windows.Forms.Button();
            this.LBL_LieuNs = new System.Windows.Forms.Label();
            this.B_masquerpcs = new System.Windows.Forms.Button();
            this.LBL_DateDc = new System.Windows.Forms.Label();
            this.B_memepcs = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.B_Imprimer = new System.Windows.Forms.Button();
            this.LBL_DateN = new System.Windows.Forms.Label();
            this.TXT_LieuDc = new System.Windows.Forms.TextBox();
            this.TXT_LieuNs = new System.Windows.Forms.TextBox();
            this.TXT_DateDc = new System.Windows.Forms.TextBox();
            this.B_ChargerCollecViaSQL = new System.Windows.Forms.Button();
            this.TXT_DateNs = new System.Windows.Forms.TextBox();
            this.LBL_DateMariage = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LB_DateMariage = new System.Windows.Forms.ListBox();
            this.CB_Metier = new System.Windows.Forms.ComboBox();
            this.PB_individu = new System.Windows.Forms.PictureBox();
            this.TXT_Info = new System.Windows.Forms.TextBox();
            this.TXT_Id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.B_Ajouter = new System.Windows.Forms.Button();
            this.LBL_Profession = new System.Windows.Forms.Label();
            this.LB_LieuMariage = new System.Windows.Forms.ListBox();
            this.LB_Profession = new System.Windows.Forms.ListBox();
            this.TXT_IdMere = new System.Windows.Forms.TextBox();
            this.TXT_Test = new System.Windows.Forms.TextBox();
            this.TXT_IdPere = new System.Windows.Forms.TextBox();
            this.B_SauvergardeFichier = new System.Windows.Forms.Button();
            this.B_ChargerCollecViaFichier = new System.Windows.Forms.Button();
            this.B_AddBDD = new System.Windows.Forms.Button();
            this.B_DeleteBDD = new System.Windows.Forms.Button();
            this.B_ModifBDD = new System.Windows.Forms.Button();
            this.B_SauvegarderCollectionBDD = new System.Windows.Forms.Button();
            this.B_Supprimer = new System.Windows.Forms.Button();
            this.B_Modifier = new System.Windows.Forms.Button();
            this.B_MenuSelectionFamille = new System.Windows.Forms.Button();
            this.PNL_GesMariage = new System.Windows.Forms.Panel();
            this.B_FermerGesMariage = new System.Windows.Forms.Button();
            this.LBL_Marie2 = new System.Windows.Forms.Label();
            this.LBL_Marie1 = new System.Windows.Forms.Label();
            this.LB_Marie1 = new System.Windows.Forms.ListBox();
            this.LB_Marie2 = new System.Windows.Forms.ListBox();
            this.GPX_AnniversairesDuMois = new System.Windows.Forms.GroupBox();
            this.LB_Anniv = new System.Windows.Forms.ListBox();
            this.GPX_GesActes = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.LB_Temoin = new System.Windows.Forms.ListBox();
            this.B_GestionActes = new System.Windows.Forms.Button();
            this.LB_Acte = new System.Windows.Forms.ListBox();
            this.TXT_ActeDate = new System.Windows.Forms.TextBox();
            this.LB_Maries = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TXT_ActeLieu = new System.Windows.Forms.TextBox();
            this.TXT_ActeId = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.PNL_GestionActes = new System.Windows.Forms.Panel();
            this.B_GestionPNLActesFermer = new System.Windows.Forms.Button();
            this.PNL_GestLieux = new System.Windows.Forms.Panel();
            this.B_InsertLieu = new System.Windows.Forms.Button();
            this.TXT_IdGestLast = new System.Windows.Forms.TextBox();
            this.B_depvisible = new System.Windows.Forms.Button();
            this.TXT_AddCom = new System.Windows.Forms.TextBox();
            this.LBL_PaysGes = new System.Windows.Forms.Label();
            this.LBL_DepGes = new System.Windows.Forms.Label();
            this.LB_GesPays = new System.Windows.Forms.ListBox();
            this.LB_GesDep = new System.Windows.Forms.ListBox();
            this.B_Croix2 = new System.Windows.Forms.Button();
            this.B_InsertLieuxCommune = new System.Windows.Forms.Button();
            this.LBL_CommuneGes = new System.Windows.Forms.Label();
            this.TXT_AddPays = new System.Windows.Forms.TextBox();
            this.TXT_AddDep = new System.Windows.Forms.TextBox();
            this.LB_GesCom = new System.Windows.Forms.ListBox();
            this.GPX_ActesGestion = new System.Windows.Forms.GroupBox();
            this.LB_GestionIdPays = new System.Windows.Forms.ListBox();
            this.LB_GestionIdDep = new System.Windows.Forms.ListBox();
            this.LB_GestionId = new System.Windows.Forms.ListBox();
            this.TXT_GestionActeLieuID = new System.Windows.Forms.TextBox();
            this.CB_GestionActeTypeIndividu = new System.Windows.Forms.ComboBox();
            this.LB_GestionActeIndividu = new System.Windows.Forms.ListBox();
            this.B_GestionActesAjouter = new System.Windows.Forms.Button();
            this.DTP_Date = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.TXT_GestionActesLieu = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.LB_GestionActesChoix = new System.Windows.Forms.ListBox();
            this.GPX_Lieux = new System.Windows.Forms.GroupBox();
            this.B_GestionLieux = new System.Windows.Forms.Button();
            this.TXT_ShowPays = new System.Windows.Forms.Button();
            this.LBL_ShowPays = new System.Windows.Forms.Label();
            this.TXT_Departements = new System.Windows.Forms.Button();
            this.PNL_GestId = new System.Windows.Forms.Panel();
            this.TXT_DEPNom = new System.Windows.Forms.Button();
            this.TXT_NomDep = new System.Windows.Forms.Button();
            this.LBL_sl = new System.Windows.Forms.Label();
            this.LBL_Tdep = new System.Windows.Forms.Label();
            this.TXT_sl = new System.Windows.Forms.TextBox();
            this.LB_ListeLieux = new System.Windows.Forms.ListBox();
            this.B_ChargerLieux = new System.Windows.Forms.Button();
            this.TT_Ajouter = new System.Windows.Forms.ToolTip(this.components);
            this.TT_Supprimer = new System.Windows.Forms.ToolTip(this.components);
            this.TT_Modifier = new System.Windows.Forms.ToolTip(this.components);
            this.TT_ChargerCollecVIABDD = new System.Windows.Forms.ToolTip(this.components);
            this.TT_SauvCollecDansBDD = new System.Windows.Forms.ToolTip(this.components);
            this.TT_ChargerCollecViaFichier = new System.Windows.Forms.ToolTip(this.components);
            this.TT_SauvCollecDansFichier = new System.Windows.Forms.ToolTip(this.components);
            this.TT_VoirProfession = new System.Windows.Forms.ToolTip(this.components);
            this.MasquerProfession = new System.Windows.Forms.ToolTip(this.components);
            this.TT_AfficherArbre = new System.Windows.Forms.ToolTip(this.components);
            this.TT_Imprimer = new System.Windows.Forms.ToolTip(this.components);
            this.PNL_PhotoFamille = new System.Windows.Forms.Panel();
            this.LBL_imageInfo = new System.Windows.Forms.Label();
            this.LBL_ = new System.Windows.Forms.Label();
            this.PB_Famille = new System.Windows.Forms.PictureBox();
            this.TT8gestionlieu = new System.Windows.Forms.ToolTip(this.components);
            this.TT_lieu = new System.Windows.Forms.ToolTip(this.components);
            this.TT_Menu = new System.Windows.Forms.ToolTip(this.components);
            this.PNL_ImageActe = new System.Windows.Forms.Panel();
            this.PB_Acte = new System.Windows.Forms.PictureBox();
            this.GPX_Individu.SuspendLayout();
            this.GPX_Famille.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_individu)).BeginInit();
            this.PNL_GesMariage.SuspendLayout();
            this.GPX_AnniversairesDuMois.SuspendLayout();
            this.GPX_GesActes.SuspendLayout();
            this.PNL_GestionActes.SuspendLayout();
            this.PNL_GestLieux.SuspendLayout();
            this.GPX_ActesGestion.SuspendLayout();
            this.GPX_Lieux.SuspendLayout();
            this.PNL_GestId.SuspendLayout();
            this.PNL_PhotoFamille.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Famille)).BeginInit();
            this.PNL_ImageActe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Acte)).BeginInit();
            this.SuspendLayout();
            // 
            // LB_individu
            // 
            this.LB_individu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.LB_individu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_individu.FormattingEnabled = true;
            this.LB_individu.ItemHeight = 16;
            this.LB_individu.Location = new System.Drawing.Point(14, 110);
            this.LB_individu.Name = "LB_individu";
            this.LB_individu.Size = new System.Drawing.Size(363, 484);
            this.LB_individu.TabIndex = 0;
            this.LB_individu.SelectedIndexChanged += new System.EventHandler(this.LB_individu_SelectedIndexChanged);
            // 
            // TXT_Nom
            // 
            this.TXT_Nom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_Nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Nom.Location = new System.Drawing.Point(403, 113);
            this.TXT_Nom.Name = "TXT_Nom";
            this.TXT_Nom.Size = new System.Drawing.Size(160, 22);
            this.TXT_Nom.TabIndex = 1;
            // 
            // TXT_Prenom
            // 
            this.TXT_Prenom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_Prenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Prenom.Location = new System.Drawing.Point(403, 139);
            this.TXT_Prenom.Name = "TXT_Prenom";
            this.TXT_Prenom.Size = new System.Drawing.Size(160, 22);
            this.TXT_Prenom.TabIndex = 2;
            // 
            // LBL_Nom
            // 
            this.LBL_Nom.AutoSize = true;
            this.LBL_Nom.Font = new System.Drawing.Font("Cooper Black", 9.75F);
            this.LBL_Nom.Location = new System.Drawing.Point(569, 116);
            this.LBL_Nom.Name = "LBL_Nom";
            this.LBL_Nom.Size = new System.Drawing.Size(39, 15);
            this.LBL_Nom.TabIndex = 12;
            this.LBL_Nom.Text = "Nom";
            // 
            // LBL_Prenom
            // 
            this.LBL_Prenom.AutoSize = true;
            this.LBL_Prenom.Font = new System.Drawing.Font("Cooper Black", 9.75F);
            this.LBL_Prenom.Location = new System.Drawing.Point(569, 142);
            this.LBL_Prenom.Name = "LBL_Prenom";
            this.LBL_Prenom.Size = new System.Drawing.Size(60, 15);
            this.LBL_Prenom.TabIndex = 21;
            this.LBL_Prenom.Text = "Prénom";
            // 
            // LB_Frere
            // 
            this.LB_Frere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Frere.FormattingEnabled = true;
            this.LB_Frere.ItemHeight = 16;
            this.LB_Frere.Location = new System.Drawing.Point(190, 56);
            this.LB_Frere.Name = "LB_Frere";
            this.LB_Frere.Size = new System.Drawing.Size(157, 68);
            this.LB_Frere.TabIndex = 26;
            this.LB_Frere.SelectedIndexChanged += new System.EventHandler(this.LB_Frere_SelectedIndexChanged_1);
            // 
            // LB_GrandsParents
            // 
            this.LB_GrandsParents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_GrandsParents.FormattingEnabled = true;
            this.LB_GrandsParents.ItemHeight = 16;
            this.LB_GrandsParents.Location = new System.Drawing.Point(9, 101);
            this.LB_GrandsParents.Name = "LB_GrandsParents";
            this.LB_GrandsParents.Size = new System.Drawing.Size(157, 68);
            this.LB_GrandsParents.TabIndex = 28;
            this.LB_GrandsParents.SelectedIndexChanged += new System.EventHandler(this.LB_GrandsParents_SelectedIndexChanged);
            // 
            // LB_OnclesTantes
            // 
            this.LB_OnclesTantes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_OnclesTantes.FormattingEnabled = true;
            this.LB_OnclesTantes.ItemHeight = 16;
            this.LB_OnclesTantes.Location = new System.Drawing.Point(9, 189);
            this.LB_OnclesTantes.Name = "LB_OnclesTantes";
            this.LB_OnclesTantes.Size = new System.Drawing.Size(157, 52);
            this.LB_OnclesTantes.TabIndex = 30;
            this.LB_OnclesTantes.SelectedIndexChanged += new System.EventHandler(this.LB_OnclesTantes_SelectedIndexChanged);
            // 
            // LBL_Enfants
            // 
            this.LBL_Enfants.AutoSize = true;
            this.LBL_Enfants.Location = new System.Drawing.Point(189, 141);
            this.LBL_Enfants.Name = "LBL_Enfants";
            this.LBL_Enfants.Size = new System.Drawing.Size(51, 16);
            this.LBL_Enfants.TabIndex = 33;
            this.LBL_Enfants.Text = "Enfants";
            // 
            // LB_Enfants
            // 
            this.LB_Enfants.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Enfants.FormattingEnabled = true;
            this.LB_Enfants.ItemHeight = 16;
            this.LB_Enfants.Location = new System.Drawing.Point(190, 160);
            this.LB_Enfants.Name = "LB_Enfants";
            this.LB_Enfants.Size = new System.Drawing.Size(157, 68);
            this.LB_Enfants.TabIndex = 32;
            this.LB_Enfants.SelectedIndexChanged += new System.EventHandler(this.LB_Enfants_SelectedIndexChanged);
            // 
            // GPX_Individu
            // 
            this.GPX_Individu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.GPX_Individu.Controls.Add(this.GPX_Famille);
            this.GPX_Individu.Controls.Add(this.LB_PersonnePCS);
            this.GPX_Individu.Controls.Add(this.label11);
            this.GPX_Individu.Controls.Add(this.LBL_Famille);
            this.GPX_Individu.Controls.Add(this.LBL_LieuDc);
            this.GPX_Individu.Controls.Add(this.label10);
            this.GPX_Individu.Controls.Add(this.B_Arbre);
            this.GPX_Individu.Controls.Add(this.LB_individu);
            this.GPX_Individu.Controls.Add(this.LBL_LieuNs);
            this.GPX_Individu.Controls.Add(this.B_masquerpcs);
            this.GPX_Individu.Controls.Add(this.LBL_DateDc);
            this.GPX_Individu.Controls.Add(this.B_memepcs);
            this.GPX_Individu.Controls.Add(this.label12);
            this.GPX_Individu.Controls.Add(this.B_Imprimer);
            this.GPX_Individu.Controls.Add(this.LBL_DateN);
            this.GPX_Individu.Controls.Add(this.TXT_LieuDc);
            this.GPX_Individu.Controls.Add(this.TXT_LieuNs);
            this.GPX_Individu.Controls.Add(this.TXT_DateDc);
            this.GPX_Individu.Controls.Add(this.B_ChargerCollecViaSQL);
            this.GPX_Individu.Controls.Add(this.TXT_DateNs);
            this.GPX_Individu.Controls.Add(this.LBL_DateMariage);
            this.GPX_Individu.Controls.Add(this.label3);
            this.GPX_Individu.Controls.Add(this.LB_DateMariage);
            this.GPX_Individu.Controls.Add(this.CB_Metier);
            this.GPX_Individu.Controls.Add(this.PB_individu);
            this.GPX_Individu.Controls.Add(this.TXT_Info);
            this.GPX_Individu.Controls.Add(this.TXT_Id);
            this.GPX_Individu.Controls.Add(this.label1);
            this.GPX_Individu.Controls.Add(this.B_Ajouter);
            this.GPX_Individu.Controls.Add(this.LBL_Profession);
            this.GPX_Individu.Controls.Add(this.TXT_Nom);
            this.GPX_Individu.Controls.Add(this.TXT_Prenom);
            this.GPX_Individu.Controls.Add(this.LBL_Nom);
            this.GPX_Individu.Controls.Add(this.LBL_Prenom);
            this.GPX_Individu.Controls.Add(this.LB_LieuMariage);
            this.GPX_Individu.Controls.Add(this.LB_Profession);
            this.GPX_Individu.Controls.Add(this.TXT_IdMere);
            this.GPX_Individu.Controls.Add(this.TXT_Test);
            this.GPX_Individu.Controls.Add(this.TXT_IdPere);
            this.GPX_Individu.Controls.Add(this.B_SauvergardeFichier);
            this.GPX_Individu.Controls.Add(this.B_ChargerCollecViaFichier);
            this.GPX_Individu.Controls.Add(this.B_AddBDD);
            this.GPX_Individu.Controls.Add(this.B_DeleteBDD);
            this.GPX_Individu.Controls.Add(this.B_ModifBDD);
            this.GPX_Individu.Controls.Add(this.B_SauvegarderCollectionBDD);
            this.GPX_Individu.Controls.Add(this.B_Supprimer);
            this.GPX_Individu.Controls.Add(this.B_Modifier);
            this.GPX_Individu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPX_Individu.Location = new System.Drawing.Point(12, 12);
            this.GPX_Individu.Name = "GPX_Individu";
            this.GPX_Individu.Size = new System.Drawing.Size(806, 628);
            this.GPX_Individu.TabIndex = 38;
            this.GPX_Individu.TabStop = false;
            this.GPX_Individu.Enter += new System.EventHandler(this.GPX_Individu_Enter);
            // 
            // GPX_Famille
            // 
            this.GPX_Famille.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.GPX_Famille.Controls.Add(this.LBL_Enfants);
            this.GPX_Famille.Controls.Add(this.label9);
            this.GPX_Famille.Controls.Add(this.label6);
            this.GPX_Famille.Controls.Add(this.label2);
            this.GPX_Famille.Controls.Add(this.LB_Enfants);
            this.GPX_Famille.Controls.Add(this.LB_Frere);
            this.GPX_Famille.Controls.Add(this.LB_Parents);
            this.GPX_Famille.Controls.Add(this.LBL_Mere);
            this.GPX_Famille.Controls.Add(this.LB_GrandsParents);
            this.GPX_Famille.Controls.Add(this.LB_OnclesTantes);
            this.GPX_Famille.Location = new System.Drawing.Point(403, 353);
            this.GPX_Famille.Name = "GPX_Famille";
            this.GPX_Famille.Size = new System.Drawing.Size(368, 250);
            this.GPX_Famille.TabIndex = 84;
            this.GPX_Famille.TabStop = false;
            this.GPX_Famille.Text = "Famille";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(189, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 16);
            this.label9.TabIndex = 37;
            this.label9.Text = "Frères et soeurs";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 16);
            this.label6.TabIndex = 36;
            this.label6.Text = "Oncles et tantes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 35;
            this.label2.Text = "Grands-parents";
            // 
            // LB_Parents
            // 
            this.LB_Parents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Parents.FormattingEnabled = true;
            this.LB_Parents.ItemHeight = 16;
            this.LB_Parents.Location = new System.Drawing.Point(9, 34);
            this.LB_Parents.Name = "LB_Parents";
            this.LB_Parents.Size = new System.Drawing.Size(157, 36);
            this.LB_Parents.TabIndex = 34;
            this.LB_Parents.SelectedIndexChanged += new System.EventHandler(this.LB_Parents_SelectedIndexChanged);
            // 
            // LBL_Mere
            // 
            this.LBL_Mere.AutoSize = true;
            this.LBL_Mere.Location = new System.Drawing.Point(8, 18);
            this.LBL_Mere.Name = "LBL_Mere";
            this.LBL_Mere.Size = new System.Drawing.Size(53, 16);
            this.LBL_Mere.TabIndex = 25;
            this.LBL_Mere.Text = "Parents";
            // 
            // LB_PersonnePCS
            // 
            this.LB_PersonnePCS.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LB_PersonnePCS.FormattingEnabled = true;
            this.LB_PersonnePCS.ItemHeight = 16;
            this.LB_PersonnePCS.Location = new System.Drawing.Point(14, 110);
            this.LB_PersonnePCS.Name = "LB_PersonnePCS";
            this.LB_PersonnePCS.Size = new System.Drawing.Size(363, 484);
            this.LB_PersonnePCS.TabIndex = 30;
            this.LB_PersonnePCS.Visible = false;
            this.LB_PersonnePCS.SelectedIndexChanged += new System.EventHandler(this.LB_PersonnePCS_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(576, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(190, 20);
            this.label11.TabIndex = 88;
            this.label11.Text = "Fonctions secondaires";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // LBL_Famille
            // 
            this.LBL_Famille.AutoSize = true;
            this.LBL_Famille.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Famille.Location = new System.Drawing.Point(19, 84);
            this.LBL_Famille.Name = "LBL_Famille";
            this.LBL_Famille.Size = new System.Drawing.Size(0, 24);
            this.LBL_Famille.TabIndex = 82;
            // 
            // LBL_LieuDc
            // 
            this.LBL_LieuDc.AutoSize = true;
            this.LBL_LieuDc.Location = new System.Drawing.Point(569, 273);
            this.LBL_LieuDc.Name = "LBL_LieuDc";
            this.LBL_LieuDc.Size = new System.Drawing.Size(73, 16);
            this.LBL_LieuDc.TabIndex = 79;
            this.LBL_LieuDc.Text = "Lieu décès";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(408, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 20);
            this.label10.TabIndex = 87;
            this.label10.Text = "Gestion fichier";
            // 
            // B_Arbre
            // 
            this.B_Arbre.BackColor = System.Drawing.Color.Transparent;
            this.B_Arbre.FlatAppearance.BorderSize = 0;
            this.B_Arbre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Arbre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Arbre.Image = ((System.Drawing.Image)(resources.GetObject("B_Arbre.Image")));
            this.B_Arbre.Location = new System.Drawing.Point(653, 32);
            this.B_Arbre.Name = "B_Arbre";
            this.B_Arbre.Size = new System.Drawing.Size(48, 43);
            this.B_Arbre.TabIndex = 60;
            this.TT_AfficherArbre.SetToolTip(this.B_Arbre, "Afficher l\'arbre géanalogique de cette personne");
            this.B_Arbre.UseVisualStyleBackColor = false;
            this.B_Arbre.Click += new System.EventHandler(this.B_Arbre_Click);
            // 
            // LBL_LieuNs
            // 
            this.LBL_LieuNs.AutoSize = true;
            this.LBL_LieuNs.Location = new System.Drawing.Point(569, 247);
            this.LBL_LieuNs.Name = "LBL_LieuNs";
            this.LBL_LieuNs.Size = new System.Drawing.Size(97, 16);
            this.LBL_LieuNs.TabIndex = 78;
            this.LBL_LieuNs.Text = "Lieu naissance";
            // 
            // B_masquerpcs
            // 
            this.B_masquerpcs.FlatAppearance.BorderSize = 0;
            this.B_masquerpcs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_masquerpcs.Image = ((System.Drawing.Image)(resources.GetObject("B_masquerpcs.Image")));
            this.B_masquerpcs.Location = new System.Drawing.Point(697, 36);
            this.B_masquerpcs.Name = "B_masquerpcs";
            this.B_masquerpcs.Size = new System.Drawing.Size(59, 39);
            this.B_masquerpcs.TabIndex = 85;
            this.MasquerProfession.SetToolTip(this.B_masquerpcs, "Masquer");
            this.B_masquerpcs.UseVisualStyleBackColor = true;
            this.B_masquerpcs.Visible = false;
            this.B_masquerpcs.Click += new System.EventHandler(this.B_masquerpcs_Click);
            // 
            // LBL_DateDc
            // 
            this.LBL_DateDc.AutoSize = true;
            this.LBL_DateDc.Location = new System.Drawing.Point(569, 223);
            this.LBL_DateDc.Name = "LBL_DateDc";
            this.LBL_DateDc.Size = new System.Drawing.Size(77, 16);
            this.LBL_DateDc.TabIndex = 77;
            this.LBL_DateDc.Text = "Date décès";
            // 
            // B_memepcs
            // 
            this.B_memepcs.FlatAppearance.BorderSize = 0;
            this.B_memepcs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_memepcs.Image = ((System.Drawing.Image)(resources.GetObject("B_memepcs.Image")));
            this.B_memepcs.Location = new System.Drawing.Point(697, 36);
            this.B_memepcs.Name = "B_memepcs";
            this.B_memepcs.Size = new System.Drawing.Size(59, 39);
            this.B_memepcs.TabIndex = 61;
            this.TT_VoirProfession.SetToolTip(this.B_memepcs, "Afficher les personnes ayant la même profession");
            this.B_memepcs.UseVisualStyleBackColor = true;
            this.B_memepcs.Click += new System.EventHandler(this.B_memepcs_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(225, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 20);
            this.label12.TabIndex = 89;
            this.label12.Text = "Gestion BDD";
            // 
            // B_Imprimer
            // 
            this.B_Imprimer.BackColor = System.Drawing.Color.Transparent;
            this.B_Imprimer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.B_Imprimer.FlatAppearance.BorderSize = 0;
            this.B_Imprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Imprimer.Image = ((System.Drawing.Image)(resources.GetObject("B_Imprimer.Image")));
            this.B_Imprimer.Location = new System.Drawing.Point(597, 32);
            this.B_Imprimer.Name = "B_Imprimer";
            this.B_Imprimer.Size = new System.Drawing.Size(54, 44);
            this.B_Imprimer.TabIndex = 58;
            this.TT_Imprimer.SetToolTip(this.B_Imprimer, "Imprimer les informations de cet individu");
            this.B_Imprimer.UseVisualStyleBackColor = false;
            this.B_Imprimer.Click += new System.EventHandler(this.B_Imprimer_Click);
            // 
            // LBL_DateN
            // 
            this.LBL_DateN.AutoSize = true;
            this.LBL_DateN.Location = new System.Drawing.Point(569, 197);
            this.LBL_DateN.Name = "LBL_DateN";
            this.LBL_DateN.Size = new System.Drawing.Size(101, 16);
            this.LBL_DateN.TabIndex = 76;
            this.LBL_DateN.Text = "Date naissance";
            // 
            // TXT_LieuDc
            // 
            this.TXT_LieuDc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_LieuDc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_LieuDc.Location = new System.Drawing.Point(403, 270);
            this.TXT_LieuDc.Name = "TXT_LieuDc";
            this.TXT_LieuDc.Size = new System.Drawing.Size(160, 22);
            this.TXT_LieuDc.TabIndex = 75;
            // 
            // TXT_LieuNs
            // 
            this.TXT_LieuNs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_LieuNs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_LieuNs.Location = new System.Drawing.Point(403, 244);
            this.TXT_LieuNs.Name = "TXT_LieuNs";
            this.TXT_LieuNs.Size = new System.Drawing.Size(160, 22);
            this.TXT_LieuNs.TabIndex = 74;
            // 
            // TXT_DateDc
            // 
            this.TXT_DateDc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_DateDc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_DateDc.Location = new System.Drawing.Point(403, 220);
            this.TXT_DateDc.Name = "TXT_DateDc";
            this.TXT_DateDc.Size = new System.Drawing.Size(160, 22);
            this.TXT_DateDc.TabIndex = 73;
            // 
            // B_ChargerCollecViaSQL
            // 
            this.B_ChargerCollecViaSQL.BackColor = System.Drawing.Color.Transparent;
            this.B_ChargerCollecViaSQL.FlatAppearance.BorderSize = 0;
            this.B_ChargerCollecViaSQL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_ChargerCollecViaSQL.Image = ((System.Drawing.Image)(resources.GetObject("B_ChargerCollecViaSQL.Image")));
            this.B_ChargerCollecViaSQL.Location = new System.Drawing.Point(188, 26);
            this.B_ChargerCollecViaSQL.Name = "B_ChargerCollecViaSQL";
            this.B_ChargerCollecViaSQL.Size = new System.Drawing.Size(41, 45);
            this.B_ChargerCollecViaSQL.TabIndex = 38;
            this.TT_ChargerCollecVIABDD.SetToolTip(this.B_ChargerCollecViaSQL, "CHARGER COLLECTION VIA BDD");
            this.B_ChargerCollecViaSQL.UseVisualStyleBackColor = false;
            this.B_ChargerCollecViaSQL.Click += new System.EventHandler(this.B_ChargerCollecViaSQL_Click);
            // 
            // TXT_DateNs
            // 
            this.TXT_DateNs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_DateNs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_DateNs.Location = new System.Drawing.Point(403, 194);
            this.TXT_DateNs.Name = "TXT_DateNs";
            this.TXT_DateNs.Size = new System.Drawing.Size(160, 22);
            this.TXT_DateNs.TabIndex = 72;
            // 
            // LBL_DateMariage
            // 
            this.LBL_DateMariage.AutoSize = true;
            this.LBL_DateMariage.Location = new System.Drawing.Point(569, 315);
            this.LBL_DateMariage.Name = "LBL_DateMariage";
            this.LBL_DateMariage.Size = new System.Drawing.Size(88, 16);
            this.LBL_DateMariage.TabIndex = 70;
            this.LBL_DateMariage.Text = "Infos Mariage";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(22, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 20);
            this.label3.TabIndex = 86;
            this.label3.Text = "Gestion collection";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // LB_DateMariage
            // 
            this.LB_DateMariage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.LB_DateMariage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DateMariage.FormattingEnabled = true;
            this.LB_DateMariage.Location = new System.Drawing.Point(403, 298);
            this.LB_DateMariage.Name = "LB_DateMariage";
            this.LB_DateMariage.Size = new System.Drawing.Size(160, 43);
            this.LB_DateMariage.TabIndex = 68;
            // 
            // CB_Metier
            // 
            this.CB_Metier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.CB_Metier.FormattingEnabled = true;
            this.CB_Metier.Location = new System.Drawing.Point(403, 164);
            this.CB_Metier.Name = "CB_Metier";
            this.CB_Metier.Size = new System.Drawing.Size(160, 24);
            this.CB_Metier.TabIndex = 63;
            this.CB_Metier.SelectedIndexChanged += new System.EventHandler(this.CB_Metier_SelectedIndexChanged);
            // 
            // PB_individu
            // 
            this.PB_individu.Location = new System.Drawing.Point(671, 90);
            this.PB_individu.Name = "PB_individu";
            this.PB_individu.Size = new System.Drawing.Size(100, 100);
            this.PB_individu.TabIndex = 54;
            this.PB_individu.TabStop = false;
            this.PB_individu.Click += new System.EventHandler(this.PB_individu_Click);
            // 
            // TXT_Info
            // 
            this.TXT_Info.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_Info.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Info.Location = new System.Drawing.Point(671, 196);
            this.TXT_Info.Multiline = true;
            this.TXT_Info.Name = "TXT_Info";
            this.TXT_Info.ReadOnly = true;
            this.TXT_Info.Size = new System.Drawing.Size(100, 103);
            this.TXT_Info.TabIndex = 52;
            this.TXT_Info.Text = "Infos";
            this.TXT_Info.TextChanged += new System.EventHandler(this.TXT_Info_TextChanged);
            // 
            // TXT_Id
            // 
            this.TXT_Id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Id.Location = new System.Drawing.Point(403, 87);
            this.TXT_Id.Name = "TXT_Id";
            this.TXT_Id.Size = new System.Drawing.Size(160, 22);
            this.TXT_Id.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(569, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 15);
            this.label1.TabIndex = 48;
            this.label1.Text = "ID";
            // 
            // B_Ajouter
            // 
            this.B_Ajouter.BackColor = System.Drawing.Color.Transparent;
            this.B_Ajouter.FlatAppearance.BorderSize = 0;
            this.B_Ajouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Ajouter.Image = ((System.Drawing.Image)(resources.GetObject("B_Ajouter.Image")));
            this.B_Ajouter.Location = new System.Drawing.Point(43, 28);
            this.B_Ajouter.Name = "B_Ajouter";
            this.B_Ajouter.Size = new System.Drawing.Size(41, 49);
            this.B_Ajouter.TabIndex = 38;
            this.TT_Ajouter.SetToolTip(this.B_Ajouter, "AJOUTER UN INDIVIDU");
            this.B_Ajouter.UseVisualStyleBackColor = false;
            this.B_Ajouter.Click += new System.EventHandler(this.B_Ajouter_Click);
            // 
            // LBL_Profession
            // 
            this.LBL_Profession.AutoSize = true;
            this.LBL_Profession.Location = new System.Drawing.Point(569, 167);
            this.LBL_Profession.Name = "LBL_Profession";
            this.LBL_Profession.Size = new System.Drawing.Size(71, 16);
            this.LBL_Profession.TabIndex = 45;
            this.LBL_Profession.Text = "Profession";
            // 
            // LB_LieuMariage
            // 
            this.LB_LieuMariage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.LB_LieuMariage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_LieuMariage.FormattingEnabled = true;
            this.LB_LieuMariage.Location = new System.Drawing.Point(97, 257);
            this.LB_LieuMariage.Name = "LB_LieuMariage";
            this.LB_LieuMariage.Size = new System.Drawing.Size(160, 43);
            this.LB_LieuMariage.TabIndex = 69;
            // 
            // LB_Profession
            // 
            this.LB_Profession.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(255)))), ((int)(((byte)(232)))));
            this.LB_Profession.FormattingEnabled = true;
            this.LB_Profession.ItemHeight = 16;
            this.LB_Profession.Location = new System.Drawing.Point(22, 237);
            this.LB_Profession.Name = "LB_Profession";
            this.LB_Profession.Size = new System.Drawing.Size(162, 36);
            this.LB_Profession.TabIndex = 28;
            this.LB_Profession.Visible = false;
            this.LB_Profession.SelectedIndexChanged += new System.EventHandler(this.LB_P_Metier_SelectedIndexChanged);
            // 
            // TXT_IdMere
            // 
            this.TXT_IdMere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_IdMere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_IdMere.Location = new System.Drawing.Point(25, 183);
            this.TXT_IdMere.Name = "TXT_IdMere";
            this.TXT_IdMere.Size = new System.Drawing.Size(160, 22);
            this.TXT_IdMere.TabIndex = 46;
            this.TXT_IdMere.Visible = false;
            this.TXT_IdMere.TextChanged += new System.EventHandler(this.TXT_IdMere_TextChanged);
            // 
            // TXT_Test
            // 
            this.TXT_Test.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_Test.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Test.Location = new System.Drawing.Point(142, 190);
            this.TXT_Test.Name = "TXT_Test";
            this.TXT_Test.Size = new System.Drawing.Size(15, 20);
            this.TXT_Test.TabIndex = 54;
            this.TXT_Test.Visible = false;
            // 
            // TXT_IdPere
            // 
            this.TXT_IdPere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.TXT_IdPere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_IdPere.Location = new System.Drawing.Point(24, 183);
            this.TXT_IdPere.Name = "TXT_IdPere";
            this.TXT_IdPere.Size = new System.Drawing.Size(160, 22);
            this.TXT_IdPere.TabIndex = 45;
            this.TXT_IdPere.Visible = false;
            // 
            // B_SauvergardeFichier
            // 
            this.B_SauvergardeFichier.BackColor = System.Drawing.Color.Transparent;
            this.B_SauvergardeFichier.FlatAppearance.BorderSize = 0;
            this.B_SauvergardeFichier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_SauvergardeFichier.Image = ((System.Drawing.Image)(resources.GetObject("B_SauvergardeFichier.Image")));
            this.B_SauvergardeFichier.Location = new System.Drawing.Point(475, 25);
            this.B_SauvergardeFichier.Name = "B_SauvergardeFichier";
            this.B_SauvergardeFichier.Size = new System.Drawing.Size(49, 48);
            this.B_SauvergardeFichier.TabIndex = 42;
            this.TT_SauvCollecDansFichier.SetToolTip(this.B_SauvergardeFichier, "ENREGISTRER LES COLLECTIONS DANS LE FICHIER");
            this.B_SauvergardeFichier.UseVisualStyleBackColor = false;
            this.B_SauvergardeFichier.Click += new System.EventHandler(this.B_SauvergardeFichier_Click);
            // 
            // B_ChargerCollecViaFichier
            // 
            this.B_ChargerCollecViaFichier.BackColor = System.Drawing.Color.Transparent;
            this.B_ChargerCollecViaFichier.FlatAppearance.BorderSize = 0;
            this.B_ChargerCollecViaFichier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_ChargerCollecViaFichier.Image = ((System.Drawing.Image)(resources.GetObject("B_ChargerCollecViaFichier.Image")));
            this.B_ChargerCollecViaFichier.Location = new System.Drawing.Point(432, 28);
            this.B_ChargerCollecViaFichier.Name = "B_ChargerCollecViaFichier";
            this.B_ChargerCollecViaFichier.Size = new System.Drawing.Size(54, 41);
            this.B_ChargerCollecViaFichier.TabIndex = 39;
            this.TT_ChargerCollecViaFichier.SetToolTip(this.B_ChargerCollecViaFichier, "CHARGER LES COLLECTIONS VIA FICHIER");
            this.B_ChargerCollecViaFichier.UseVisualStyleBackColor = false;
            this.B_ChargerCollecViaFichier.Click += new System.EventHandler(this.B_ChargerCollecViaFichier_Click);
            // 
            // B_AddBDD
            // 
            this.B_AddBDD.BackColor = System.Drawing.Color.Transparent;
            this.B_AddBDD.FlatAppearance.BorderSize = 0;
            this.B_AddBDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_AddBDD.Image = ((System.Drawing.Image)(resources.GetObject("B_AddBDD.Image")));
            this.B_AddBDD.Location = new System.Drawing.Point(225, 22);
            this.B_AddBDD.Name = "B_AddBDD";
            this.B_AddBDD.Size = new System.Drawing.Size(44, 55);
            this.B_AddBDD.TabIndex = 90;
            this.TT_Ajouter.SetToolTip(this.B_AddBDD, "AJOUTER UN INDIVIDU");
            this.B_AddBDD.UseVisualStyleBackColor = false;
            this.B_AddBDD.Click += new System.EventHandler(this.B_AddBDD_Click);
            // 
            // B_DeleteBDD
            // 
            this.B_DeleteBDD.BackColor = System.Drawing.Color.Transparent;
            this.B_DeleteBDD.FlatAppearance.BorderSize = 0;
            this.B_DeleteBDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_DeleteBDD.Image = ((System.Drawing.Image)(resources.GetObject("B_DeleteBDD.Image")));
            this.B_DeleteBDD.Location = new System.Drawing.Point(258, 24);
            this.B_DeleteBDD.Name = "B_DeleteBDD";
            this.B_DeleteBDD.Size = new System.Drawing.Size(54, 50);
            this.B_DeleteBDD.TabIndex = 91;
            this.TT_Supprimer.SetToolTip(this.B_DeleteBDD, "SUPPRIMER L\'INDIVIDU");
            this.B_DeleteBDD.UseVisualStyleBackColor = false;
            this.B_DeleteBDD.Click += new System.EventHandler(this.B_DeleteBDD_Click);
            // 
            // B_ModifBDD
            // 
            this.B_ModifBDD.BackColor = System.Drawing.Color.Transparent;
            this.B_ModifBDD.FlatAppearance.BorderSize = 0;
            this.B_ModifBDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_ModifBDD.Image = ((System.Drawing.Image)(resources.GetObject("B_ModifBDD.Image")));
            this.B_ModifBDD.Location = new System.Drawing.Point(307, 24);
            this.B_ModifBDD.Name = "B_ModifBDD";
            this.B_ModifBDD.Size = new System.Drawing.Size(42, 45);
            this.B_ModifBDD.TabIndex = 92;
            this.TT_Modifier.SetToolTip(this.B_ModifBDD, "MODIFIER L\'INDIVIDU");
            this.B_ModifBDD.UseVisualStyleBackColor = false;
            this.B_ModifBDD.Click += new System.EventHandler(this.B_ModifBDD_Click);
            // 
            // B_SauvegarderCollectionBDD
            // 
            this.B_SauvegarderCollectionBDD.BackColor = System.Drawing.Color.Transparent;
            this.B_SauvegarderCollectionBDD.FlatAppearance.BorderSize = 0;
            this.B_SauvegarderCollectionBDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_SauvegarderCollectionBDD.Image = ((System.Drawing.Image)(resources.GetObject("B_SauvegarderCollectionBDD.Image")));
            this.B_SauvegarderCollectionBDD.Location = new System.Drawing.Point(346, 26);
            this.B_SauvegarderCollectionBDD.Name = "B_SauvegarderCollectionBDD";
            this.B_SauvegarderCollectionBDD.Size = new System.Drawing.Size(40, 45);
            this.B_SauvegarderCollectionBDD.TabIndex = 41;
            this.TT_SauvCollecDansBDD.SetToolTip(this.B_SauvegarderCollectionBDD, "SAUVEGARDER LES COLLECTION DANS LA BDD");
            this.B_SauvegarderCollectionBDD.UseVisualStyleBackColor = false;
            this.B_SauvegarderCollectionBDD.Click += new System.EventHandler(this.B_SauvergarderCollectionBDD_Click);
            // 
            // B_Supprimer
            // 
            this.B_Supprimer.BackColor = System.Drawing.Color.Transparent;
            this.B_Supprimer.FlatAppearance.BorderSize = 0;
            this.B_Supprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Supprimer.Image = ((System.Drawing.Image)(resources.GetObject("B_Supprimer.Image")));
            this.B_Supprimer.Location = new System.Drawing.Point(80, 27);
            this.B_Supprimer.Name = "B_Supprimer";
            this.B_Supprimer.Size = new System.Drawing.Size(41, 50);
            this.B_Supprimer.TabIndex = 39;
            this.TT_Supprimer.SetToolTip(this.B_Supprimer, "SUPPRIMER L\'INDIVIDU");
            this.B_Supprimer.UseVisualStyleBackColor = false;
            this.B_Supprimer.Click += new System.EventHandler(this.B_Supprimer_Click);
            // 
            // B_Modifier
            // 
            this.B_Modifier.BackColor = System.Drawing.Color.Transparent;
            this.B_Modifier.FlatAppearance.BorderSize = 0;
            this.B_Modifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Modifier.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.B_Modifier.Image = ((System.Drawing.Image)(resources.GetObject("B_Modifier.Image")));
            this.B_Modifier.Location = new System.Drawing.Point(116, 31);
            this.B_Modifier.Name = "B_Modifier";
            this.B_Modifier.Size = new System.Drawing.Size(49, 39);
            this.B_Modifier.TabIndex = 40;
            this.TT_Modifier.SetToolTip(this.B_Modifier, "MODIFIER L\'INDIVIDU");
            this.B_Modifier.UseVisualStyleBackColor = false;
            this.B_Modifier.Click += new System.EventHandler(this.B_Modifier_Click);
            // 
            // B_MenuSelectionFamille
            // 
            this.B_MenuSelectionFamille.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.B_MenuSelectionFamille.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_MenuSelectionFamille.Location = new System.Drawing.Point(1685, 12);
            this.B_MenuSelectionFamille.Name = "B_MenuSelectionFamille";
            this.B_MenuSelectionFamille.Size = new System.Drawing.Size(212, 62);
            this.B_MenuSelectionFamille.TabIndex = 56;
            this.B_MenuSelectionFamille.Text = "Retour Arbre Selection Famille";
            this.B_MenuSelectionFamille.UseVisualStyleBackColor = false;
            this.B_MenuSelectionFamille.Click += new System.EventHandler(this.B_MenuSelectionFamille_Click);
            // 
            // PNL_GesMariage
            // 
            this.PNL_GesMariage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.PNL_GesMariage.Controls.Add(this.B_FermerGesMariage);
            this.PNL_GesMariage.Controls.Add(this.LBL_Marie2);
            this.PNL_GesMariage.Controls.Add(this.LBL_Marie1);
            this.PNL_GesMariage.Controls.Add(this.LB_Marie1);
            this.PNL_GesMariage.Controls.Add(this.LB_Marie2);
            this.PNL_GesMariage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PNL_GesMariage.Location = new System.Drawing.Point(6, 4);
            this.PNL_GesMariage.Name = "PNL_GesMariage";
            this.PNL_GesMariage.Size = new System.Drawing.Size(420, 114);
            this.PNL_GesMariage.TabIndex = 55;
            this.PNL_GesMariage.Visible = false;
            // 
            // B_FermerGesMariage
            // 
            this.B_FermerGesMariage.FlatAppearance.BorderSize = 0;
            this.B_FermerGesMariage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_FermerGesMariage.ForeColor = System.Drawing.Color.Red;
            this.B_FermerGesMariage.Image = ((System.Drawing.Image)(resources.GetObject("B_FermerGesMariage.Image")));
            this.B_FermerGesMariage.Location = new System.Drawing.Point(387, 3);
            this.B_FermerGesMariage.Name = "B_FermerGesMariage";
            this.B_FermerGesMariage.Size = new System.Drawing.Size(30, 30);
            this.B_FermerGesMariage.TabIndex = 61;
            this.B_FermerGesMariage.UseVisualStyleBackColor = true;
            this.B_FermerGesMariage.Click += new System.EventHandler(this.B_FermerGesMariage_Click);
            // 
            // LBL_Marie2
            // 
            this.LBL_Marie2.AutoSize = true;
            this.LBL_Marie2.Location = new System.Drawing.Point(205, 15);
            this.LBL_Marie2.Name = "LBL_Marie2";
            this.LBL_Marie2.Size = new System.Drawing.Size(49, 16);
            this.LBL_Marie2.TabIndex = 58;
            this.LBL_Marie2.Text = "Mariée";
            // 
            // LBL_Marie1
            // 
            this.LBL_Marie1.AutoSize = true;
            this.LBL_Marie1.Location = new System.Drawing.Point(17, 15);
            this.LBL_Marie1.Name = "LBL_Marie1";
            this.LBL_Marie1.Size = new System.Drawing.Size(41, 16);
            this.LBL_Marie1.TabIndex = 57;
            this.LBL_Marie1.Text = "Marié";
            this.LBL_Marie1.Click += new System.EventHandler(this.LBL_Marie1_Click);
            // 
            // LB_Marie1
            // 
            this.LB_Marie1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Marie1.FormattingEnabled = true;
            this.LB_Marie1.ItemHeight = 16;
            this.LB_Marie1.Location = new System.Drawing.Point(14, 33);
            this.LB_Marie1.Name = "LB_Marie1";
            this.LB_Marie1.Size = new System.Drawing.Size(185, 68);
            this.LB_Marie1.TabIndex = 56;
            this.LB_Marie1.SelectedIndexChanged += new System.EventHandler(this.LB_Marie1_SelectedIndexChanged);
            // 
            // LB_Marie2
            // 
            this.LB_Marie2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Marie2.FormattingEnabled = true;
            this.LB_Marie2.ItemHeight = 16;
            this.LB_Marie2.Location = new System.Drawing.Point(206, 33);
            this.LB_Marie2.Name = "LB_Marie2";
            this.LB_Marie2.Size = new System.Drawing.Size(185, 68);
            this.LB_Marie2.TabIndex = 55;
            this.LB_Marie2.SelectedIndexChanged += new System.EventHandler(this.LB_Marie2_SelectedIndexChanged);
            // 
            // GPX_AnniversairesDuMois
            // 
            this.GPX_AnniversairesDuMois.BackColor = System.Drawing.Color.PapayaWhip;
            this.GPX_AnniversairesDuMois.Controls.Add(this.LB_Anniv);
            this.GPX_AnniversairesDuMois.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPX_AnniversairesDuMois.Location = new System.Drawing.Point(12, 646);
            this.GPX_AnniversairesDuMois.Name = "GPX_AnniversairesDuMois";
            this.GPX_AnniversairesDuMois.Size = new System.Drawing.Size(404, 302);
            this.GPX_AnniversairesDuMois.TabIndex = 43;
            this.GPX_AnniversairesDuMois.TabStop = false;
            this.GPX_AnniversairesDuMois.Text = "Anniversaires du mois";
            // 
            // LB_Anniv
            // 
            this.LB_Anniv.BackColor = System.Drawing.Color.PapayaWhip;
            this.LB_Anniv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.LB_Anniv.FormattingEnabled = true;
            this.LB_Anniv.Location = new System.Drawing.Point(6, 23);
            this.LB_Anniv.Name = "LB_Anniv";
            this.LB_Anniv.Size = new System.Drawing.Size(391, 286);
            this.LB_Anniv.TabIndex = 33;
            // 
            // GPX_GesActes
            // 
            this.GPX_GesActes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.GPX_GesActes.Controls.Add(this.label13);
            this.GPX_GesActes.Controls.Add(this.LB_Temoin);
            this.GPX_GesActes.Controls.Add(this.B_GestionActes);
            this.GPX_GesActes.Controls.Add(this.LB_Acte);
            this.GPX_GesActes.Controls.Add(this.TXT_ActeDate);
            this.GPX_GesActes.Controls.Add(this.LB_Maries);
            this.GPX_GesActes.Controls.Add(this.label5);
            this.GPX_GesActes.Controls.Add(this.label4);
            this.GPX_GesActes.Controls.Add(this.TXT_ActeLieu);
            this.GPX_GesActes.Controls.Add(this.TXT_ActeId);
            this.GPX_GesActes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPX_GesActes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GPX_GesActes.Location = new System.Drawing.Point(422, 646);
            this.GPX_GesActes.Name = "GPX_GesActes";
            this.GPX_GesActes.Size = new System.Drawing.Size(285, 302);
            this.GPX_GesActes.TabIndex = 57;
            this.GPX_GesActes.TabStop = false;
            this.GPX_GesActes.Text = "Evenements";
            this.GPX_GesActes.Enter += new System.EventHandler(this.GPX_GesActes_Enter);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(71, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 20);
            this.label13.TabIndex = 88;
            // 
            // LB_Temoin
            // 
            this.LB_Temoin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Temoin.FormattingEnabled = true;
            this.LB_Temoin.ItemHeight = 16;
            this.LB_Temoin.Location = new System.Drawing.Point(20, 116);
            this.LB_Temoin.Name = "LB_Temoin";
            this.LB_Temoin.Size = new System.Drawing.Size(160, 52);
            this.LB_Temoin.TabIndex = 54;
            // 
            // B_GestionActes
            // 
            this.B_GestionActes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.B_GestionActes.FlatAppearance.BorderSize = 0;
            this.B_GestionActes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_GestionActes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_GestionActes.Image = ((System.Drawing.Image)(resources.GetObject("B_GestionActes.Image")));
            this.B_GestionActes.Location = new System.Drawing.Point(183, 61);
            this.B_GestionActes.Name = "B_GestionActes";
            this.B_GestionActes.Size = new System.Drawing.Size(102, 105);
            this.B_GestionActes.TabIndex = 51;
            this.TT_Menu.SetToolTip(this.B_GestionActes, "Menu gestion évènements");
            this.B_GestionActes.UseVisualStyleBackColor = false;
            this.B_GestionActes.Click += new System.EventHandler(this.B_AjouterActe_Click);
            // 
            // LB_Acte
            // 
            this.LB_Acte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Acte.FormattingEnabled = true;
            this.LB_Acte.ItemHeight = 16;
            this.LB_Acte.Location = new System.Drawing.Point(20, 42);
            this.LB_Acte.Name = "LB_Acte";
            this.LB_Acte.Size = new System.Drawing.Size(160, 68);
            this.LB_Acte.TabIndex = 28;
            this.LB_Acte.SelectedIndexChanged += new System.EventHandler(this.LB_Acte_SelectedIndexChanged);
            // 
            // TXT_ActeDate
            // 
            this.TXT_ActeDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_ActeDate.Location = new System.Drawing.Point(20, 174);
            this.TXT_ActeDate.Name = "TXT_ActeDate";
            this.TXT_ActeDate.Size = new System.Drawing.Size(160, 22);
            this.TXT_ActeDate.TabIndex = 52;
            // 
            // LB_Maries
            // 
            this.LB_Maries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_Maries.FormattingEnabled = true;
            this.LB_Maries.ItemHeight = 16;
            this.LB_Maries.Location = new System.Drawing.Point(20, 226);
            this.LB_Maries.Name = "LB_Maries";
            this.LB_Maries.Size = new System.Drawing.Size(216, 36);
            this.LB_Maries.TabIndex = 30;
            this.LB_Maries.Click += new System.EventHandler(this.LB_Maries_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 16);
            this.label5.TabIndex = 51;
            this.label5.Text = "Lieu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(186, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 53;
            this.label4.Text = "Date";
            // 
            // TXT_ActeLieu
            // 
            this.TXT_ActeLieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_ActeLieu.Location = new System.Drawing.Point(20, 200);
            this.TXT_ActeLieu.Name = "TXT_ActeLieu";
            this.TXT_ActeLieu.Size = new System.Drawing.Size(160, 22);
            this.TXT_ActeLieu.TabIndex = 49;
            // 
            // TXT_ActeId
            // 
            this.TXT_ActeId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_ActeId.Location = new System.Drawing.Point(29, 69);
            this.TXT_ActeId.Name = "TXT_ActeId";
            this.TXT_ActeId.Size = new System.Drawing.Size(29, 22);
            this.TXT_ActeId.TabIndex = 90;
            this.TXT_ActeId.Visible = false;
            // 
            // PNL_GestionActes
            // 
            this.PNL_GestionActes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.PNL_GestionActes.Controls.Add(this.PNL_GesMariage);
            this.PNL_GestionActes.Controls.Add(this.B_GestionPNLActesFermer);
            this.PNL_GestionActes.Controls.Add(this.PNL_GestLieux);
            this.PNL_GestionActes.Controls.Add(this.GPX_ActesGestion);
            this.PNL_GestionActes.Controls.Add(this.GPX_Lieux);
            this.PNL_GestionActes.Location = new System.Drawing.Point(12, 646);
            this.PNL_GestionActes.Name = "PNL_GestionActes";
            this.PNL_GestionActes.Size = new System.Drawing.Size(806, 302);
            this.PNL_GestionActes.TabIndex = 53;
            this.PNL_GestionActes.Visible = false;
            // 
            // B_GestionPNLActesFermer
            // 
            this.B_GestionPNLActesFermer.FlatAppearance.BorderSize = 0;
            this.B_GestionPNLActesFermer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_GestionPNLActesFermer.ForeColor = System.Drawing.Color.Red;
            this.B_GestionPNLActesFermer.Image = ((System.Drawing.Image)(resources.GetObject("B_GestionPNLActesFermer.Image")));
            this.B_GestionPNLActesFermer.Location = new System.Drawing.Point(773, 3);
            this.B_GestionPNLActesFermer.Name = "B_GestionPNLActesFermer";
            this.B_GestionPNLActesFermer.Size = new System.Drawing.Size(30, 28);
            this.B_GestionPNLActesFermer.TabIndex = 54;
            this.B_GestionPNLActesFermer.UseVisualStyleBackColor = true;
            this.B_GestionPNLActesFermer.Click += new System.EventHandler(this.B_GestionPNLActesFermer_Click);
            // 
            // PNL_GestLieux
            // 
            this.PNL_GestLieux.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.PNL_GestLieux.Controls.Add(this.B_InsertLieu);
            this.PNL_GestLieux.Controls.Add(this.TXT_IdGestLast);
            this.PNL_GestLieux.Controls.Add(this.B_depvisible);
            this.PNL_GestLieux.Controls.Add(this.TXT_AddCom);
            this.PNL_GestLieux.Controls.Add(this.LBL_PaysGes);
            this.PNL_GestLieux.Controls.Add(this.LBL_DepGes);
            this.PNL_GestLieux.Controls.Add(this.LB_GesPays);
            this.PNL_GestLieux.Controls.Add(this.LB_GesDep);
            this.PNL_GestLieux.Controls.Add(this.B_Croix2);
            this.PNL_GestLieux.Controls.Add(this.B_InsertLieuxCommune);
            this.PNL_GestLieux.Controls.Add(this.LBL_CommuneGes);
            this.PNL_GestLieux.Controls.Add(this.TXT_AddPays);
            this.PNL_GestLieux.Controls.Add(this.TXT_AddDep);
            this.PNL_GestLieux.Controls.Add(this.LB_GesCom);
            this.PNL_GestLieux.ForeColor = System.Drawing.Color.Black;
            this.PNL_GestLieux.Location = new System.Drawing.Point(3, 7);
            this.PNL_GestLieux.Name = "PNL_GestLieux";
            this.PNL_GestLieux.Size = new System.Drawing.Size(447, 248);
            this.PNL_GestLieux.TabIndex = 59;
            this.PNL_GestLieux.Visible = false;
            // 
            // B_InsertLieu
            // 
            this.B_InsertLieu.FlatAppearance.BorderSize = 0;
            this.B_InsertLieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_InsertLieu.Image = ((System.Drawing.Image)(resources.GetObject("B_InsertLieu.Image")));
            this.B_InsertLieu.Location = new System.Drawing.Point(151, 123);
            this.B_InsertLieu.Name = "B_InsertLieu";
            this.B_InsertLieu.Size = new System.Drawing.Size(54, 48);
            this.B_InsertLieu.TabIndex = 75;
            this.TT_SauvCollecDansBDD.SetToolTip(this.B_InsertLieu, "Insert BDD");
            this.B_InsertLieu.UseVisualStyleBackColor = true;
            this.B_InsertLieu.Click += new System.EventHandler(this.B_InsertLieu_Click);
            // 
            // TXT_IdGestLast
            // 
            this.TXT_IdGestLast.Location = new System.Drawing.Point(92, 177);
            this.TXT_IdGestLast.Name = "TXT_IdGestLast";
            this.TXT_IdGestLast.Size = new System.Drawing.Size(100, 20);
            this.TXT_IdGestLast.TabIndex = 74;
            this.TXT_IdGestLast.UseWaitCursor = true;
            // 
            // B_depvisible
            // 
            this.B_depvisible.Location = new System.Drawing.Point(194, 67);
            this.B_depvisible.Name = "B_depvisible";
            this.B_depvisible.Size = new System.Drawing.Size(58, 23);
            this.B_depvisible.TabIndex = 73;
            this.B_depvisible.Text = "France";
            this.B_depvisible.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.B_depvisible.UseVisualStyleBackColor = true;
            this.B_depvisible.Click += new System.EventHandler(this.B_depvisible_Click);
            // 
            // TXT_AddCom
            // 
            this.TXT_AddCom.Location = new System.Drawing.Point(92, 35);
            this.TXT_AddCom.Name = "TXT_AddCom";
            this.TXT_AddCom.Size = new System.Drawing.Size(100, 20);
            this.TXT_AddCom.TabIndex = 72;
            this.TXT_AddCom.TextChanged += new System.EventHandler(this.TXT_AddCom_TextChanged);
            // 
            // LBL_PaysGes
            // 
            this.LBL_PaysGes.AutoSize = true;
            this.LBL_PaysGes.ForeColor = System.Drawing.Color.Black;
            this.LBL_PaysGes.Location = new System.Drawing.Point(48, 73);
            this.LBL_PaysGes.Name = "LBL_PaysGes";
            this.LBL_PaysGes.Size = new System.Drawing.Size(30, 13);
            this.LBL_PaysGes.TabIndex = 71;
            this.LBL_PaysGes.Text = "Pays";
            // 
            // LBL_DepGes
            // 
            this.LBL_DepGes.AutoSize = true;
            this.LBL_DepGes.ForeColor = System.Drawing.Color.Black;
            this.LBL_DepGes.Location = new System.Drawing.Point(1, 102);
            this.LBL_DepGes.Name = "LBL_DepGes";
            this.LBL_DepGes.Size = new System.Drawing.Size(68, 13);
            this.LBL_DepGes.TabIndex = 70;
            this.LBL_DepGes.Text = "Département";
            // 
            // LB_GesPays
            // 
            this.LB_GesPays.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LB_GesPays.FormattingEnabled = true;
            this.LB_GesPays.Location = new System.Drawing.Point(258, 101);
            this.LB_GesPays.Name = "LB_GesPays";
            this.LB_GesPays.Size = new System.Drawing.Size(142, 56);
            this.LB_GesPays.TabIndex = 69;
            this.LB_GesPays.SelectedIndexChanged += new System.EventHandler(this.LB_GesPays_SelectedIndexChanged);
            // 
            // LB_GesDep
            // 
            this.LB_GesDep.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LB_GesDep.FormattingEnabled = true;
            this.LB_GesDep.Location = new System.Drawing.Point(258, 167);
            this.LB_GesDep.Name = "LB_GesDep";
            this.LB_GesDep.Size = new System.Drawing.Size(142, 43);
            this.LB_GesDep.TabIndex = 68;
            this.LB_GesDep.SelectedIndexChanged += new System.EventHandler(this.LB_GesDep_SelectedIndexChanged);
            // 
            // B_Croix2
            // 
            this.B_Croix2.FlatAppearance.BorderSize = 0;
            this.B_Croix2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Croix2.ForeColor = System.Drawing.Color.Red;
            this.B_Croix2.Image = ((System.Drawing.Image)(resources.GetObject("B_Croix2.Image")));
            this.B_Croix2.Location = new System.Drawing.Point(418, 3);
            this.B_Croix2.Name = "B_Croix2";
            this.B_Croix2.Size = new System.Drawing.Size(23, 23);
            this.B_Croix2.TabIndex = 55;
            this.B_Croix2.UseVisualStyleBackColor = true;
            this.B_Croix2.Click += new System.EventHandler(this.B_Croix2_Click);
            // 
            // B_InsertLieuxCommune
            // 
            this.B_InsertLieuxCommune.FlatAppearance.BorderSize = 0;
            this.B_InsertLieuxCommune.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_InsertLieuxCommune.ForeColor = System.Drawing.Color.Black;
            this.B_InsertLieuxCommune.Image = ((System.Drawing.Image)(resources.GetObject("B_InsertLieuxCommune.Image")));
            this.B_InsertLieuxCommune.Location = new System.Drawing.Point(85, 123);
            this.B_InsertLieuxCommune.Name = "B_InsertLieuxCommune";
            this.B_InsertLieuxCommune.Size = new System.Drawing.Size(54, 48);
            this.B_InsertLieuxCommune.TabIndex = 67;
            this.TT_Ajouter.SetToolTip(this.B_InsertLieuxCommune, "Insert");
            this.B_InsertLieuxCommune.UseVisualStyleBackColor = true;
            this.B_InsertLieuxCommune.Click += new System.EventHandler(this.B_InsertLieuxCommune_Click);
            // 
            // LBL_CommuneGes
            // 
            this.LBL_CommuneGes.AutoSize = true;
            this.LBL_CommuneGes.ForeColor = System.Drawing.Color.Black;
            this.LBL_CommuneGes.Location = new System.Drawing.Point(18, 40);
            this.LBL_CommuneGes.Name = "LBL_CommuneGes";
            this.LBL_CommuneGes.Size = new System.Drawing.Size(54, 13);
            this.LBL_CommuneGes.TabIndex = 3;
            this.LBL_CommuneGes.Text = "Commune";
            // 
            // TXT_AddPays
            // 
            this.TXT_AddPays.Location = new System.Drawing.Point(92, 67);
            this.TXT_AddPays.Name = "TXT_AddPays";
            this.TXT_AddPays.Size = new System.Drawing.Size(100, 20);
            this.TXT_AddPays.TabIndex = 2;
            this.TXT_AddPays.TextChanged += new System.EventHandler(this.TXT_AddPays_TextChanged);
            // 
            // TXT_AddDep
            // 
            this.TXT_AddDep.Location = new System.Drawing.Point(92, 96);
            this.TXT_AddDep.Name = "TXT_AddDep";
            this.TXT_AddDep.Size = new System.Drawing.Size(100, 20);
            this.TXT_AddDep.TabIndex = 1;
            this.TXT_AddDep.Text = "NO_DEPARTMENT";
            this.TXT_AddDep.TextChanged += new System.EventHandler(this.TXT_AddDep_TextChanged);
            // 
            // LB_GesCom
            // 
            this.LB_GesCom.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LB_GesCom.FormattingEnabled = true;
            this.LB_GesCom.Location = new System.Drawing.Point(258, 37);
            this.LB_GesCom.Name = "LB_GesCom";
            this.LB_GesCom.Size = new System.Drawing.Size(142, 56);
            this.LB_GesCom.TabIndex = 60;
            this.LB_GesCom.SelectedIndexChanged += new System.EventHandler(this.LB_GesCom_SelectedIndexChanged);
            // 
            // GPX_ActesGestion
            // 
            this.GPX_ActesGestion.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.GPX_ActesGestion.Controls.Add(this.LB_GestionIdPays);
            this.GPX_ActesGestion.Controls.Add(this.LB_GestionIdDep);
            this.GPX_ActesGestion.Controls.Add(this.LB_GestionId);
            this.GPX_ActesGestion.Controls.Add(this.TXT_GestionActeLieuID);
            this.GPX_ActesGestion.Controls.Add(this.CB_GestionActeTypeIndividu);
            this.GPX_ActesGestion.Controls.Add(this.LB_GestionActeIndividu);
            this.GPX_ActesGestion.Controls.Add(this.B_GestionActesAjouter);
            this.GPX_ActesGestion.Controls.Add(this.DTP_Date);
            this.GPX_ActesGestion.Controls.Add(this.label7);
            this.GPX_ActesGestion.Controls.Add(this.TXT_GestionActesLieu);
            this.GPX_ActesGestion.Controls.Add(this.label8);
            this.GPX_ActesGestion.Controls.Add(this.LB_GestionActesChoix);
            this.GPX_ActesGestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPX_ActesGestion.Location = new System.Drawing.Point(6, 30);
            this.GPX_ActesGestion.Name = "GPX_ActesGestion";
            this.GPX_ActesGestion.Size = new System.Drawing.Size(447, 248);
            this.GPX_ActesGestion.TabIndex = 53;
            this.GPX_ActesGestion.TabStop = false;
            this.GPX_ActesGestion.Text = "Gestion des actes";
            // 
            // LB_GestionIdPays
            // 
            this.LB_GestionIdPays.FormattingEnabled = true;
            this.LB_GestionIdPays.ItemHeight = 16;
            this.LB_GestionIdPays.Location = new System.Drawing.Point(255, 337);
            this.LB_GestionIdPays.Name = "LB_GestionIdPays";
            this.LB_GestionIdPays.Size = new System.Drawing.Size(124, 36);
            this.LB_GestionIdPays.TabIndex = 67;
            this.LB_GestionIdPays.Visible = false;
            // 
            // LB_GestionIdDep
            // 
            this.LB_GestionIdDep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.LB_GestionIdDep.FormattingEnabled = true;
            this.LB_GestionIdDep.ItemHeight = 16;
            this.LB_GestionIdDep.Location = new System.Drawing.Point(131, 337);
            this.LB_GestionIdDep.Name = "LB_GestionIdDep";
            this.LB_GestionIdDep.Size = new System.Drawing.Size(118, 36);
            this.LB_GestionIdDep.TabIndex = 66;
            this.LB_GestionIdDep.Visible = false;
            // 
            // LB_GestionId
            // 
            this.LB_GestionId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.LB_GestionId.FormattingEnabled = true;
            this.LB_GestionId.ItemHeight = 16;
            this.LB_GestionId.Location = new System.Drawing.Point(14, 337);
            this.LB_GestionId.Name = "LB_GestionId";
            this.LB_GestionId.Size = new System.Drawing.Size(111, 36);
            this.LB_GestionId.TabIndex = 58;
            this.LB_GestionId.Visible = false;
            // 
            // TXT_GestionActeLieuID
            // 
            this.TXT_GestionActeLieuID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_GestionActeLieuID.Location = new System.Drawing.Point(209, 188);
            this.TXT_GestionActeLieuID.Name = "TXT_GestionActeLieuID";
            this.TXT_GestionActeLieuID.Size = new System.Drawing.Size(61, 22);
            this.TXT_GestionActeLieuID.TabIndex = 65;
            this.TXT_GestionActeLieuID.Visible = false;
            // 
            // CB_GestionActeTypeIndividu
            // 
            this.CB_GestionActeTypeIndividu.FormattingEnabled = true;
            this.CB_GestionActeTypeIndividu.Location = new System.Drawing.Point(10, 22);
            this.CB_GestionActeTypeIndividu.Name = "CB_GestionActeTypeIndividu";
            this.CB_GestionActeTypeIndividu.Size = new System.Drawing.Size(163, 24);
            this.CB_GestionActeTypeIndividu.TabIndex = 64;
            // 
            // LB_GestionActeIndividu
            // 
            this.LB_GestionActeIndividu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_GestionActeIndividu.FormattingEnabled = true;
            this.LB_GestionActeIndividu.ItemHeight = 16;
            this.LB_GestionActeIndividu.Location = new System.Drawing.Point(184, 13);
            this.LB_GestionActeIndividu.Name = "LB_GestionActeIndividu";
            this.LB_GestionActeIndividu.Size = new System.Drawing.Size(245, 148);
            this.LB_GestionActeIndividu.TabIndex = 62;
            this.LB_GestionActeIndividu.SelectedIndexChanged += new System.EventHandler(this.LB_GestionActeIndividu_SelectedIndexChanged);
            // 
            // B_GestionActesAjouter
            // 
            this.B_GestionActesAjouter.FlatAppearance.BorderSize = 0;
            this.B_GestionActesAjouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_GestionActesAjouter.Image = ((System.Drawing.Image)(resources.GetObject("B_GestionActesAjouter.Image")));
            this.B_GestionActesAjouter.Location = new System.Drawing.Point(378, 163);
            this.B_GestionActesAjouter.Name = "B_GestionActesAjouter";
            this.B_GestionActesAjouter.Size = new System.Drawing.Size(63, 48);
            this.B_GestionActesAjouter.TabIndex = 61;
            this.TT_Ajouter.SetToolTip(this.B_GestionActesAjouter, "Ajouter");
            this.B_GestionActesAjouter.UseVisualStyleBackColor = true;
            this.B_GestionActesAjouter.Click += new System.EventHandler(this.B_GestionActesAjouter_Click_1);
            // 
            // DTP_Date
            // 
            this.DTP_Date.Location = new System.Drawing.Point(10, 162);
            this.DTP_Date.Name = "DTP_Date";
            this.DTP_Date.Size = new System.Drawing.Size(160, 22);
            this.DTP_Date.TabIndex = 56;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(176, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 16);
            this.label7.TabIndex = 53;
            this.label7.Text = "Date";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // TXT_GestionActesLieu
            // 
            this.TXT_GestionActesLieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_GestionActesLieu.Location = new System.Drawing.Point(10, 188);
            this.TXT_GestionActesLieu.Name = "TXT_GestionActesLieu";
            this.TXT_GestionActesLieu.ReadOnly = true;
            this.TXT_GestionActesLieu.Size = new System.Drawing.Size(160, 22);
            this.TXT_GestionActesLieu.TabIndex = 49;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(176, 195);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 16);
            this.label8.TabIndex = 51;
            this.label8.Text = "Lieu";
            // 
            // LB_GestionActesChoix
            // 
            this.LB_GestionActesChoix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_GestionActesChoix.FormattingEnabled = true;
            this.LB_GestionActesChoix.ItemHeight = 16;
            this.LB_GestionActesChoix.Location = new System.Drawing.Point(10, 56);
            this.LB_GestionActesChoix.Name = "LB_GestionActesChoix";
            this.LB_GestionActesChoix.Size = new System.Drawing.Size(160, 100);
            this.LB_GestionActesChoix.TabIndex = 28;
            this.LB_GestionActesChoix.SelectedIndexChanged += new System.EventHandler(this.LB_GestionActesChoix_SelectedIndexChanged_1);
            // 
            // GPX_Lieux
            // 
            this.GPX_Lieux.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.GPX_Lieux.Controls.Add(this.B_GestionLieux);
            this.GPX_Lieux.Controls.Add(this.TXT_ShowPays);
            this.GPX_Lieux.Controls.Add(this.LBL_ShowPays);
            this.GPX_Lieux.Controls.Add(this.TXT_Departements);
            this.GPX_Lieux.Controls.Add(this.PNL_GestId);
            this.GPX_Lieux.Controls.Add(this.LBL_sl);
            this.GPX_Lieux.Controls.Add(this.LBL_Tdep);
            this.GPX_Lieux.Controls.Add(this.TXT_sl);
            this.GPX_Lieux.Controls.Add(this.LB_ListeLieux);
            this.GPX_Lieux.Controls.Add(this.B_ChargerLieux);
            this.GPX_Lieux.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GPX_Lieux.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPX_Lieux.Location = new System.Drawing.Point(468, 31);
            this.GPX_Lieux.Name = "GPX_Lieux";
            this.GPX_Lieux.Size = new System.Drawing.Size(303, 248);
            this.GPX_Lieux.TabIndex = 50;
            this.GPX_Lieux.TabStop = false;
            this.GPX_Lieux.Text = "Lieux";
            this.GPX_Lieux.Enter += new System.EventHandler(this.GPX_Lieux_Enter);
            // 
            // B_GestionLieux
            // 
            this.B_GestionLieux.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.B_GestionLieux.FlatAppearance.BorderSize = 0;
            this.B_GestionLieux.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_GestionLieux.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_GestionLieux.Image = ((System.Drawing.Image)(resources.GetObject("B_GestionLieux.Image")));
            this.B_GestionLieux.Location = new System.Drawing.Point(251, 62);
            this.B_GestionLieux.Name = "B_GestionLieux";
            this.B_GestionLieux.Size = new System.Drawing.Size(46, 37);
            this.B_GestionLieux.TabIndex = 64;
            this.TT_lieu.SetToolTip(this.B_GestionLieux, "Gestion lieu");
            this.B_GestionLieux.UseVisualStyleBackColor = false;
            this.B_GestionLieux.Click += new System.EventHandler(this.B_GestionLieux_Click);
            // 
            // TXT_ShowPays
            // 
            this.TXT_ShowPays.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.TXT_ShowPays.Location = new System.Drawing.Point(106, 213);
            this.TXT_ShowPays.Name = "TXT_ShowPays";
            this.TXT_ShowPays.Size = new System.Drawing.Size(115, 23);
            this.TXT_ShowPays.TabIndex = 63;
            this.TXT_ShowPays.UseVisualStyleBackColor = false;
            // 
            // LBL_ShowPays
            // 
            this.LBL_ShowPays.AutoSize = true;
            this.LBL_ShowPays.Location = new System.Drawing.Point(40, 216);
            this.LBL_ShowPays.Name = "LBL_ShowPays";
            this.LBL_ShowPays.Size = new System.Drawing.Size(38, 16);
            this.LBL_ShowPays.TabIndex = 62;
            this.LBL_ShowPays.Text = "Pays";
            // 
            // TXT_Departements
            // 
            this.TXT_Departements.BackColor = System.Drawing.SystemColors.Window;
            this.TXT_Departements.Location = new System.Drawing.Point(103, 186);
            this.TXT_Departements.Name = "TXT_Departements";
            this.TXT_Departements.Size = new System.Drawing.Size(118, 23);
            this.TXT_Departements.TabIndex = 59;
            this.TXT_Departements.UseVisualStyleBackColor = false;
            // 
            // PNL_GestId
            // 
            this.PNL_GestId.Controls.Add(this.TXT_DEPNom);
            this.PNL_GestId.Controls.Add(this.TXT_NomDep);
            this.PNL_GestId.Location = new System.Drawing.Point(33, 359);
            this.PNL_GestId.Name = "PNL_GestId";
            this.PNL_GestId.Size = new System.Drawing.Size(200, 30);
            this.PNL_GestId.TabIndex = 57;
            this.PNL_GestId.Visible = false;
            // 
            // TXT_DEPNom
            // 
            this.TXT_DEPNom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.TXT_DEPNom.Location = new System.Drawing.Point(128, 0);
            this.TXT_DEPNom.Name = "TXT_DEPNom";
            this.TXT_DEPNom.Size = new System.Drawing.Size(47, 23);
            this.TXT_DEPNom.TabIndex = 58;
            this.TXT_DEPNom.UseVisualStyleBackColor = false;
            // 
            // TXT_NomDep
            // 
            this.TXT_NomDep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.TXT_NomDep.Location = new System.Drawing.Point(76, 0);
            this.TXT_NomDep.Name = "TXT_NomDep";
            this.TXT_NomDep.Size = new System.Drawing.Size(46, 23);
            this.TXT_NomDep.TabIndex = 49;
            this.TXT_NomDep.UseVisualStyleBackColor = false;
            // 
            // LBL_sl
            // 
            this.LBL_sl.AutoSize = true;
            this.LBL_sl.Location = new System.Drawing.Point(73, 140);
            this.LBL_sl.Name = "LBL_sl";
            this.LBL_sl.Size = new System.Drawing.Size(118, 16);
            this.LBL_sl.TabIndex = 57;
            this.LBL_sl.Text = "Rechercher un lieu";
            this.LBL_sl.Click += new System.EventHandler(this.LBL_sl_Click);
            // 
            // LBL_Tdep
            // 
            this.LBL_Tdep.AutoSize = true;
            this.LBL_Tdep.Location = new System.Drawing.Point(11, 189);
            this.LBL_Tdep.Name = "LBL_Tdep";
            this.LBL_Tdep.Size = new System.Drawing.Size(85, 16);
            this.LBL_Tdep.TabIndex = 56;
            this.LBL_Tdep.Text = "Departement";
            this.LBL_Tdep.Click += new System.EventHandler(this.LBL_Tdep_Click);
            // 
            // TXT_sl
            // 
            this.TXT_sl.Location = new System.Drawing.Point(40, 159);
            this.TXT_sl.Name = "TXT_sl";
            this.TXT_sl.Size = new System.Drawing.Size(181, 22);
            this.TXT_sl.TabIndex = 55;
            this.TXT_sl.TextChanged += new System.EventHandler(this.TXT_sl_TextChanged);
            // 
            // LB_ListeLieux
            // 
            this.LB_ListeLieux.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.LB_ListeLieux.FormattingEnabled = true;
            this.LB_ListeLieux.ItemHeight = 16;
            this.LB_ListeLieux.Location = new System.Drawing.Point(6, 19);
            this.LB_ListeLieux.Name = "LB_ListeLieux";
            this.LB_ListeLieux.Size = new System.Drawing.Size(241, 116);
            this.LB_ListeLieux.TabIndex = 29;
            this.LB_ListeLieux.SelectedIndexChanged += new System.EventHandler(this.LB_ListeLieux_SelectedIndexChanged);
            // 
            // B_ChargerLieux
            // 
            this.B_ChargerLieux.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.B_ChargerLieux.FlatAppearance.BorderSize = 0;
            this.B_ChargerLieux.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_ChargerLieux.Image = ((System.Drawing.Image)(resources.GetObject("B_ChargerLieux.Image")));
            this.B_ChargerLieux.Location = new System.Drawing.Point(250, 19);
            this.B_ChargerLieux.Name = "B_ChargerLieux";
            this.B_ChargerLieux.Size = new System.Drawing.Size(47, 37);
            this.B_ChargerLieux.TabIndex = 47;
            this.TT8gestionlieu.SetToolTip(this.B_ChargerLieux, "Charger lieu");
            this.B_ChargerLieux.UseVisualStyleBackColor = false;
            this.B_ChargerLieux.Click += new System.EventHandler(this.B_ChargerLieux_Click);
            // 
            // TT_Ajouter
            // 
            this.TT_Ajouter.AutomaticDelay = 150;
            this.TT_Ajouter.AutoPopDelay = 5000;
            this.TT_Ajouter.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TT_Ajouter.ForeColor = System.Drawing.Color.Black;
            this.TT_Ajouter.InitialDelay = 150;
            this.TT_Ajouter.ReshowDelay = 30;
            this.TT_Ajouter.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TT_Supprimer
            // 
            this.TT_Supprimer.AutomaticDelay = 150;
            this.TT_Supprimer.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Warning;
            // 
            // TT_Modifier
            // 
            this.TT_Modifier.AutomaticDelay = 150;
            this.TT_Modifier.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TT_ChargerCollecVIABDD
            // 
            this.TT_ChargerCollecVIABDD.AutomaticDelay = 150;
            this.TT_ChargerCollecVIABDD.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TT_SauvCollecDansBDD
            // 
            this.TT_SauvCollecDansBDD.AutomaticDelay = 150;
            this.TT_SauvCollecDansBDD.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TT_ChargerCollecViaFichier
            // 
            this.TT_ChargerCollecViaFichier.AutomaticDelay = 150;
            this.TT_ChargerCollecViaFichier.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TT_SauvCollecDansFichier
            // 
            this.TT_SauvCollecDansFichier.AutomaticDelay = 150;
            this.TT_SauvCollecDansFichier.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // PNL_PhotoFamille
            // 
            this.PNL_PhotoFamille.Controls.Add(this.LBL_imageInfo);
            this.PNL_PhotoFamille.Controls.Add(this.LBL_);
            this.PNL_PhotoFamille.Controls.Add(this.PB_Famille);
            this.PNL_PhotoFamille.Location = new System.Drawing.Point(824, 13);
            this.PNL_PhotoFamille.Name = "PNL_PhotoFamille";
            this.PNL_PhotoFamille.Size = new System.Drawing.Size(326, 340);
            this.PNL_PhotoFamille.TabIndex = 62;
            this.PNL_PhotoFamille.Visible = false;
            // 
            // LBL_imageInfo
            // 
            this.LBL_imageInfo.AutoSize = true;
            this.LBL_imageInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_imageInfo.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBL_imageInfo.Location = new System.Drawing.Point(19, 36);
            this.LBL_imageInfo.Name = "LBL_imageInfo";
            this.LBL_imageInfo.Size = new System.Drawing.Size(155, 20);
            this.LBL_imageInfo.TabIndex = 93;
            this.LBL_imageInfo.Text = "anfklenhfklnhfklze";
            // 
            // LBL_
            // 
            this.LBL_.AutoSize = true;
            this.LBL_.Location = new System.Drawing.Point(33, 22);
            this.LBL_.Name = "LBL_";
            this.LBL_.Size = new System.Drawing.Size(0, 13);
            this.LBL_.TabIndex = 81;
            this.LBL_.Click += new System.EventHandler(this.label14_Click);
            // 
            // PB_Famille
            // 
            this.PB_Famille.Location = new System.Drawing.Point(23, 57);
            this.PB_Famille.Name = "PB_Famille";
            this.PB_Famille.Size = new System.Drawing.Size(275, 250);
            this.PB_Famille.TabIndex = 80;
            this.PB_Famille.TabStop = false;
            // 
            // PNL_ImageActe
            // 
            this.PNL_ImageActe.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.PNL_ImageActe.Controls.Add(this.PB_Acte);
            this.PNL_ImageActe.Location = new System.Drawing.Point(1156, 13);
            this.PNL_ImageActe.Name = "PNL_ImageActe";
            this.PNL_ImageActe.Size = new System.Drawing.Size(523, 396);
            this.PNL_ImageActe.TabIndex = 63;
            this.PNL_ImageActe.Visible = false;
            this.PNL_ImageActe.Paint += new System.Windows.Forms.PaintEventHandler(this.PNL_ImageActe_Paint);
            // 
            // PB_Acte
            // 
            this.PB_Acte.Location = new System.Drawing.Point(14, 32);
            this.PB_Acte.Name = "PB_Acte";
            this.PB_Acte.Size = new System.Drawing.Size(500, 352);
            this.PB_Acte.TabIndex = 55;
            this.PB_Acte.TabStop = false;
            // 
            // FRM_Accueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(37)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.PNL_ImageActe);
            this.Controls.Add(this.PNL_PhotoFamille);
            this.Controls.Add(this.PNL_GestionActes);
            this.Controls.Add(this.GPX_Individu);
            this.Controls.Add(this.GPX_AnniversairesDuMois);
            this.Controls.Add(this.B_MenuSelectionFamille);
            this.Controls.Add(this.GPX_GesActes);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FRM_Accueil";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FRM_Accueil_FormClosing);
            this.Load += new System.EventHandler(this.FRM_Accueil_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FRM_Accueil_KeyDown);
            this.GPX_Individu.ResumeLayout(false);
            this.GPX_Individu.PerformLayout();
            this.GPX_Famille.ResumeLayout(false);
            this.GPX_Famille.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_individu)).EndInit();
            this.PNL_GesMariage.ResumeLayout(false);
            this.PNL_GesMariage.PerformLayout();
            this.GPX_AnniversairesDuMois.ResumeLayout(false);
            this.GPX_GesActes.ResumeLayout(false);
            this.GPX_GesActes.PerformLayout();
            this.PNL_GestionActes.ResumeLayout(false);
            this.PNL_GestLieux.ResumeLayout(false);
            this.PNL_GestLieux.PerformLayout();
            this.GPX_ActesGestion.ResumeLayout(false);
            this.GPX_ActesGestion.PerformLayout();
            this.GPX_Lieux.ResumeLayout(false);
            this.GPX_Lieux.PerformLayout();
            this.PNL_GestId.ResumeLayout(false);
            this.PNL_PhotoFamille.ResumeLayout(false);
            this.PNL_PhotoFamille.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Famille)).EndInit();
            this.PNL_ImageActe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PB_Acte)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LB_individu;
        private System.Windows.Forms.TextBox TXT_Nom;
        private System.Windows.Forms.TextBox TXT_Prenom;
        private System.Windows.Forms.Label LBL_Nom;
        private System.Windows.Forms.Label LBL_Prenom;
        private System.Windows.Forms.ListBox LB_Frere;
        private System.Windows.Forms.ListBox LB_GrandsParents;
        private System.Windows.Forms.ListBox LB_OnclesTantes;
        private System.Windows.Forms.Label LBL_Enfants;
        private System.Windows.Forms.ListBox LB_Enfants;
        private System.Windows.Forms.GroupBox GPX_Individu;
        private System.Windows.Forms.Button B_Modifier;
        private System.Windows.Forms.Button B_Ajouter;
        private System.Windows.Forms.Button B_Supprimer;
        private System.Windows.Forms.Button B_ChargerCollecViaSQL;
        private System.Windows.Forms.Button B_ChargerCollecViaFichier;
        private System.Windows.Forms.ListBox LB_PersonnePCS;
        private System.Windows.Forms.Label LBL_Profession;
        private System.Windows.Forms.TextBox TXT_Id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button B_SauvegarderCollectionBDD;
        private System.Windows.Forms.ListBox LB_Parents;
        private System.Windows.Forms.Label LBL_Mere;
        private System.Windows.Forms.TextBox TXT_IdMere;
        private System.Windows.Forms.TextBox TXT_IdPere;
        private System.Windows.Forms.TextBox TXT_Info;
        private System.Windows.Forms.GroupBox GPX_AnniversairesDuMois;
        private System.Windows.Forms.ListBox LB_Anniv;
        private System.Windows.Forms.PictureBox PB_individu;
        private System.Windows.Forms.TextBox TXT_Test;
        private System.Windows.Forms.Button B_MenuSelectionFamille;
        private System.Windows.Forms.GroupBox GPX_GesActes;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button B_GestionActes;
        private System.Windows.Forms.TextBox TXT_ActeDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXT_ActeLieu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox LB_Maries;
        private System.Windows.Forms.ListBox LB_Acte;
        private System.Windows.Forms.Panel PNL_GestionActes;
        private System.Windows.Forms.GroupBox GPX_ActesGestion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TXT_GestionActesLieu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox LB_GestionActesChoix;
        private System.Windows.Forms.DateTimePicker DTP_Date;
        private System.Windows.Forms.Button B_GestionPNLActesFermer;
        private System.Windows.Forms.Button B_GestionActesAjouter;
        private System.Windows.Forms.ComboBox CB_Metier;
        private System.Windows.Forms.Button B_SauvergardeFichier;
        private System.Windows.Forms.ToolTip TT_Ajouter;
        private System.Windows.Forms.ToolTip TT_Supprimer;
        private System.Windows.Forms.ToolTip TT_SauvCollecDansFichier;
        private System.Windows.Forms.ToolTip TT_SauvCollecDansBDD;
        private System.Windows.Forms.ToolTip TT_ChargerCollecVIABDD;
        private System.Windows.Forms.ToolTip TT_ChargerCollecViaFichier;
        private System.Windows.Forms.ToolTip TT_Modifier;
        private System.Windows.Forms.Button B_Imprimer;
        private System.Windows.Forms.ComboBox CB_GestionActeTypeIndividu;
        private System.Windows.Forms.ListBox LB_GestionActeIndividu;
        private System.Windows.Forms.TextBox TXT_GestionActeLieuID;
        private System.Windows.Forms.Panel PNL_GesMariage;
        private System.Windows.Forms.Label LBL_Marie1;
        private System.Windows.Forms.ListBox LB_Marie1;
        private System.Windows.Forms.ListBox LB_Marie2;
        private System.Windows.Forms.Label LBL_Marie2;
        private System.Windows.Forms.Button B_FermerGesMariage;
        private System.Windows.Forms.Label LBL_LieuDc;
        private System.Windows.Forms.Label LBL_LieuNs;
        private System.Windows.Forms.Label LBL_DateDc;
        private System.Windows.Forms.Label LBL_DateN;
        private System.Windows.Forms.TextBox TXT_LieuDc;
        private System.Windows.Forms.TextBox TXT_LieuNs;
        private System.Windows.Forms.TextBox TXT_DateDc;
        private System.Windows.Forms.TextBox TXT_DateNs;
        private System.Windows.Forms.Label LBL_DateMariage;
        private System.Windows.Forms.ListBox LB_LieuMariage;
        private System.Windows.Forms.ListBox LB_DateMariage;
        private System.Windows.Forms.Label LBL_Famille;
        private System.Windows.Forms.ListBox LB_Temoin;
        private System.Windows.Forms.ListBox LB_GestionId;
        private System.Windows.Forms.GroupBox GPX_Lieux;
        private System.Windows.Forms.Button TXT_ShowPays;
        private System.Windows.Forms.Label LBL_ShowPays;
        private System.Windows.Forms.Button TXT_Departements;
        private System.Windows.Forms.Panel PNL_GestId;
        private System.Windows.Forms.Button TXT_DEPNom;
        private System.Windows.Forms.Button TXT_NomDep;
        private System.Windows.Forms.Label LBL_sl;
        private System.Windows.Forms.Label LBL_Tdep;
        private System.Windows.Forms.TextBox TXT_sl;
        private System.Windows.Forms.ListBox LB_ListeLieux;
        private System.Windows.Forms.Button B_ChargerLieux;
        private System.Windows.Forms.Panel PNL_GestLieux;
        private System.Windows.Forms.Button B_InsertLieu;
        private System.Windows.Forms.TextBox TXT_IdGestLast;
        private System.Windows.Forms.Button B_depvisible;
        private System.Windows.Forms.TextBox TXT_AddCom;
        private System.Windows.Forms.Label LBL_PaysGes;
        private System.Windows.Forms.Label LBL_DepGes;
        private System.Windows.Forms.ListBox LB_GesPays;
        private System.Windows.Forms.ListBox LB_GesDep;
        private System.Windows.Forms.Button B_Croix2;
        private System.Windows.Forms.Button B_InsertLieuxCommune;
        private System.Windows.Forms.Label LBL_CommuneGes;
        private System.Windows.Forms.TextBox TXT_AddPays;
        private System.Windows.Forms.TextBox TXT_AddDep;
        private System.Windows.Forms.ListBox LB_GesCom;
        private System.Windows.Forms.ListBox LB_GestionIdPays;
        private System.Windows.Forms.ListBox LB_GestionIdDep;
        private System.Windows.Forms.Button B_GestionLieux;
        private System.Windows.Forms.Button B_Arbre;
        private System.Windows.Forms.ListBox LB_Profession;
        private System.Windows.Forms.GroupBox GPX_Famille;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button B_memepcs;
        private System.Windows.Forms.Button B_masquerpcs;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolTip TT_VoirProfession;
        private System.Windows.Forms.ToolTip MasquerProfession;
        private System.Windows.Forms.ToolTip TT_AfficherArbre;
        private System.Windows.Forms.ToolTip TT_Imprimer;
        private System.Windows.Forms.Panel PNL_PhotoFamille;
        private System.Windows.Forms.PictureBox PB_Famille;
        private System.Windows.Forms.Button B_ModifBDD;
        private System.Windows.Forms.Button B_DeleteBDD;
        private System.Windows.Forms.Button B_AddBDD;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolTip TT_lieu;
        private System.Windows.Forms.ToolTip TT8gestionlieu;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolTip TT_Menu;
        private System.Windows.Forms.Label LBL_;
        private System.Windows.Forms.Label LBL_imageInfo;
        private System.Windows.Forms.Panel PNL_ImageActe;
        private System.Windows.Forms.PictureBox PB_Acte;
        private System.Windows.Forms.TextBox TXT_ActeId;
    }
}

