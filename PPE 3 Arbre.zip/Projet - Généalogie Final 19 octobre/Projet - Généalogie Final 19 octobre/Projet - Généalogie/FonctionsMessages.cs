﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestionDErreurs;
using System.Windows.Forms;

namespace Messages
{
    public unsafe class FonctionsMessage
    {
        /// <summary>
        /// affiche un message popup
        /// </summary>
        /// <param name="nomclasse"></param>
        /// <param name="nomfonction"></param>
        /// <param name="msg"></param>
        /// <param name="erreur"></param>
        public void AfficheMessage(string nomclasse, string nomfonction, string msg, string erreur)
        {
            bool flag = false;
            MessagePopup mp = new MessagePopup(&flag, nomclasse, nomfonction, msg, erreur);
            DialogResult dr = mp.ShowDialog();
            mp.Dispose();
        }
        /// <summary>
        /// affiche et attends une confirmation
        /// </summary>
        /// <param name="message"></param>
        /// <param name="titre"></param>
        /// <returns></returns>
        public DialogResult AfficheMessage2(string message, string titre)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            return MessageBox.Show(message, titre, buttons);
        }
    }
}
