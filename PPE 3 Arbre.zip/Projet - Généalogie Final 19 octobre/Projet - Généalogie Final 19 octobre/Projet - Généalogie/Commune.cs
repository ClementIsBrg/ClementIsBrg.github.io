﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    public class Commune
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string CodePostal { get; set; }
        public int IdDepartement { get; set; }
        public Commune(int id, string nom, string codepostal, int iddepartement)
        {
            Id = id;
            Nom = nom;
            CodePostal = codepostal;
            IdDepartement = iddepartement;
        }
        public Commune() : this(0, "no_name", "no_code", 0) { }
        public override string ToString()
        {
            return Id + " " + Nom + " " + CodePostal + " " + IdDepartement;
        }


    }
}
