﻿using Messages;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Projet___Généalogie
{
    public partial class FRM_Accueil : Form
    {
        #region Déclaration des listes et fichiers

        private string cheminPartie1;
        private string cheminPartie2 = "Personnes\\individus";


        private List<Personne> lesPersonnes = new List<Personne>();

        /*private Global gbp = new Global(Application.StartupPath, "Fichiers\\", "Personnes");*/
        private List<Personne> lesPersonnesPCS = new List<Personne>();
        /*private Global gbpPCS = new Global(Application.StartupPath, "Fichiers\\", "PersonnesPCS");*/
        private List<Profession> lesProfessions = new List<Profession>();
        /*        private Global gbc = new Global(Application.StartupPath, "Fichiers\\", "Professions");
        */      //  private List<Commune> lesCommunes = new List<Commune>();
        /*        private Global gbco = new Global(Application.StartupPath, "Fichiers\\", "Communes");
        */
        private List<Acte> lesActes = new List<Acte>();
        /*        private Global gba = new Global(Application.StartupPath, "Fichiers\\", "Actes");
        */
        private List<Personne> lesMariagePCS = new List<Personne>();
        /*        private Global gblmPCS = new Global(Application.StartupPath, "Fichiers\\", "MariagePCS");
        */
        /*        private Global gbl = new Global(Application.StartupPath, "Fichiers\\", "Lieu");
        */
        private List<Lieu> lesLieu = new List<Lieu>();
        private List<Departement> lesDepartement = new List<Departement>();
        private List<Pays> lesPays = new List<Pays>();
        private List<Lieu_session_actuelle> lesLieuActuelle = new List<Lieu_session_actuelle>();

        private List<ListeIndividuAnniv> lesAnniv = new List<ListeIndividuAnniv>();
        // private Global gbllia = new Global(Application.StartupPath, "Fichiers\\", "Anniv");

        private Bitmap captureFormImage; //POUR IMPRIMER

        private List<Liste_Individu> lesIndividu = new List<Liste_Individu>(); //sert pour l'insert des actes
        private List<TypeIndividu> lesTypeIndividu = new List<TypeIndividu>(); //sert pour l'insert des actes


        public string imagePathInconnuPhotoFamille;
        #endregion


        #region Graphismes + gestion du formulaire

        //private bool confirmationAffichee = false; // Déclaration d'une variable de contrôle pour que la validation quand on quitte le form ne se fasse pas 2 fois






        #endregion

        #region Déclaration des variables globales à la classe FRM_Accueil

        // définition de la chaine de connexion nécessaire pour accéder à la base Mysql
        public static string chaineConnexion;
        // définition de l'objet connexion
        private static MySqlConnection cnx;
        // déclare la variable d'instance de la classe Requete
        Requête rq = new Requête();
        private static FonctionsMessage fm = new FonctionsMessage();

        public FRM_Accueil()
        {
            InitializeComponent();
            // Activez la gestion des touches pour ce formulaire
            this.KeyPreview = true;
            this.KeyDown += FRM_Accueil_KeyDown;

            //Chaine de connexion avec le nom de la BDD choisie depuis FRM_Graphic
            chaineConnexion = "Data Source=localhost;Database=" + FRM_Graphic.SelectedDbName + "; User Id=root; Password=root";
            //BDD choisie dans FRM_Graphic
            cnx = new MySqlConnection(chaineConnexion);




            LBL_Famille.Text = FRM_Graphic.SelectedDbName;//Afficher le nom de famille 

            LB_Frere.SelectedIndexChanged += LB_Frere_SelectedIndexChanged;
        }      



        #endregion

        #region Gestion des boutons



        private void B_Ajouter_Click(object sender, EventArgs e)
        {

            AjouterPersonneCollection();
        }
        private void AjouterPersonneCollection()
        {
            try
            {
                int id = int.Parse(TXT_Id.Text);

                // Vérifier si l'ID existe déjà dans la collection avant d'insérer la personne
                if (LesPersonnesContiennentId(id))
                {
                    MessageBox.Show("L'ID de la personne existe déjà dans la collection, insertion impossible.");
                    return; // Sortir de la méthode si l'ID existe déjà
                }

                try //Si l'ID n'existe pas, c'est bon, on ajoute la personne dans la collection
                {
                    lesPersonnes.Add(new Personne()
                    {
                        Id = int.Parse(TXT_Id.Text),
                        Nom = TXT_Nom.Text,
                        Prenom = TXT_Prenom.Text,
                        IdPere = int.Parse(TXT_IdPere.Text),
                        IdMere = int.Parse(TXT_IdMere.Text),
                        IdProfession = CB_Metier.SelectedIndex,
                        Info = TXT_Info.Text

                    });
                }
                catch
                {
                    MessageBox.Show("Erreur lors de l'ajout de la personne : ");
                }
                ChargerLB();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout de la personne : " + ex.Message);
            }
        }

        private void B_Supprimer_Click(object sender, EventArgs e)
        { 
            SupprimerPersonneCollection();
        }
        private void SupprimerPersonneCollection()
        {
            //Suppression d'un individu
            int j = LB_individu.SelectedIndex;
            if (j != -1)
            {
                lesPersonnes.RemoveAt(j);
            }
            /*
            try
            {
                int i = rq.Exec_SQL_MajDonneesPersonnes(cnx, "suppression_personne", int.Parse(TXT_Id.Text), TXT_Nom.Text, TXT_Prenom.Text, TXT_DateNaissance.Text, TXT_DateDeces.Text, int.Parse(TXT_IdProfession.Text), "Erreur suppression personne");
            }
            catch (Exception ex) { MessageBox.Show("Erreur suppression personne", ex.Message); }
            */
            EffaceChamps();

            ChargerLB();
        }

        private void B_Modifier_Click(object sender, EventArgs e)  //Modification individu dans la collection
        {
            ModifierCollectionPersonne();
        }

        private void ModifierCollectionPersonne()
        {
            DialogResult result = fm.AfficheMessage2("Confirmez-vous la modification de l'individu ?", "Modification d'une ligne");
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                int i = LB_individu.SelectedIndex;
                if (i != -1)
                {
                    lesPersonnes[i].Id = int.Parse(TXT_Id.Text);
                    lesPersonnes[i].Nom = TXT_Nom.Text;
                    lesPersonnes[i].Prenom = TXT_Prenom.Text;
                    lesPersonnes[i].IdPere = int.Parse(TXT_IdPere.Text);
                    lesPersonnes[i].IdMere = int.Parse(TXT_IdMere.Text);
                    lesPersonnes[i].IdProfession = CB_Metier.SelectedIndex;
                    lesPersonnes[i].Info = TXT_Info.Text;


                    EffaceChamps();

                    ChargerLB();
                }
            }
        }

        private void B_SauvergarderCollectionBDD_Click(object sender, EventArgs e)
        {
            SupprimerToutesLesDonneesDeLaBase();
            Sauvergarder_Collection_Dans_BDD();
        }
        private void B_ChargerListe_Click(object sender, EventArgs e)
        {

        }

        private void B_ChargerCollecViaSQL_Click(object sender, EventArgs e)
        {
            ChargerCollection();
            ChargerLB();

            ChargerCollectionLieu();
            ChargerCollectionDep();
            ChargerCollectionPays();
        }

        // Charger un fichiers depuis la famille selectionner (Achille)
        private void ChargerFichiers()
        {
            try
            {

                #region Chemin enregistrement de fichier 
                Global gbp = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "individus");
                Global gbpPCS = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "individuspcs");
                Global gbc = new Global(Application.StartupPath, "\\", "Resources \\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "professions");
                Global gbco = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Communes\\", "individuspcs");
                Global gba = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Actes\\", "individuspcs");
                Global gblmPCS = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "MariagePCS\\", "individuspcs");
                Global gbl = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Lieu\\", "individuspcs");
                #endregion

                BinaryFormatter formatter = new BinaryFormatter();




                FileStream fs = new FileStream(gbp.ToString(), FileMode.Open, FileAccess.Read);
                lesPersonnes = (List<Personne>)formatter.Deserialize(fs);
                fs.Close();
            }
            catch (Exception exc)
            {
                fm.AfficheMessage("FRM_Personnes", "B_ChargerFichierPersonnes_Click", "Chargement fichier personnes non effectué", exc.ToString());
            }

        }
        private void B_ChargerCollecViaFichier_Click(object sender, EventArgs e)
        {
            ChargerFichiers();
            ChargerLB();
            
        }


        #endregion

        #region Gestion des ListBox



        public void LB_individu_SelectedIndexChanged(object sender, EventArgs e)
        //Fonction qui affiche les éléments de l'individu dans les textbox + trouve l'image de la personne avec son ID
        {
            // ici on affiche les informations de la personne sur laquelle on a cliqué dans les textbox
            RazControles_Secondaire();
            EffaceChamps();
            int i = LB_individu.SelectedIndex;
            if (i != -1)
            {
                TXT_Id.Text = lesPersonnes[i].Id.ToString();
                TXT_Nom.Text = lesPersonnes[i].Nom;
                TXT_Prenom.Text = lesPersonnes[i].Prenom;
                CB_Metier.SelectedIndex = RechercherCat(lesPersonnes[i].IdProfession);//transformation de txt profession en listebox metier pour simplification de l'insert, update
                TXT_IdPere.Text = lesPersonnes[i].IdPere.ToString();
                TXT_IdMere.Text = lesPersonnes[i].IdMere.ToString();
                TXT_Info.Text = lesPersonnes[i].Info.ToString();


            }





            {

                // --------------CODE POUR IMAGE INDIVIDU ------------------

                // Obtenez le répertoire de base de l'application
                string appDirectory = Path.GetDirectoryName(Application.ExecutablePath);

                // Construisez le chemin complet du dossier "Resources"
                string resourcesFolder = Path.Combine(appDirectory, "Resources");

                // Récupérez l'ID de l'individu sélectionné dans la TextBox
                string selectedID = TXT_Id.Text;

                // Combinez le chemin du répertoire "Resources" avec le chemin de la famille et le nom du fichier
                // Obtenez le nom de la famille sélectionnée dans la ListBox
                string selectedFamily = FRM_Graphic.SelectedDbName;
                string imagePath = Path.Combine(appDirectory, resourcesFolder, selectedFamily, "Images", selectedID + ".jpg");
                TXT_Test.Text = imagePath;

                string imagePathInconnu = Path.Combine(appDirectory, resourcesFolder + "\\Inconnu.jpg");
                imagePathInconnuPhotoFamille = Path.Combine(appDirectory, resourcesFolder + "\\InconnuFamille.png");


                // Vérifiez si le fichier image existe avant de l'afficher
                if (File.Exists(imagePath))
                {
                    // Chargez l'image dans la PictureBox
                    PB_individu.Image = Image.FromFile(imagePath);
                }
                else
                {
                    // Si l'image n'existe pas, image Inconnu
                    PB_individu.Image = Image.FromFile(imagePathInconnu);
                }
                // --------------FIN CODE POUR IMAGE INDIVIDU ------------------


            }

            #region AFFICHAGE INFORMATIONS EVENEMENTS D'UN INDIVIDU (Prevot Valentin)
            /*affichage informations de la naissance de l'individu*/
            try
            {
                lesLieu.Clear();
                lesActes.Clear();
                TXT_DateNs.Clear();
                TXT_LieuNs.Clear();

                int idmm = 0;
                int j = LB_individu.SelectedIndex;
                if (j != -1)
                {
                    idmm = lesPersonnes[j].Id;
                }
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT * from acte, type_acte, type_individu, personne, liste_individu, lieu  WHERE acte.id = liste_individu.idActe AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND acte.idtypeacte = 1 AND acte.IdVille = lieu.ville_id AND personne.id=" + idmm + ";", "Erreur select personne");
                while (curseur.Read())
                {
                    lesActes.Add(new Acte()
                    {
                        Id = (int)curseur["id"],
                        DateActe = ((DateTime)curseur["dateActe"]),
                        IdTypeActe = (int)curseur["idTypeActe"],
                        TypeActe = (string)curseur["nom"],
                        IdVille = (int)curseur["idVille"],

                    });

                    lesLieu.Add(new Lieu()
                    {
                        Idl = (int)curseur["ville_id"],
                        Vn = (string)curseur["ville_slug"],
                        Vd_id = (string)curseur["ville_departement"],
                    });
                }
                curseur.Close();
                cnx.Close();
                foreach (Acte unActe in lesActes)
                    TXT_DateNs.Text = unActe.DateActe.ToString("dd/MM/yyyy");
                foreach (Lieu unLieu in lesLieu)
                    TXT_LieuNs.Text = unLieu.Vn;
            }
            catch (Exception ex) { MessageBox.Show("Erreur LB_Personnes_SelectedIndexChanged", ex.Message); cnx.Close(); }




            /*affichage informations de décès de l'individu*/
            try
            {
                lesLieu.Clear();
                lesActes.Clear();
                TXT_DateDc.Clear();
                TXT_LieuDc.Clear();


                int idmm = 0;
                int j = LB_individu.SelectedIndex;
                if (j != -1)
                {
                    idmm = lesPersonnes[j].Id;
                }
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT * from acte, type_acte, type_individu, personne, liste_individu, lieu  WHERE acte.id = liste_individu.idActe AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND acte.idtypeacte = 2 AND acte.IdVille = lieu.ville_id AND personne.id=" + idmm + ";", "Erreur select personne");
                while (curseur.Read())
                {
                    lesActes.Add(new Acte()
                    {
                        Id = (int)curseur["id"],
                        DateActe = ((DateTime)curseur["dateActe"]),
                        IdTypeActe = (int)curseur["idTypeActe"],
                        TypeActe = (string)curseur["nom"],
                        IdVille = (int)curseur["idVille"],

                    });

                    lesLieu.Add(new Lieu()
                    {
                        Idl = (int)curseur["ville_id"],
                        Vn = (string)curseur["ville_slug"],
                        Vd_id = (string)curseur["ville_departement"],
                    });

                }
                curseur.Close();
                cnx.Close();
                foreach (Acte unActe in lesActes)
                    TXT_DateDc.Text = unActe.DateActe.ToString("dd/MM/yyyy");
                foreach (Lieu unLieu in lesLieu)
                    TXT_LieuDc.Text = unLieu.Vn;
            }
            catch (Exception ex) { MessageBox.Show("Erreur LB_Personnes_SelectedIndexChanged", ex.Message); cnx.Close(); }


            /*affichage informations du mariage de l'individu*/
            try
            {
                lesLieu.Clear();
                lesActes.Clear();
                LB_DateMariage.Items.Clear();
                LB_LieuMariage.Items.Clear();


                int idmm = 0;
                int j = LB_individu.SelectedIndex;
                if (j != -1)
                {
                    idmm = lesPersonnes[j].Id;
                }
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT * from acte, type_acte, type_individu, personne, liste_individu, lieu  WHERE acte.id = liste_individu.idActe AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND acte.idtypeacte = 3 AND acte.IdVille = lieu.ville_id AND personne.id=" + idmm + ";", "Erreur select personne");
                while (curseur.Read())
                {
                    lesActes.Add(new Acte()
                    {
                        Id = (int)curseur["id"],
                        DateActe = ((DateTime)curseur["dateActe"]),
                        IdTypeActe = (int)curseur["idTypeActe"],
                        TypeActe = (string)curseur["nom"],
                        IdVille = (int)curseur["idVille"],

                    });

                    lesLieu.Add(new Lieu()
                    {
                        Idl = (int)curseur["ville_id"],
                        Vn = (string)curseur["ville_slug"],
                        Vd_id = (string)curseur["ville_departement"],
                    });

                }
                curseur.Close();
                cnx.Close();
                LB_DateMariage.Items.Clear();
                foreach (Acte unActe in lesActes) // Affichage de la collection dans LB_Acte
                    LB_DateMariage.Items.Add(unActe.DateActe);
                LB_LieuMariage.Items.Clear();
                foreach (Lieu unLieu in lesLieu) // Affichage de la collection dans LB_Acte
                    LB_LieuMariage.Items.Add(unLieu.Vn);
            }
            catch (Exception ex) { MessageBox.Show("Erreur LB_Personnes_SelectedIndexChanged", ex.Message); cnx.Close(); }

            #endregion


            // requete sql pour afficher enfant (Achille)

            LB_Enfants.Items.Clear();

            

            try
            {
                cnx.Open();
                string sql = "SELECT id, prenom, nom FROM personne WHERE idPere = " + int.Parse(TXT_Id.Text) + " OR idMere = " + int.Parse(TXT_Id.Text) + ";";
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                cmd.CommandText = sql;
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    {
                        string id = reader["id"].ToString();
                        string prenom = reader["prenom"].ToString();
                        string nom = reader["nom"].ToString();
                        string nomComplet = id + " " + prenom + " " + nom;
                        LB_Enfants.Items.Add(nomComplet);

                    }



                }
                reader.Close();
                cnx.Close();

            }
            // catch (Exception ex) { MessageBox.Show("Erreur LB_Personnes_SelectedIndexChanged", ex.Message); cnx.Close(); }
            catch { cnx.Close(); }

            AfficherEnfants(lesPersonnes[i]);
            ChargerGrandsParents(lesPersonnes[i]);
            ChargerOncleTante(lesPersonnes[i]);
            AfficherFreresSoeurs(lesPersonnes[i]);
            AfficherParents(lesPersonnes[i]);

            //Selection de la personne dans la base de donnée afin de l'afficher dans le LB_Acte
            int k = LB_Acte.SelectedIndex;
            if (k != -1)
            {
                TXT_ActeDate.Text = lesActes[k].DateActe.ToString("dd/MM/yyyy");
                TXT_ActeLieu.Text = lesActes[k].IdVille.ToString();

            }

            try
            {
                LB_Acte.Items.Clear();
                lesActes.Clear();

                int idmm = 0;
                int j = LB_individu.SelectedIndex;
                if (j != -1)
                {
                    idmm = lesPersonnes[j].Id;
                }
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT * from acte, type_acte, type_individu, personne, liste_individu  WHERE acte.id = liste_individu.idActe AND type_individu.id != 5 AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND personne.id=" + idmm + ";", "Erreur select personne");
                // SELECT des actes des indivus exepté les acte de mariage dont les individus sont témoins 
                while (curseur.Read())
                {
                    lesActes.Add(new Acte()
                    {
                        Id = (int)curseur["id"],
                        DateActe = ((DateTime)curseur["dateActe"]),
                        IdTypeActe = (int)curseur["idTypeActe"],
                        TypeActe = (string)curseur["nom"],
                        IdVille = (int)curseur["idVille"]
                    });

                }
                curseur.Close();
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur select acte", ex.Message); cnx.Close(); }

            LB_Acte.Items.Clear();
            foreach (Acte unActe in lesActes) // Affichage de la collection dans LB_Acte
                LB_Acte.Items.Add(unActe.TypeActe);

            AfficherPhotoFamille();
            PB_Acte.Image = null;
            PNL_ImageActe.Visible = false;

        }

        private async void AfficherPhotoFamille()
        {
            PB_Famille.Image = null;
            LBL_imageInfo.Text = "";
            PNL_PhotoFamille.Visible = true;

            // Utilisez une liste pour stocker les informations sur les images avant de les afficher
            List<(string NomImage, string InfosImage)> imagesList = new List<(string, string)>();


            try
            {
                cnx.Open();

                string sql = "SELECT image.id, image.nom, image.infos FROM image JOIN detailimage ON image.id = detailimage.idimage JOIN personne ON detailimage.idpersonne = personne.id WHERE personne.id =" + int.Parse(TXT_Id.Text) + "; ";
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string nomImage = reader["nom"].ToString();
                    string infosImage = reader["infos"].ToString();

                    imagesList.Add((nomImage, infosImage));
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur LB_Personnes_SelectedIndexChanged", ex.Message);
            }
            finally
            {
                if (cnx.State == ConnectionState.Open)
                {
                    cnx.Close();
                }
            }


            // Utiliser la liste pour afficher les images
            foreach (var (nomImage, infosImage) in imagesList)
            {

                LBL_imageInfo.Text = (infosImage);

                string cheminImage = Path.Combine("Resources", FRM_Graphic.SelectedDbName, "Images", nomImage + ".jpg");
                if (File.Exists(cheminImage))
                {
                    Image image = Image.FromFile(cheminImage);
                    PB_Famille.Image = image;

                    await Task.Delay(5000);
                }

                PB_Famille.Image = null;
                LBL_imageInfo.Text = "";
            }

            //Ferme le panel photo
            PNL_PhotoFamille.Visible = false;

        }















        private void LB_Familles_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LB_P_Metier_SelectedIndexChanged(object sender, EventArgs e)
        { }

        private void LB_PersonnePCS_SelectedIndexChanged(object sender, EventArgs e)
        {
            // On synchronise la LB qui affiche les métiers avec la CB 
            EffaceChamps();
            int selectedIndex = LB_PersonnePCS.SelectedIndex;
            if (selectedIndex != -1)
            {
                string cat = LB_PersonnePCS.SelectedItem.ToString();

                string[] cats = cat.Split(' ');

                int idcat = int.Parse(cats[0]);

                int IndexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idcat)
                    {
                        IndexDansLBIndividu = i;
                        break;
                    }
                }
                if (IndexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = IndexDansLBIndividu;
                }
            }
        }

        private void CB_Metier_SelectedIndexChanged(object sender, EventArgs e)
        {
            //syncrhonisation entre LB_Profession et CB_Metier dans CB_Metier
            int selectedIndex = CB_Metier.SelectedIndex;
            if (selectedIndex != -1)
            {
                string cat = CB_Metier.SelectedItem.ToString();

                string[] cats = cat.Split(' ');

                int idcat = int.Parse(cats[0]);

                int IndexDansLBIndividu = -1;
                for (int i = 0; i < LB_Profession.Items.Count; i++)
                {
                    string personneInfo = LB_Profession.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idcat)
                    {
                        IndexDansLBIndividu = i;
                        break;
                    }
                }
                if (IndexDansLBIndividu != -1)
                {
                    LB_Profession.SelectedIndex = IndexDansLBIndividu;
                }
            }

            // On rempli les collections 
            try
            {
                int idliste;
                idliste = CB_Metier.SelectedIndex;
                LB_PersonnePCS.Items.Clear();
                lesPersonnesPCS.Clear();
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from personne, categorie_pcs where personne.idCat=" + idliste + " group by personne.id ;", "Erreur Reload personne");
                while (curseur.Read())
                {


                    lesPersonnesPCS.Add(new Personne()
                    {

                        Id = (int)curseur["id"],
                        Nom = (string)curseur["nom"],
                        Prenom = (string)curseur["prenom"],
                        IdProfession = (int)curseur["idCat"],



                    });

                    LB_PersonnePCS.Items.Clear();
                    foreach (Personne unePersonne in lesPersonnesPCS)
                        LB_PersonnePCS.Items.Add(unePersonne.ToString());

                }
                curseur.Close();
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur SelectMetier", ex.Message); }



        }




        #region Affichage des informations (Image Acte, Date, Lieu) et individus (Mariés, Témoins si existent) liés au mariage (Prevot Valentin)
        private void LB_Acte_SelectedIndexChanged(object sender, EventArgs e)
        {
            GestionInfoActes();//gestion des informations du mariage
            AfficherPhotoActe();//gestion de l'image d'acte du mariage
        }

        private void AfficherPhotoActe()
        {

                PB_Acte.Image = null;
            string NomImage = " ";


            try
            {
                cnx.Open();
                string sql = "SELECT image.nom FROM image, acte, detailimageacte  WHERE acte.id = detailimageacte.idacte AND image.id = detailimageacte.idimage AND acte.id =" + int.Parse(TXT_ActeId.Text) + "; ";
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string nomImage = reader["nom"].ToString();

                    NomImage = nomImage;

                }

                reader.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur LB_Actes_SelectedIndexChanged", ex.Message);
            }
            finally
            {
                if (cnx.State == ConnectionState.Open)
                {
                    cnx.Close();
                }
            }


            string cheminImage = Path.Combine("Resources", FRM_Graphic.SelectedDbName, "Images", NomImage + ".jpg");
            if (File.Exists(cheminImage))
            {
        
                PNL_ImageActe.Visible = true;
                Image image = Image.FromFile(cheminImage);
                PB_Acte.Image = image;
            }
            
        }
        private void GestionInfoActes()
        {
            {
                try
                {
                    int idmm = 0;
                    LB_Maries.Items.Clear();
                    lesMariagePCS.Clear();
                    cnx.Open();
                    int j = LB_Acte.SelectedIndex;
                    if (j != -1)
                    {
                        idmm = lesActes[j].Id;
                    }
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT personne.id, personne.nom, personne.prenom from acte, type_acte, type_individu, personne, liste_individu  WHERE acte.id = liste_individu.idActe AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu Between 3 and 4 AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND liste_individu.idActe =" + idmm + " group by personne.id ; ", "Erreur select personne");
                    while (curseur.Read())
                    {
                        lesMariagePCS.Add(new Personne()
                        {

                            Id = (int)curseur["id"],
                            Nom = (string)curseur["nom"],
                            Prenom = (string)curseur["prenom"]

                        });

                        LB_Maries.Items.Clear();
                        foreach (Personne unePersonne in lesMariagePCS)
                            LB_Maries.Items.Add(unePersonne.ToString());


                    }
                    curseur.Close();
                    cnx.Close();

                }

                catch (Exception ex) { MessageBox.Show("Erreur select mariage", ex.Message); cnx.Close(); }

                try
                {
                    int idmm = 0;
                    LB_Temoin.Items.Clear();
                    lesMariagePCS.Clear();
                    cnx.Open();
                    int h = LB_Acte.SelectedIndex;
                    if (h != -1)
                    {
                        idmm = lesActes[h].Id;
                    }
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT personne.id, personne.nom, personne.prenom from acte, type_acte, type_individu, personne, liste_individu  WHERE acte.id = liste_individu.idActe AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu = 5 AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND liste_individu.idActe =" + idmm + " group by personne.id ; ", "Erreur select personne");
                    while (curseur.Read())
                    {
                        lesMariagePCS.Add(new Personne()
                        {

                            Id = (int)curseur["id"],
                            Nom = (string)curseur["nom"],
                            Prenom = (string)curseur["prenom"],


                        });

                        LB_Temoin.Items.Clear();
                        foreach (Personne unePersonne in lesMariagePCS)
                            LB_Temoin.Items.Add(unePersonne.ToString());


                    }
                    curseur.Close();
                    cnx.Close();

                }

                catch (Exception ex) { MessageBox.Show("Erreur select mariage", ex.Message); cnx.Close(); }


                int k = LB_Acte.SelectedIndex;
                if (k != -1)
                {
                    TXT_ActeDate.Text = lesActes[k].DateActe.ToString("yyyy/MM/dd");
                    TXT_ActeLieu.Text = lesActes[k].IdVille.ToString();
                    TXT_ActeId.Text = lesActes[k].Id.ToString();

                }
                //Affiche les information stockée dans la collection des different actes dans le TXT_date et TXT_lieu
                try
                {
                    LB_Acte.Items.Clear();
                    lesActes.Clear();

                    int idmm = 0;
                    int j = LB_individu.SelectedIndex;
                    if (j != -1)
                    {
                        idmm = lesPersonnes[j].Id;
                    }
                    cnx.Open();

                    // SELECT des acte des indivus exepté les acte de mariage dont les individus sont témoins 
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT * from acte, type_acte, type_individu, personne, liste_individu  WHERE acte.id = liste_individu.idActe AND type_individu.id != 5 AND personne.id = liste_individu.idPersonne AND liste_individu.idTypeIndividu AND liste_individu.idTypeIndividu = type_individu.id AND acte.idTypeActe = type_acte.id AND personne.id=" + idmm + ";", "Erreur select personne");
                    while (curseur.Read())
                    {
                        lesActes.Add(new Acte() //Ajout des valeurs dans la collections
                        {
                            Id = (int)curseur["id"],
                            DateActe = ((DateTime)curseur["dateActe"]),
                            IdTypeActe = (int)curseur["idTypeActe"],
                            TypeActe = (string)curseur["nom"],
                            IdVille = (int)curseur["idVille"]
                        });

                    }
                    curseur.Close();
                    cnx.Close();
                }
                catch (Exception ex) { MessageBox.Show("Erreur select acte", ex.Message); }

                LB_Acte.Items.Clear();
                foreach (Acte unActe in lesActes)   // Affichage de la collection dans LB_Acte
                    LB_Acte.Items.Add(unActe.TypeActe);
            }
        }

        /*Sélection de l'individu dans LB_Individu quand selection d'un indivudu marié*/
        private void LB_Maries_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = LB_Maries.SelectedIndex;
            if (selectedIndex != -1)
            {
                string mariesInfo = LB_Maries.SelectedItem.ToString();

                string[] mariesInfos = mariesInfo.Split(' ');

                int idMaries = int.Parse(mariesInfos[0]);

                int IndexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idMaries)
                    {
                        IndexDansLBIndividu = i;
                        break;
                    }
                }
                if (IndexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = IndexDansLBIndividu;
                }
            }
        }

        /*Sélection de l'individu dans LB_Individu quand selection d'un indivudu témoin*/
        private void LB_Temoin_SelectedIndexChanged(object sender, EventArgs e)
        {

            int selectedIndex = LB_Temoin.SelectedIndex;
            if (selectedIndex != -1)
            {
                string temoinsInfo = LB_Temoin.SelectedItem.ToString();

                string[] temoinInfos = temoinsInfo.Split(' ');

                int idTemoins = int.Parse(temoinInfos[0]);

                int IndexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idTemoins)
                    {
                        IndexDansLBIndividu = i;
                        break;
                    }
                }
                if (IndexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = IndexDansLBIndividu;
                }
            }
        }
        #endregion


        private void LB_GrandsParents_SelectedIndexChanged(object sender, EventArgs e)
        {

            RazControles_Secondaire();
            int selectedIndex = LB_GrandsParents.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Récupère le parent sélectionné
                string GPparentInfo = LB_GrandsParents.SelectedItem.ToString();

                // Divise toutes les informations du parent
                string[] GPparentInfos = GPparentInfo.Split(' ');

                // L'id du parent est au début de la chaîne
                int idGPParent = int.Parse(GPparentInfos[0]);

                // Recherche l'indice du parent dans la ListBox LB_individu
                int indexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idGPParent)
                    {
                        indexDansLBIndividu = i;
                        break;
                    }
                }

                if (indexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = indexDansLBIndividu;
                }
            }

        }

        private void LB_Parents_SelectedIndexChanged(object sender, EventArgs e)
        {
            RazControles_Secondaire();
            int selectedIndex = LB_Parents.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Récupère le parent sélectionné
                string parentInfo = LB_Parents.SelectedItem.ToString();

                // Divise toutes les informations du parent
                string[] parentInfos = parentInfo.Split(' ');

                // L'id du parent est au début de la chaîne
                int idParent = int.Parse(parentInfos[0]);

                // Recherche l'indice du parent dans la ListBox LB_individu
                int indexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idParent)
                    {
                        indexDansLBIndividu = i;
                        break;
                    }
                }

                if (indexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = indexDansLBIndividu;
                }
            }
        }

        private void LB_OnclesTantes_SelectedIndexChanged(object sender, EventArgs e)
        {

            RazControles_Secondaire();
            int selectedIndex = LB_OnclesTantes.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Récupère le parent sélectionné
                string OncleTanteInfo = LB_OnclesTantes.SelectedItem.ToString();

                // Divise toutes les informations du parent
                string[] OncleTanteInfos = OncleTanteInfo.Split(' ');

                // L'id du parent est au début de la chaîne
                int idOncleTante = int.Parse(OncleTanteInfos[0]);

                // Recherche l'indice du parent dans la ListBox LB_individu
                int indexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idOncleTante)
                    {
                        indexDansLBIndividu = i;
                        break;
                    }
                }

                if (indexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = indexDansLBIndividu;
                }
            }
        }

        private void LB_Frere_SelectedIndexChanged(object sender, EventArgs e)
        {
            RazControles_Secondaire();
            int selectedIndex = LB_Frere.SelectedIndex;
            if (selectedIndex >= 0)
            {
                string nomComplet = LB_Frere.SelectedItem.ToString();
                SelectionnerIndividuDansLBIndividu(nomComplet);
            }
        }

        // Synchronisation de l'individus dans la lb_enfants dans la lb_individus (Achille)
        private void LB_Enfants_SelectedIndexChanged(object sender, EventArgs e)
        {
            RazControles_Secondaire();
            int selectedIndex = LB_Enfants.SelectedIndex;
            if (selectedIndex != -1)
            {
                // Récupérez l'enfant sélectionné
                string enfantInfo = LB_Enfants.SelectedItem.ToString();

                // Divisez la chaîne pour obtenir les différentes informations
                string[] enfantInfos = enfantInfo.Split(' ');

                // L'ID de l'enfant est au début de la chaîne
                int idEnfant = int.Parse(enfantInfos[0]);

                // Recherchez l'indice de l'enfant dans la ListBox LB_individu
                int indexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    // L'ID de la personne est au début de la chaîne
                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idEnfant)
                    {
                        indexDansLBIndividu = i;
                        break;
                    }
                }

                // Si l'indice est trouvé, mettez à jour les TextBox avec les informations de l'enfant
                if (indexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = indexDansLBIndividu; // Sélectionnez l'enfant dans LB_individu
                                                                     // Les TextBox seront automatiquement mis à jour grâce à l'événement LB_individu_SelectedIndexChanged
                }
            }
        }

        #endregion


        #region Gestion Afficher

        // Afficher enfant depuis la collection (Achille)
        private void AfficherEnfants(Personne individuSelectionne)
        {
            try
            {

                int id = individuSelectionne.Id;
                int idPere = individuSelectionne.IdPere;
                int idMere = individuSelectionne.IdMere;

                var enfants = lesPersonnes.Where(individu => individu.Id == idPere && individu.Id == idMere);



                foreach (Personne enfant in enfants)
                {
                    if (idPere != 0 && idMere != 0)
                    {
                        LB_Enfants.Items.Add(enfant.ToString());
                    }
                    if (id == 0)
                    {
                        LB_Enfants.Items.Clear();

                    }


                }
            }

            catch (Exception ex) { }
        }

        private void ChargerGrandsParents(Personne IndividuSelectionne)
        {
            LB_GrandsParents.Items.Clear();

            // Récupérez les ID du père et de la mère de la personne sélectionnée
            int idPere = IndividuSelectionne.IdPere;
            int idMere = IndividuSelectionne.IdMere;

            // Initialisez les ID des grands-parents à -1 (s'ils ne sont pas trouvés, ils resteront à -1)
            int idGpPaternite = -1; // Grand-père paternel
            int idGmPaternite = -1; // Grand-mère paternelle
            int idGpMaternite = -1; // Grand-père maternel
            int idGmMaternite = -1; // Grand-mère maternelle

            // Recherchez le père de l'individu sélectionné
            Personne pere = lesPersonnes.FirstOrDefault(individu => individu.Id == idPere);

            // Recherchez la mère de l'individu sélectionné
            Personne mere = lesPersonnes.FirstOrDefault(individu => individu.Id == idMere);

            // Si le père et la mère ont été trouvés, recherchez les grands-parents
            if (pere != null || mere != null)
            {
                // Recherchez le père du père (grand-père paternel)
                int? idPereDuPere = lesPersonnes.FirstOrDefault(individu => individu.Id == pere.IdPere)?.Id;
                idGpPaternite = idPereDuPere.GetValueOrDefault();

                // Recherchez la mère du père (grand-mère paternelle)
                int? idMereDuPere = lesPersonnes.FirstOrDefault(individu => individu.Id == pere.IdMere)?.Id;
                idGmPaternite = idMereDuPere.GetValueOrDefault();

                // Recherchez le père de la mère (grand-père maternel)
                int? idPereDeLaMere = lesPersonnes.FirstOrDefault(individu => individu.Id == mere.IdPere)?.Id;
                idGpMaternite = idPereDeLaMere.GetValueOrDefault();

                // Recherchez la mère de la mère (grand-mère maternelle)
                int? idMereDeLaMere = lesPersonnes.FirstOrDefault(individu => individu.Id == mere.IdMere)?.Id;
                idGmMaternite = idMereDeLaMere.GetValueOrDefault();
            }

            // Ajoutez les noms des grands-parents à la liste en vérifiant que leur ID n'est pas égal à 1
            if (idGpPaternite != -0 && idGpPaternite != 0)
            {
                Personne gpPaternite = lesPersonnes.FirstOrDefault(individu => individu.Id == idGpPaternite);
                if (gpPaternite != null)
                {
                    LB_GrandsParents.Items.Add($"{gpPaternite.Id} {gpPaternite.Nom} {gpPaternite.Prenom}");
                }
            }

            if (idGmPaternite != -0 && idGmPaternite != 0)
            {
                Personne gmPaternite = lesPersonnes.FirstOrDefault(individu => individu.Id == idGmPaternite);
                if (gmPaternite != null)
                {
                    LB_GrandsParents.Items.Add($"{gmPaternite.Id} {gmPaternite.Nom} {gmPaternite.Prenom}");
                }
            }

            if (idGpMaternite != -0 && idGpMaternite != 0)
            {
                Personne gpMaternite = lesPersonnes.FirstOrDefault(individu => individu.Id == idGpMaternite);
                if (gpMaternite != null)
                {
                    LB_GrandsParents.Items.Add($"{gpMaternite.Id} {gpMaternite.Nom} {gpMaternite.Prenom}");
                }
            }

            if (idGmMaternite != -0 && idGmMaternite != 0)
            {
                Personne gmMaternite = lesPersonnes.FirstOrDefault(individu => individu.Id == idGmMaternite);
                if (gmMaternite != null)
                {
                    LB_GrandsParents.Items.Add($"{gmMaternite.Id} {gmMaternite.Nom} {gmMaternite.Prenom}");
                }
            }
        }

        private void ChargerOncleTante(Personne IndividuSelectionne)
        {
            LB_OnclesTantes.Items.Clear();

            // Récupérez les ID du père et de la mère de la personne sélectionnée
            int idPere = IndividuSelectionne.IdPere;
            int idMere = IndividuSelectionne.IdMere;

            // Initialisez les ID des grands-parents à -1 (s'ils ne sont pas trouvés, ils resteront à -1)
            int idGpPaternite = -1; // Grand-père paternel
            int idGmPaternite = -1; // Grand-mère paternelle
            int idGpMaternite = -1; // Grand-père maternel
            int idGmMaternite = -1; // Grand-mère maternelle

            // Recherchez le père de l'individu sélectionné
            Personne pere = lesPersonnes.FirstOrDefault(individu => individu.Id == idPere);

            // Recherchez la mère de l'individu sélectionné
            Personne mere = lesPersonnes.FirstOrDefault(individu => individu.Id == idMere);

            // Si le père et la mère ont été trouvés, recherchez les grands-parents
            if (pere != null || mere != null)
            {
                // Recherchez le père du père (grand-père paternel)
                int? idPereDuPere = lesPersonnes.FirstOrDefault(individu => individu.Id == pere.IdPere)?.Id;
                idGpPaternite = idPereDuPere.GetValueOrDefault();

                // Recherchez la mère du père (grand-mère paternelle)
                int? idMereDuPere = lesPersonnes.FirstOrDefault(individu => individu.Id == pere.IdMere)?.Id;
                idGmPaternite = idMereDuPere.GetValueOrDefault();

                // Recherchez le père de la mère (grand-père maternel)
                int? idPereDeLaMere = lesPersonnes.FirstOrDefault(individu => individu.Id == mere.IdPere)?.Id;
                idGpMaternite = idPereDeLaMere.GetValueOrDefault();

                // Recherchez la mère de la mère (grand-mère maternelle)
                int? idMereDeLaMere = lesPersonnes.FirstOrDefault(individu => individu.Id == mere.IdMere)?.Id;
                idGmMaternite = idMereDeLaMere.GetValueOrDefault();
            }

            // Créez une liste pour stocker les oncles et les tantes
            List<string> OnclesTantes = new List<string>();

            // Parcourez la liste des individus pour trouver les oncles et les tantes
            foreach (Personne individu in lesPersonnes)
            {
                if (individu.Id != IndividuSelectionne.Id && individu.Id != idPere && individu.Id != idMere)
                {
                    // Vérifiez si l'individu a les mêmes grands-parents
                    if ((individu.IdPere == idGpPaternite && individu.IdMere == idGmPaternite) ||
                        (individu.IdPere == idGpMaternite && individu.IdMere == idGmMaternite))
                    {
                        // Vérifiez si le père et la mère de l'individu ne sont pas 1
                        if (individu.IdPere != 0 && individu.IdMere != 0)
                        {
                            // Ajoutez l'individu à la liste des oncles et tantes
                            OnclesTantes.Add($"{individu.Id} {individu.Nom} {individu.Prenom}");
                        }
                    }
                }
            }

            // Reste du code inchangé
            // Ajoutez les oncles et tantes à la ListBox
            foreach (string oncleTante in OnclesTantes)
            {
                LB_OnclesTantes.Items.Add($"{oncleTante}");
            }


        }

        private void AfficherFreresSoeurs(Personne individuSelectionne)
        {
            LB_Frere.Items.Clear();

            int idPere = individuSelectionne.IdPere;
            int idMere = individuSelectionne.IdMere;

            var freresSoeurs = lesPersonnes.Where(individu => (individu.IdPere == idPere || individu.IdMere == idMere) && individu.Id != individuSelectionne.Id);

            foreach (Personne frereSoeur in freresSoeurs)
            {
                if (idPere != 0 && idMere != 0)
                    LB_Frere.Items.Add(frereSoeur.ToString());
            }
        }



        private void SelectionnerIndividuDansLBIndividu(string nomComplet)
        {
            for (int i = 0; i < LB_individu.Items.Count; i++)
            {
                if (LB_individu.Items[i].ToString() == nomComplet)
                {
                    // Sélectionnez l'élément trouvé dans LB_individu.
                    LB_individu.SelectedIndex = i;
                    break;
                }
            }
        }

        private void AfficherParents(Personne personneSelectionne)
        {
            // je n'ai pas utilisé de requete sql pour que mon clic fonctionne sur les fichiers
            //fonction pour trouver et afficher les parents de la personne selectionné 
            LB_Parents.Items.Clear();

            int idPere = personneSelectionne.IdPere;
            int idMere = personneSelectionne.IdMere;

            //création de la variable pere qui permet d'obtenir l'information du pere de la personne 
            var pere = lesPersonnes.FirstOrDefault(personne => personne.Id == idPere);
            //création de la variable mere qui permet d'obtenir l'information de la mere de la personne 
            var mere = lesPersonnes.FirstOrDefault(personne => personne.Id == idMere);

            //condition pour remplir la list box si le pere est renseigné 
            if (pere != null)
            {
                if (idPere != 0)
                {
                    LB_Parents.Items.Add(pere.ToString());
                }
            }
            //condition pour remplir la list box si la mere est renseigné 
            if (mere != null)
            {
                if (idMere != 0)
                {
                    LB_Parents.Items.Add(mere.ToString());
                }

            }

        }

        #endregion

        #region Gestion des fonctions secondaires

        private int RetourneIdMax()
        {
            int max = 0;
            foreach (Personne laPersonne in lesPersonnes)
                if (laPersonne.Id > max) max = laPersonne.Id;
            return max;
        }

        /*  private string RechercherCommune(int id)
          {
              string nom = "";
              foreach (Commune uneCommune in lesCommunes)
                  if (uneCommune.Id == id) nom = uneCommune.Nom;
              return nom;
          }
        */

        private int RechercherCat(int id)
        {
            int idc = -1;
            foreach (Profession uneProfession in lesProfessions)
            {
                if (uneProfession.Id_cat == id)
                {
                    idc = uneProfession.Id_cat;
                    break;
                }
            }
            return idc;
            
        }

        private int RechercherIdIndi(int id)
        {
            int idc = 0;
            foreach (Personne unePersonne in lesPersonnes)
                if (unePersonne.Id == id) idc = unePersonne.Id;
            return idc;
        }




        private void RazControles()
        {
            LB_individu.Items.Clear(); LB_Profession.Items.Clear(); LB_Acte.Items.Clear(); LB_Maries.Items.Clear(); /*LB_AN_GrandsParents.Items.Clear()*/;
            LB_Enfants.Items.Clear(); LB_Frere.Items.Clear(); LB_GrandsParents.Items.Clear(); LB_OnclesTantes.Items.Clear(); LB_PersonnePCS.Items.Clear(); EffaceChamps();
        }
        private void RazControles_Secondaire()
        {
            LB_Acte.Items.Clear(); LB_Maries.Items.Clear(); LB_Temoin.Items.Clear(); TXT_ActeDate.Clear(); TXT_ActeLieu.Clear();
        }

        private void EffaceChamps()
        {
            TXT_Id.Clear();
            TXT_Nom.Clear();
            TXT_Prenom.Clear();
            TXT_IdPere.Clear();
            TXT_IdMere.Clear();
            TXT_Info.Clear();

        }
        private void SupprimerToutesLesDonneesDeLaBase()
        {
            try
            {
                cnx.Open();

                // Désactiver les contraintes de clé étrangère
                MySqlCommand disableForeignKeyChecksCommand = new MySqlCommand("SET FOREIGN_KEY_CHECKS = 0", cnx);
                disableForeignKeyChecksCommand.ExecuteNonQuery();

                // Supprimer toutes les données de la table 'personne'
                MySqlCommand deletePersonneCommand = new MySqlCommand("DELETE FROM personne", cnx);
                deletePersonneCommand.ExecuteNonQuery();

                // Réactiver les contraintes de clé étrangère
                MySqlCommand enableForeignKeyChecksCommand = new MySqlCommand("SET FOREIGN_KEY_CHECKS = 1", cnx);
                enableForeignKeyChecksCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression des données", ex.Message);
            }
            finally
            {
                cnx.Close(); // Fermer la connexion dans le bloc finally pour garantir qu'elle sera toujours fermée, même en cas d'exception.
            }

        }
        private void ViderCollection()
        {
            lesPersonnes.Clear();
            lesProfessions.Clear();
        }
        private void ViderLesListBox()
        {
            LB_individu.Items.Clear();
            LB_Profession.Items.Clear();
            LB_GrandsParents.Items.Clear();
            LB_Parents.Items.Clear();
            LB_OnclesTantes.Items.Clear();
            LB_Frere.Items.Clear();
            LB_Enfants.Items.Clear();
            LB_Acte.Items.Clear();
            LB_Temoin.Items.Clear();
            LB_Maries.Items.Clear();
            LB_ListeLieux.Items.Clear();
            LB_Profession.Items.Clear();
            LB_PersonnePCS.Items.Clear();
            LB_Anniv.Items.Clear();
        }
        private bool LesPersonnesContiennentId(int id) //Fonction utilisée quand on clique sur le bouton ajouter un individu, check si l'ID existe déjà pour éviter les doublons et les bugs d'ajout BDD
        {
            // Parcourir la collection pour vérifier si l'ID existe déjà
            foreach (Personne personne in lesPersonnes)
            {
                if (personne.Id == id)
                {
                    return true; // L'ID existe déjà dans la collection
                }
            }
            return false; // L'ID n'a pas été trouvé dans la collection
        }
        private bool LesLieuContiennentId(int id) //Fonction utilisée quand on clique sur le bouton ajouter un lieu
                                                  //, check si l'ID existe déjà pour éviter les doublons et les bugs d'ajout BDD
        {
            // Parcourir la collection pour vérifier si l'ID existe déjà
            foreach (Lieu lieu in lesLieu)
            {
                if (lieu.Idl == id)
                {
                    return true; // L'ID existe déjà dans la collection
                }
            }
            return false; // L'ID n'a pas été trouvé dans la collection
        }
        private void RemplirCollection()
        {
               try
                {
                    cnx.Open();
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from personne, categorie_pcs where personne.idCat = categorie_pcs.id order by personne.id  ;", "Erreur Reload personne");
                    while (curseur.Read())
                    {
                        lesPersonnes.Add(new Personne()
                        {

                            Id = (int)curseur["id"],
                            Nom = (string)curseur["nom"],
                            Prenom = (string)curseur["prenom"],
                            IdPere = (int)curseur["idPere"],
                            IdMere = (int)curseur["idMere"],
                            IdProfession = (int)curseur["idCat"],
                            Info = (string)curseur["infos"],

                        });
                    }
                    curseur.Close();
                    cnx.Close();
                }
                catch (Exception ex) { MessageBox.Show("Erreur Reload personne", ex.Message); cnx.Close(); }



                try
                {
                    cnx.Open();
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from categorie_pcs order by id ;", "Erreur Reload personne");
                    while (curseur.Read())
                    {
                        lesProfessions.Add(new Profession()
                        {
                            Id_cat = (int)curseur["id"],
                            Nom_cat = (string)curseur["nomcat"]
                        });
                    }
                    curseur.Close();
                    cnx.Close();
                }
                catch (Exception ex) { MessageBox.Show("Erreur Reload personne", ex.Message); cnx.Close(); }
                //ANNIVERSAIRE LB
                try
                {
                    cnx.Open();
                    MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "SELECT personne.id, personne.nom, personne.prenom, acte.dateActe, acte.idTypeActe\r\nFROM liste_individu AS li, personne, acte\r\nWHERE li.idPersonne = personne.id\r\nAND li.idActe = acte.id\r\nAND acte.idTypeActe = 1;", "Erreur Reload liste_individu");
                    while (curseur.Read())
                    {
                        lesAnniv.Add(new ListeIndividuAnniv()
                        {

                            IdPersonne = (int)curseur["id"],
                            NomPersonne = (string)curseur["nom"],
                            PrenomPersonne = (string)curseur["prenom"],
                            DateActe = ((DateTime)curseur["dateActe"]),



                        });
                    }
                    curseur.Close();


                    cnx.Close();
                }
                catch { cnx.Close(); }
           

        }

        private void ChargerCollection() //Charger collection depuis la BDD
        {
            ViderCollection();//Fonction qui permet de vider la collection pour ensuite la remplir
            RemplirCollection();
        }



        private void ChargerLB() //Charger la LB
        {
            LB_individu.Items.Clear();
            foreach (Personne unePersonne in lesPersonnes)
            {
                string formattePersonne = string.Format("{0,-6}\t{1,-20}\t{2,-20}",
                unePersonne.Id,
                unePersonne.Nom,
                unePersonne.Prenom);
                LB_individu.Items.Add(formattePersonne);
            } //Charge les personnes depuis la collection

            LB_Profession.Items.Clear();
            foreach (Profession uneProfession in lesProfessions)
                LB_Profession.Items.Add(uneProfession.ToString());//Charge le métier des personnes depuis la collection

            CB_Metier.Items.Clear();
            foreach (Profession uneProfession in lesProfessions)
                CB_Metier.Items.Add(uneProfession.ToString());//Charge le métier des personnes depuis la collection
            LB_Anniv.Items.Clear();

            foreach (ListeIndividuAnniv unAnniv in lesAnniv)
            {
                if (unAnniv.DateActe.Month == DateTime.Now.Month)
                {
                    string formattedAnniv = string.Format("{0, -5}\t{1, -20}\t{2, -20}\t{3:d}",
                    unAnniv.IdPersonne,
                    unAnniv.NomPersonne,
                    unAnniv.PrenomPersonne,
                    unAnniv.DateActe
                    );
                    LB_Anniv.Items.Add(formattedAnniv);
                }
            }
            LB_Anniv.Font = new Font(LB_Anniv.Font.FontFamily, 10);

        }

        private void Sauvergarder_Collection_Dans_BDD()
        {

            try
            {
                // Insérer les données de la collection 'lesPersonnes'
                foreach (Personne personne in lesPersonnes)
                {
                    try
                    {//on ajoute dans la table personne dans la BDD
                        int i = rq.Exec_SQL_MajDonneesPersonnes(cnx, "ajout_personne", personne.Id, personne.Nom, personne.Prenom, personne.IdPere, personne.IdMere, personne.IdProfession, personne.Info, "Erreur ajout personne");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout personne", ex.Message); }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'insertion des données", ex.Message);
            }

        }

        #endregion




        private void PNL_Familles_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TXT_Info_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void B_AjouterActe_Click(object sender, EventArgs e)
        {


            PNL_GestionActes.Visible = true;

            LB_GestionActeIndividu.Items.Clear(); //Charge les personnes depuis la collection
            foreach (Personne unePersonne in lesPersonnes)
                LB_GestionActeIndividu.Items.Add(unePersonne.ToString());

            LB_Marie1.Items.Clear(); //Charge les personnes depuis la collection
            foreach (Personne unePersonne in lesPersonnes)
                LB_Marie1.Items.Add(unePersonne.ToString());

            LB_Marie2.Items.Clear(); //Charge les personnes depuis la collection
            foreach (Personne unePersonne in lesPersonnes)
                LB_Marie2.Items.Add(unePersonne.ToString());




            try //CHARGE LES TYPES ACTES (NAISSANCE MORT MARIAGE)
            {
                cnx.Open();
                // récupérer les types d'actes
                MySqlCommand command = new MySqlCommand("SELECT nom FROM type_acte", cnx);
                // Exécutez la commande et obtenez un lecteur de données
                MySqlDataReader reader = command.ExecuteReader();
                LB_GestionActesChoix.Items.Clear();

                //ajouter  à la ListBox
                while (reader.Read())
                {
                    LB_GestionActesChoix.Items.Add(reader["nom"].ToString());
                }
                reader.Close();
                cnx.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message); cnx.Close();
            }
            finally
            {
                cnx.Close();
            }

            //AJOUTER LES TYPEINDIVIDU à LA COLLECTION TYPEINDIVIDU
            try
            {
                lesTypeIndividu.Clear();
                cnx.Open();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from type_individu order by id ;", "Erreur type individu load");
                while (curseur.Read())
                {
                    lesTypeIndividu.Add(new TypeIndividu()
                    {
                        Id_TypeIndividu = (int)curseur["id"],
                        Nom_TypeIndividu = (string)curseur["nom"]
                    });
                }
                curseur.Close();
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur Reload personne", ex.Message); cnx.Close(); }
            //AJOUTER LA COLLECTION TYPE INIDIVIDU à LA COMBOBOX
            CB_GestionActeTypeIndividu.Items.Clear();
            foreach (TypeIndividu lesTypeIndividu in lesTypeIndividu)
                CB_GestionActeTypeIndividu.Items.Add(lesTypeIndividu.ToString());//Charge le métier des personnes depuis la collection
        }

        private void B_GestionPNLActesFermer_Click(object sender, EventArgs e)
        {
            PNL_GestionActes.Visible = false;
            PNL_GesMariage.Visible = false;
            PNL_GestLieux.Visible = false;
        }

        private void B_GestionActesAjouter_Click(object sender, EventArgs e)
        {

        }

        private void FRM_Accueil_Load(object sender, EventArgs e)
        {
            // design de la barre d'en tête (Achille)
            this.WindowState = FormWindowState.Maximized;
            this.Text = "<Echap : retour page precedente>, <F2 : Afficher arbre>, <F3 : Charger Arbre> , <F4 : Date Lieux>, <F7 : Capture d'ecran de L'arbre>, <F8 : imprimer arbre>, <BS : Racine precedente>, <PP : Ascendant Paternel>, <PN : ascendant Maternel>.";
            // Ecrasement du fichier capture de l'arbre (Valentin.Prevot)
            string pdfFileName = "captures.pdf";
            if (File.Exists(pdfFileName))
            {
                File.Delete(pdfFileName);
            }

        }

        private void B_SauvergardeFichier_Click(object sender, EventArgs e)
        {
            try
            {

                #region Chemin enregistrement de fichier 
                Global gbp = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "individus");
                Global gbpPCS = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "individuspcs");
                Global gbc = new Global(Application.StartupPath, "\\", "Resources \\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "professions");
                Global gbco = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Personnes\\", "individuspcsffr");
                Global gba = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Actes\\", "individuspcs");
                Global gblmPCS = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "MariagePCS\\", "individuspcs");
                Global gbl = new Global(Application.StartupPath, "\\", "Resources\\", FRM_Graphic.SelectedDbName + "\\", "Lieu\\", "individuspcs");
                #endregion

                BinaryFormatter formatter = new BinaryFormatter();


                FileStream fs = new FileStream(gbp.ToString(), FileMode.Create, FileAccess.Write);
                formatter.Serialize(fs, lesPersonnes);
                fs.Close();

                /*FileStream fs2 = new FileStream(gbi.ToString(), FileMode.Create, FileAccess.Write);
                formatter.Serialize(fs2, lesImages);
                fs2.Close();*/
            }
            catch (Exception ex) { MessageBox.Show("Erreur B_SelectPersonne_Click" + ex.ToString()); }
        }

        private void B_Imprimer_Click(object sender, EventArgs e)
        {
            // Créez une instance de PrintDocument
            PrintDocument printDocument = new PrintDocument();

            // Abonnez-vous à l'événement PrintPage pour définir le contenu à imprimer
            printDocument.PrintPage += new PrintPageEventHandler(ImprimerGraphisme_PrintPage);

            // Capturez le contenu du formulaire dans un Bitmap
            captureFormImage = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(captureFormImage, new Rectangle(0, 0, this.Width, this.Height));

            // Affichez la boîte de dialogue d'impression pour permettre à l'utilisateur de sélectionner une imprimante
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                // Imprimez le document
                printDocument.Print();
            }
        }
        private void ImprimerGraphisme_PrintPage(object sender, PrintPageEventArgs e)
        {

            // Dessinez le contenu du bitmap (graphisme du formulaire) sur la page d'impression
            e.Graphics.DrawImage(captureFormImage, 0, 0, e.PageBounds.Width, e.PageBounds.Height);

        }

        #region AJOUT D'UN EVENEMENT (Naissance, Décès, Naissance) DANS LA BASE DE DONNEES (Prevot Valentin, Benjamin, Mathéo)
        private void B_GestionActesAjouter_Click_1(object sender, EventArgs e)
        {
            PNL_GesMariage.Visible = false;
            PNL_GestionActes.Visible = false;
            int idMaxActe = 0; // Initialisez idMaxActe à une valeur par défaut, par exemple 0.

            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT MAX(id) FROM acte", cnx);
                object result = cmd.ExecuteScalar(); // Utilisez ExecuteScalar pour obtenir la valeur maximale.

                if (result != DBNull.Value)
                {
                    idMaxActe = Convert.ToInt32(result);
                }

                cnx.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur Reload lieu", ex.Message);
                cnx.Close();
            }

            if (LB_GestionActesChoix.SelectedIndex != 2)//Effectue l'ajout d'un acte pour déces ou naissance 
            {
                try
                {

                    try
                    {
                        int i = rq.Exec_SQL_MajDonneesActes(cnx, "ajout_acte", idMaxActe + 1, DTP_Date.Value, LB_GestionActesChoix.SelectedIndex + 1, int.Parse(TXT_GestionActeLieuID.Text), "Erreur ajout Acte");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout acte deces ou naissance", ex.Message); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'insertion des données", ex.Message);
                }

                try
                {

                    try
                    {
                        int i = rq.Exec_SQL_MajDonneesListe_Individu(cnx, "ajout_liste_individu", int.Parse(TXT_Id.Text), idMaxActe + 1, LB_GestionActesChoix.SelectedIndex + 1, "Erreur ajout individu");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout_liste_individu deces ou naissance", ex.Message); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'insertion des données", ex.Message);
                }
            }

            else//Effectue l'ajout d'un acte de mariage dans la table acte et liste_individu pour 2 personnes différentes (Prevot Valentin)
            {
                try
                {

                    try
                    {
                        int i = rq.Exec_SQL_MajDonneesActes(cnx, "ajout_acte", idMaxActe + 1, DTP_Date.Value, LB_GestionActesChoix.SelectedIndex + 1, int.Parse(TXT_GestionActeLieuID.Text), "Erreur ajout Acte");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout acte mariage", ex.Message); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'insertion des données", ex.Message);
                }

                try
                {

                    try //Insertion Marié 1
                    {
                        int i = rq.Exec_SQL_MajDonneesListe_Individu(cnx, "ajout_liste_individu", idmari1, idMaxActe + 1, 3, "Erreur ajout marié");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout marié 1", ex.Message); }
                    try //Insertion Mariée 2
                    {
                        int i = rq.Exec_SQL_MajDonneesListe_Individu(cnx, "ajout_liste_individu", idmari2, idMaxActe + 1, 4, "Erreur ajout mariée");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout marié 2", ex.Message); }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'insertion des données", ex.Message);
                }
            }

        }

        private void LB_Marie1_SelectedIndexChanged(object sender, EventArgs e)//stockage de l'id de la personne séléctionner pour insertion évènement mariage
        {
            int i = LB_Marie1.SelectedIndex;
            if (i != -1)
            {
                idmari1 = lesPersonnes[i].Id;


            }

        }
        public void LB_Marie2_SelectedIndexChanged(object sender, EventArgs e)//stockage de l'id de la personne séléctionner pour insertion évènement mariage
        {
            int i = LB_Marie2.SelectedIndex;
            if (i != -1)
            {
                idmari2 = lesPersonnes[i].Id;


            }
        }

        #endregion

        private void LB_GestionActeIndividu_SelectedIndexChanged(object sender, EventArgs e)
        {
            //insertion des personnes dans la LB_GestionActeIndividu
            int i = LB_GestionActeIndividu.SelectedIndex;
            if (i != -1)
            {
                LB_individu.SelectedIndex = i;
            }
            if (i != -1)
            {
                TXT_Id.Text = lesPersonnes[i].Id.ToString();
                TXT_Nom.Text = lesPersonnes[i].Nom;
                TXT_Prenom.Text = lesPersonnes[i].Prenom;
                CB_Metier.SelectedIndex = RechercherCat(lesPersonnes[i].IdProfession);
                TXT_IdPere.Text = lesPersonnes[i].IdPere.ToString();
                TXT_IdMere.Text = lesPersonnes[i].IdMere.ToString();
                TXT_Info.Text = lesPersonnes[i].Info.ToString();
            }
        }

        private void B_GestionActesModifier_Click(object sender, EventArgs e)
        {

        }


        private void LB_GestionActesChoix_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LB_GestionActesChoix_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (LB_GestionActesChoix.SelectedIndex == 2) //MARIAGE
            {
                PNL_GesMariage.Visible = true;
                LB_GestionActeIndividu.Visible = false;
                CB_GestionActeTypeIndividu.Enabled = true;
            }
            else//SI PAS MARIAGE
            {
                PNL_GesMariage.Visible = false;
                LB_GestionActeIndividu.Visible = true;
            }

            if (LB_GestionActesChoix.SelectedIndex == 1 || LB_GestionActesChoix.SelectedIndex == 0)//DECES OU NAISSANCE
            {
                if (LB_GestionActesChoix.SelectedIndex == 1)//DECES
                {
                    CB_GestionActeTypeIndividu.SelectedIndex = 1;
                    CB_GestionActeTypeIndividu.Enabled = false;
                }
                else
                {
                    CB_GestionActeTypeIndividu.SelectedIndex = 0;//NAISSANCE
                    CB_GestionActeTypeIndividu.Enabled = false;
                }
            }

        }

        private void B_FermerGesMariage_Click(object sender, EventArgs e)
        {
            PNL_GesMariage.Visible = false;
        }




        private void LBL_Marie1_Click(object sender, EventArgs e)
        {

        }

        private void PB_individu_Click(object sender, EventArgs e)
        {

        }

        private void LB_Frere_SelectedIndexChanged_1(object sender, EventArgs e)
        {

            RazControles_Secondaire();
            int selectedIndex = LB_Frere.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Récupère le parent sélectionné
                string FrereInfo = LB_Frere.SelectedItem.ToString();

                // Divise toutes les informations du parent
                string[] FrereInfos = FrereInfo.Split(' ');

                // L'id du parent est au début de la chaîne
                int idFrere = int.Parse(FrereInfos[0]);

                // Recherche l'indice du parent dans la ListBox LB_individu
                int indexDansLBIndividu = -1;
                for (int i = 0; i < LB_individu.Items.Count; i++)
                {
                    string personneInfo = LB_individu.Items[i].ToString();
                    string[] personneInfos = personneInfo.Split(' ');

                    int idPersonne = int.Parse(personneInfos[0]);

                    if (idPersonne == idFrere)
                    {
                        indexDansLBIndividu = i;
                        break;
                    }
                }

                if (indexDansLBIndividu != -1)
                {
                    LB_individu.SelectedIndex = indexDansLBIndividu;
                }
            }

        }

        private void GPX_Lieux_Enter(object sender, EventArgs e)
        {

        }

        int idmari1 = 0;

        

        private void B_MenuSelectionFamille_Click(object sender, EventArgs e)
        {
            // Créez une instance du formulaire d'accueil
            FRM_Graphic frmGraphic = new FRM_Graphic();


            // Affichez le formulaire d'accueil
            frmGraphic.Show();

            // Cachez le formulaire actuel (FRM_Graphic) si nécessaire
            this.Hide();
        }

        private void GPX_Individu_Enter(object sender, EventArgs e)
        {

        }

        //section gestion des lieux
        private void B_ChargerLieux_Click(object sender, EventArgs e)
        {
            //Charger les collections
            ChargerCollectionLieu();
            ChargerCollectionDep();
            ChargerCollectionPays();
            //charger les listbox
            ChargerLB_Lieu();
            ChargerLB_LieuGest();

        }
        private void ChargerCollectionLieu() //Charger collection lieu depuis la BDD
        {
            try
            {

                cnx.Close();
                cnx.Open(); //ouvre la connexion a la base
                lesLieu.Clear();//clear la collection
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from lieu order by ville_id  ;", "Erreur Reload lieu");//requete pour selectionner les données
                while (curseur.Read())
                {
                    lesLieu.Add(new Lieu()//ajout dans la collection des données
                    {

                        Idl = (int)curseur["ville_id"],
                        Vn = (string)curseur["ville_slug"],
                        Vd_id = (string)curseur["ville_departement"],
                        Vp_id = (int)curseur["ville_pays"]
                    });
                }
                curseur.Close();
                cnx.Close();//ferme la connexion
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur Reload lieu", ex.Message);

            }

        }
        private void ChargerCollectionDep() //Charger collection Departement depuis la BDD (se référer a la fonction de chargement des lieux
        {
            try
            {

                cnx.Open();
                lesDepartement.Clear();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from departements order by departement_id  ;", "Erreur Reload lieu");
                while (curseur.Read())
                {
                    lesDepartement.Add(new Departement()
                    {

                        Idd = (string)curseur["departement_code"],
                        Dn = (string)curseur["departement_nom"],

                    });
                }
                curseur.Close();
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur Reload lieu", ex.Message); }

        }
        private void ChargerCollectionPays() //Charger collection Pays depuis la BDD (se référer a la fonction de chargement des lieux
        {
            try
            {
                cnx.Open();
                lesPays.Clear();
                MySqlDataReader curseur = rq.Exec_SQL_ExtractionDeDonnees(cnx, "Select * from pays order by id_pays  ;", "Erreur Reload lieu");
                while (curseur.Read())
                {
                    lesPays.Add(new Pays()
                    {

                        id_p = (int)curseur["id_pays"],
                        nom_p = (string)curseur["fr"],

                    });
                }
                curseur.Close();
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur Reload lieu", ex.Message); }

        }
        private void ChargerLB_Lieu() //Charger la LBLieux
        {
            LB_ListeLieux.Items.Clear();
            foreach (Lieu unLieu in lesLieu)
                LB_ListeLieux.Items.Add(unLieu.Vn); //Charge les lieux depuis la collection


            // charger les collections de gestion d'id

            LB_GestionId.Items.Clear();
            foreach (Lieu unLieu in lesLieu)
                LB_GestionId.Items.Add(unLieu.Vn);


            LB_GestionIdDep.Items.Clear();
            foreach (Departement unDepartement in lesDepartement)
                LB_GestionIdDep.Items.Add(unDepartement.Dn);


            LB_GestionIdPays.Items.Clear();
            foreach (Pays unPays in lesPays)
                LB_GestionIdPays.Items.Add(unPays.nom_p);
        }

        private void ChargerLB_LieuGest() //Charger la LBLieuxGestion
        {
            LB_GesCom.Items.Clear();
            LB_GesDep.Items.Clear();
            LB_GesPays.Items.Clear();
            foreach (Lieu unLieu in lesLieu)
                LB_GesCom.Items.Add(unLieu.Vn); //Charge les lieux depuis la collection
            foreach (Departement unDepartement in lesDepartement)
                LB_GesDep.Items.Add(unDepartement.Dn);
            foreach (Pays unPays in lesPays)
                LB_GesPays.Items.Add(unPays.nom_p);



        }

        private void TXT_sl_TextChanged(object sender, EventArgs e)
        {
            //fonction permettant d'isoler un item dans une liste en fonction de ce qui est écrit dans la textebox

            string searchText = TXT_sl.Text.Trim();

            LB_ListeLieux.Items.Clear();

            foreach (Lieu lieu in lesLieu)

                if (lieu.Vn.ToLower().Contains(searchText.ToLower()))
                {
                    LB_ListeLieux.Items.Add(lieu.Vn.ToString());
                }
            //A chaque itération , toute la liste va etre scanner , pour vérifié si les items correspondent au text dans la textbox
        }

        private void LBL_sl_Click(object sender, EventArgs e)
        {

        }

        private void LBL_Tdep_Click(object sender, EventArgs e)
        {

        }


        private void LB_ListeLieux_SelectedIndexChanged(object sender, EventArgs e)
        {


            TXT_GestionActesLieu.Text = LB_ListeLieux.SelectedItem.ToString();

            //selectionne l'id pour afficher le département et/ou le pays de la ville séléctionnée

            string lieuSaisi = LB_ListeLieux.SelectedItem.ToString(); //récupére le nom du lieu saisi

            LB_GestionId.SelectedItem = lieuSaisi; //selectionne dans la listebox de gestion , l'item dont le nom correspond au lieu saisi

            int lieuId = LB_GestionId.SelectedIndex; // récupéré l'index de l'item séléctionné pour en faire une idée et ainsi l'id du lieu

            int DepId = int.Parse(lesLieu[lieuId].Vd_id); //récupère l'id du département grace a l'id du lieu précedement acquise

            TXT_Departements.Text = lesDepartement[DepId].Dn.ToString();// Récupère et affiche le nom du département dans la collection grace a l'id obtenu précédement

            int PaysId = lesLieu[lieuId].Vp_id; // récupère l'id du pays dans la collection grace a l'id lieu
            TXT_ShowPays.Text = lesPays[PaysId].nom_p.ToString();// Récupère et affiche le nom du département dans la collection grace a l'id obtenu précédement









            //AFFICHER ID DE LA VILLE
            if (LB_ListeLieux.SelectedItem != null) // Vérifiez si un élément est sélectionné
            {
                string selectedVilleNom = LB_ListeLieux.SelectedItem.ToString();

                // Recherche de l'ID correspondant dans la collection lesLieu
                int villeId = lesLieu.FirstOrDefault(lieu => lieu.Vn == selectedVilleNom)?.Idl ?? -1;

                if (villeId != -1)
                {
                    TXT_GestionActeLieuID.Text = villeId.ToString();
                }
                else
                {
                    // Gérez le cas où l'ID n'est pas trouvé (peut-être afficher un message d'erreur)
                    TXT_GestionActeLieuID.Text = string.Empty; // Effacez le texte de la TextBox
                }
            }
            else
            {
                // Gérez le cas où aucun élément n'est sélectionné
                TXT_GestionActeLieuID.Text = string.Empty; // Effacez le texte de la TextBox
            }

        }



        private void B_GestionLieux_Click(object sender, EventArgs e)
        {
            //permet d'empecher l'utilisateur de toucher A la gestion des département si Le pays france n'est pas séléctionné
            PNL_GestLieux.Visible = true;

            TXT_AddDep.Enabled = false;
            LB_GesDep.Enabled = false;
            LBL_DepGes.Enabled = false;
        }

        private void B_Croix2_Click(object sender, EventArgs e) // ferme la panel de gestion des lieux
        {
            PNL_GestLieux.Visible = false;
        }

        private void B_depvisible_Click(object sender, EventArgs e)
        //permet d'activer la gestion des departement lorsque france est sélctionné
        {
            TXT_AddPays.Text = "France";
            TXT_AddDep.Enabled = true;
            LB_GesDep.Enabled = true;
            LBL_DepGes.Enabled = true;
        }
        private void TXT_AddCom_TextChanged(object sender, EventArgs e)
        {
            //la fonction permet de facilité la recherche d'une ville dans la listebox , et permet a l'utilisateur de vérifié si celle ci existe déjà

            string searchText = TXT_AddCom.Text.Trim();

            LB_GesCom.Items.Clear();

            foreach (Lieu lieu in lesLieu) // se référé à TXT_sl_TextChanged

                if (lieu.Vn.ToLower().Contains(searchText.ToLower()))
                {
                    LB_GesCom.Items.Add(lieu.Vn.ToString());
                }

        }

        private void TXT_AddPays_TextChanged(object sender, EventArgs e)
        {
            //permet de vérifié que France soit écrit , pour annulé l'accès a la gestion des départements
            string france = "France";

            if (TXT_AddDep.Text == france)
            {
                TXT_AddDep.Enabled = true;
                LB_GesDep.Enabled = true;

                LBL_DepGes.Visible = true;


            }
            else
            {
                TXT_AddDep.Enabled = false;
                LB_GesDep.Enabled = false;
                TXT_AddDep.Text = "NO_DEPARTMENT";



            }
            // se référé à TXT_sl_TextChanged
            string searchText = TXT_AddPays.Text.Trim();

            LB_GesPays.Items.Clear();

            foreach (Pays pays in lesPays)

                if (pays.nom_p.ToLower().Contains(searchText.ToLower()))
                {
                    LB_GesPays.Items.Add(pays.nom_p.ToString());
                }


        }



        private void TXT_AddDep_TextChanged(object sender, EventArgs e)
        {
            // se référé à TXT_sl_TextChanged

            string searchText = TXT_AddDep.Text.Trim();

            LB_GesDep.Items.Clear();


            foreach (Departement departement in lesDepartement)

                if (departement.Dn.ToLower().Contains(searchText.ToLower()))
                {
                    LB_GesDep.Items.Add(departement.Dn.ToString());
                }
        }

        private void LB_GesCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            //selectionne l'item dans la liste box et le place dans le text box
            TXT_AddCom.Text = LB_GesCom.SelectedItem.ToString();
        }

        private void LB_GesPays_SelectedIndexChanged(object sender, EventArgs e)
        {
            //selectionne l'item dans la liste box et le place dans le text box
            TXT_AddPays.Text = LB_GesPays.SelectedItem.ToString();

        }

        private void LB_GesDep_SelectedIndexChanged(object sender, EventArgs e)
        {
            //selectionne l'item dans la liste box et le place dans le text box
            TXT_AddDep.Text = LB_GesDep.SelectedItem.ToString();
        }
        private void B_InsertLieuxCommune_Click(object sender, EventArgs e)
        {
            //permet de vérifié le dernier index de la base et ainsi s'assuré qu'il n'existe pas en ajoutant +1
            int lastItemId = LB_GestionId.Items.Count + 2;
            TXT_IdGestLast.Text = lastItemId.ToString();


            LB_GestionIdDep.SelectedItem = TXT_AddDep.Text;
            int depId = LB_GestionIdDep.SelectedIndex;

            LB_GestionIdPays.SelectedItem = TXT_AddPays.Text;

            int PaysId = LB_GestionIdPays.SelectedIndex;

            try
            {


                // Vérifier si l'ID existe déjà dans la collection avant d'insérer la personne
                if (LesLieuContiennentId(lastItemId))
                {
                    MessageBox.Show("L'ID du lieu existe déjà dans la collection, insertion impossible.");
                    return; // Sortir de la méthode si l'ID existe déjà
                }

                try //Si l'ID n'existe pas, c'est bon, on ajoute la personne dans la collection
                {

                    if (TXT_AddPays.Text != "")
                    {


                        lesLieu.Add(new Lieu() //collection regroupant la totalité des villes  qui seront afficher dans la listebox
                        {
                            Idl = lastItemId,
                            Vn = TXT_AddCom.Text,
                            Vd_id = depId.ToString(),
                            Vp_id = PaysId

                        });
                        //collection de tout les ajouts fait durant la session 

                        lesLieuActuelle.Add(new Lieu_session_actuelle()
                        {
                            Idl = lastItemId,
                            Vn = TXT_AddCom.Text,
                            Vd_id = depId.ToString(),
                            Vp_id = PaysId

                        });
                        //recharger les listbox

                        ChargerLB_Lieu();
                        ChargerLB_LieuGest();
                        //clear les textbox
                        TXT_AddPays.Clear();
                        TXT_AddDep.Clear();
                        TXT_AddCom.Clear();
                        TXT_AddDep.Text = "NO_DEPARTMENT";
                    }
                    else
                    {
                        MessageBox.Show("Aucun pays n'est séléctionée");
                    }
                }
                catch
                {
                    MessageBox.Show("Erreur lors de l'ajout du lieu : ");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du lieu: " + ex.Message);
            }


        }

        private void B_InsertLieu_Click(object sender, EventArgs e)
        {
            // SupprimerToutesLesDonneesLieuDeLaBase();
            Sauvergarder_Collection_Dans_BDDLieu();
            lesLieuActuelle.Clear();
        }
        private void Sauvergarder_Collection_Dans_BDDLieu()
        {

            try
            {
                cnx.Open();


                // Désactiver les contraintes de clé étrangère
                MySqlCommand disableForeignKeyChecksCommand = new MySqlCommand("SET FOREIGN_KEY_CHECKS = 0", cnx);
                disableForeignKeyChecksCommand.ExecuteNonQuery();


                foreach (Lieu_session_actuelle lieuS in lesLieuActuelle)

                {

                    try
                    {//on ajoute dans la table lieu dans la BDD
                        int i = rq.Exec_SQL_MajDonneeslieu(cnx, "ajout_lieu", lieuS.Idl, lieuS.Vn, lieuS.Vd_id, lieuS.Vp_id, "Erreur ajout lieu");

                        MessageBox.Show("ville ajouté avec succées !!");
                    }
                    catch (Exception ex) { MessageBox.Show("Erreur ajout lieu", ex.Message); }
                }


                // Réactiver les contraintes de clé étrangère
                MySqlCommand enableForeignKeyChecksCommand = new MySqlCommand("SET FOREIGN_KEY_CHECKS = 1", cnx);
                enableForeignKeyChecksCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

            }

            finally
            {
                cnx.Close(); // Fermer la connexion dans le bloc finally pour garantir qu'elle sera toujours fermée, même en cas d'exception.
            }
        }
        //fin section gestion des lieux


        private void FRM_Accueil_KeyDown(object sender, KeyEventArgs e)
        {
            if (LB_individu.SelectedIndex >= 0)//SI UN INDIVIDU EST SELECTIONNE dans la LB_Individu
            {
                EventArgs ea = new EventArgs();//ALORS OUVRE ARBRE GENEALOGIQUE
                if (!e.Alt)
                {
                    switch (e.KeyCode)
                    {
                        case Keys.F2: Arbre ecran = new Arbre(lesPersonnes, LB_individu.SelectedIndex,cnx); DialogResult dr = ecran.ShowDialog(); break;
                    }
                }
            }
            else//SINON, MESSAGE SELECTIONNER UNE PERSONNE
            {
            }


        }

        private void B_Arbre_Click(object sender, EventArgs e)
        {
            if (LB_individu.SelectedIndex >= 0)//SI UN INDIVIDU EST SELECTIONNE dans la LB_Individu
            {
                Arbre ecran = new Arbre(lesPersonnes, LB_individu.SelectedIndex, cnx) ; DialogResult dr = ecran.ShowDialog();//ALORS OUVRE ARBRE GENEALOGIQUE
            }
            else//SINON, MESSAGE SELECTIONNER UNE PERSONNE
            {
            }
        }

        private void FRM_Accueil_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Demandez à l'application de se fermer
            System.Windows.Forms.Application.Exit();
        }

        private void LBL_Frere_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void B_memepcs_Click(object sender, EventArgs e)
        {
            LB_PersonnePCS.Visible = true;
            B_memepcs.Visible = false;
            B_masquerpcs.Visible = true;
        }

        private void B_masquerpcs_Click(object sender, EventArgs e)
        {
            LB_PersonnePCS.Visible = false;
            B_memepcs.Visible = true;
            B_masquerpcs.Visible = false;
        }

        private void TXT_IdMere_TextChanged(object sender, EventArgs e)
        {

        }

        private void B_Close_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void LB_imageInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void GPX_GesActes_Enter(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        int idmari2 = 0;
        

       

        private void PNL_ImageActe_Paint(object sender, PaintEventArgs e)
        {

        }
        private void AjouterPersonneBase()
        {
            int idmetier = CB_Metier.SelectedIndex;
            try
            {//on ajoute dans la table personne dans la BDD
                int i = rq.Exec_SQL_MajDonneesPersonnes(cnx, "ajout_personne", int.Parse(TXT_Id.Text), TXT_Nom.Text, TXT_Prenom.Text, int.Parse(TXT_IdPere.Text), int.Parse(TXT_IdMere.Text), idmetier, TXT_Info.Text, "Erreur ajout personne");
            }
            catch (Exception ex) { MessageBox.Show("Erreur ajout personne", ex.Message); }
        }

        private void ModifierPersonneBase()
        {
            int idmetier = CB_Metier.SelectedIndex;
            try
            {//on modifie la table personne dans la BDD
                int i = rq.Exec_SQL_MajDonneesPersonnes(cnx, "modif_personne", int.Parse(TXT_Id.Text), TXT_Nom.Text, TXT_Prenom.Text, int.Parse(TXT_IdPere.Text), int.Parse(TXT_IdMere.Text), idmetier, TXT_Info.Text, "Erreur ajout personne");
            }
            catch (Exception ex) { MessageBox.Show("Erreur ajout personne", ex.Message); }
        }
        private void SupprimerPersonneBase()
        {
            int idmetier = CB_Metier.SelectedIndex;
            try
            {//on supprime dans la table personne dans la BDD
                int i = rq.Exec_SQL_MajDonneesPersonnes(cnx, "suppression_personne", int.Parse(TXT_Id.Text), TXT_Nom.Text, TXT_Prenom.Text, int.Parse(TXT_IdPere.Text), int.Parse(TXT_IdMere.Text), idmetier, TXT_Info.Text, "Erreur ajout personne");
            }
            catch (Exception ex) { MessageBox.Show("Erreur ajout personne", ex.Message); }
        }

        private void B_AddBDD_Click(object sender, EventArgs e)//AJOUTE BASE + COLLECTION EN MEME TEMPS
        {

            AjouterPersonneBase();

            AjouterPersonneCollection();
        }  

        private void B_ModifBDD_Click(object sender, EventArgs e)
        {
            ModifierPersonneBase();

            ModifierCollectionPersonne();

        }

        private void B_DeleteBDD_Click(object sender, EventArgs e)
        {
            SupprimerPersonneBase();

            SupprimerPersonneCollection();
        }
    }

    //fin section gestion des lieux
}

