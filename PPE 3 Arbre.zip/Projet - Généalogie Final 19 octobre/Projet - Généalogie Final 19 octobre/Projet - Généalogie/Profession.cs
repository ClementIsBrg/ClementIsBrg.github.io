﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    internal class Profession
    {
        public int Id_cat { get; set; }
        public string Nom_cat { get; set; }


        public Profession(int id, string nom)
        {
            Id_cat = id;
            Nom_cat = nom;
        }

        public Profession() : this(0, "no_name") { }
        public override string ToString()
        {
            return Id_cat + " " + Nom_cat;
        }

    }
}
