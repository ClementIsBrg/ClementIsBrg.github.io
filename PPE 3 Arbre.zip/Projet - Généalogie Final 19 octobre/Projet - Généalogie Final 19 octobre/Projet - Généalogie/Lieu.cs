﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    /// <summary>
    /// Class <c>Personne</c> Créer la classe Personne - Hugo 
    /// </summary>
    [Serializable]
    internal class Lieu
    {
        public int Idl { get; set; }
        public string Vn { get; set; }

        public string Vd_id { get; set; }

        public int Vp_id { get; set; }



        public Lieu(int ville_id, string ville_nom, string ville_departement, int ville_pays)
        {
            Idl = ville_id;
            Vn = ville_nom;
            Vd_id = ville_departement;
            Vp_id = ville_pays;
        }
        public Lieu() : this(0, "no_name", "no_id", 0) { }
        public override string ToString()
        {
            return Idl + "" + Vn + "" + Vd_id + "" + Vp_id;
        }

    }

}
