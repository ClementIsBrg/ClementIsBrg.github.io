﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    /// <summary>
    /// Class <c>Personne</c> Créer la classe Personne - Hugo 
    /// </summary>
    [Serializable]
    internal class Departement
    {
        public string Idd { get; set; }


        public string Dn { get; set; }


        public Departement(string departement_code, string departement_nom)
        {
            Idd = departement_code;
            Dn = departement_nom;
        }
        public Departement() : this("no_departement_id", "no_departement") { }
        public override string ToString()
        {
            return Idd + "" + Dn;
        }

    }

}
