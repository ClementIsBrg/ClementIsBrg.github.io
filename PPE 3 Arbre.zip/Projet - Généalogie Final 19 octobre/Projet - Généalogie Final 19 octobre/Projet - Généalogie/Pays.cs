﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    /// <summary>
    /// Class <c>Personne</c> Créer la classe Personne - Hugo 
    /// </summary>
    [Serializable]
    internal class Pays
    {
        public int id_p { get; set; }
        public string nom_p { get; set; }




        public Pays(int id_pays, string fr)
        {
            id_p = id_pays;
            nom_p = fr;

        }
        public Pays() : this(0, "no_name") { }
        public override string ToString()
        {
            return id_p + "" + nom_p;
        }

    }

}
