﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace GestionDErreurs
{
    unsafe public partial class MessagePopup : Form
    {
        private Font font = new Font("Cooper Black", 12);
        private Font miniFont = new Font("Cooper Black", 10);
        private Font maxiFont = new Font("Cooper Black", 16);
        private Brush fontBrushR = Brushes.Red;
        private Brush fontBrushA = Brushes.Aquamarine;
        private Brush fontBrushB = Brushes.BlueViolet;
        private Brush fontBrushBl = Brushes.Black;
        private Brush fontBrushB2 = Brushes.DeepPink;
        private int xtext = 25;
        private int ytext = 0;
        private int xdeb;
        private int ydeb;
        private int hauteur;
        private int largeur;
        private static int WEcran = Screen.PrimaryScreen.Bounds.Width;
        private static int HEcran = Screen.PrimaryScreen.Bounds.Height;

        public bool flag;
        private string nomclass;
        private string nomfonction;
        private string message;
        private string errsyst;

 
        protected override void WndProc(ref Message m) //permet de déplacer la fenêtre
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if (m.Result == (IntPtr)1) m.Result = (IntPtr)2;
                    break;
                default: base.WndProc(ref m); break;

            }
        }

        public MessagePopup(bool* f, string nc, string nf, string m, string e) 
        {   
            InitializeComponent(); 
            flag = *f; nomclass = nc; nomfonction = nf; message = m; errsyst = e;
            //System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            //gp.AddEllipse(50, 50, 240, 315);           
            //this.Region = new System.Drawing.Region(gp);
        }

        private void MessagePopup_Load(object sender, EventArgs e)
        {
            hauteur = PNL_Fenetre.Height;
            largeur = PNL_Fenetre.Width;
            xdeb = (int)(WEcran - largeur / 2);
            ydeb = (int)(HEcran - hauteur / 2) ;          
            //PNL_Fenetre.Location = new Point(xdeb, ydeb);
            PNL_Fenetre.Location = new Point(50, 50);
            if (flag)
            {
                //GBX_Boutons.Location = new Point(xdeb + (int)(largeur / 2), ydeb + hauteur + 10); 
                //GBX_Boutons.Location = new Point(10, 10);
                //GBX_Boutons.Visible = true;
                B_Annuler.Visible = true;
                B_Valider.Visible = true;
            }
            else TMR_Popup.Start();
        }

        private void TMR_Popup_Tick(object sender, EventArgs e) {TMR_Popup.Stop();Close();}

        private void PNL_Fenetre_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            e.Graphics.DrawString("Class " + nomclass, maxiFont, fontBrushR, xtext, ytext );
            e.Graphics.DrawString("Fonction " + nomfonction , font, fontBrushA, xtext , ytext += 40);
            e.Graphics.DrawString(message, miniFont, fontBrushB2, xtext, ytext += 95);
            e.Graphics.DrawString("<echap> pour fermer l'aide", miniFont, fontBrushBl, largeur-200, hauteur - 20);
            DecoupeTexte(errsyst, e);
        }
        private void Accueil_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape: Close(); break;
            }
        }

        private void DecoupeTexte(string s, PaintEventArgs e)
        {
            DecoupeLigneTexte(s, ' ', e);
        }

        private void DecoupeLigneTexte(string s, char separateur, PaintEventArgs e)
        {
            string[] t;
            t = s.Split(separateur); int i = 0;
            for (; i < t.Length; )
            {
                s = "";
                do
                {
                    if (t[i].Length > 45) DecoupeLigneTexte(t[i], '\\', e);
                    else
                        if ((s + separateur + t[i]).Length > 45) ;
                        else s = s + separateur + t[i];
                    i++;
                } while ((s.Length < 45) && (i < t.Length) && ((s + separateur + t[i]).Length < 45));

                e.Graphics.DrawString(s, miniFont, fontBrushB, xtext, ytext += 15);
            }
        }


        private void B_Valider_Click(object sender, EventArgs e) { flag = true; Close(); }
        private void B_Valider_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            System.Drawing.Rectangle newRectangle = B_Valider.ClientRectangle;
            newRectangle.Inflate(-7, -7);
            e.Graphics.DrawEllipse(System.Drawing.Pens.Transparent, newRectangle);
            gp.AddEllipse(newRectangle);
            B_Valider.Region = new System.Drawing.Region(gp);
        }

        private void B_Annuler_Click(object sender, EventArgs e) { flag = false; Close(); }
        private void B_Annuler_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            System.Drawing.Rectangle newRectangle = B_Annuler.ClientRectangle;
            newRectangle.Inflate(-7, -7);
            e.Graphics.DrawEllipse(System.Drawing.Pens.Transparent, newRectangle);
            gp.AddEllipse(newRectangle);
            B_Annuler.Region = new System.Drawing.Region(gp);
        }

    }
}
