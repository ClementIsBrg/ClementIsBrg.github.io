﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet___Généalogie
{
    /// <summary>
    /// Class <c>Personne</c> Créer la classe Personne - Hugo 
    /// </summary>
    [Serializable]
    public class Personne
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }

        public int IdPere { get; set; }
        public int IdMere { get; set; }
        public int IdProfession { get; set; }
       

        public string Info { get; set; }


        public Personne(int id, string nom, string prenom,  int idpere, int idmere, int idprofession, string info)
        {
            Id = id;
            Nom = nom;
            Prenom = prenom;
            IdPere = idpere;
            IdMere = idmere;
            IdProfession = idprofession;
           
            Info = info;
        }
        public Personne() : this(0, "no_name", "no_surname",0, 0, 0,"Pas_d_info") { }
        public override string ToString()
        {
            return Id + " " + Nom + " " + Prenom ;
        }

    }

}
