﻿using System;

namespace Projet___Généalogie
{
    [Serializable]
    public class CelluleEntier
    {
        private string element;
        private CelluleEntier pere;
        private CelluleEntier mere;
        public CelluleEntier(string e, CelluleEntier p, CelluleEntier m) { element = e; pere = p; mere = m; }
        public string AccesElement() { return element; }
        public CelluleEntier AccesSuivantPere() { return pere; }
        public CelluleEntier AccesSuivantMere() { return mere; }
        public void ModifierPere(CelluleEntier nouveauptr) { pere = nouveauptr; }
        public void ModifierMere(CelluleEntier nouveauptr) { mere = nouveauptr; }
    }

    [Serializable]
    public class CelluleEntier2
    {
        private string element;
        private CelluleEntier2 suiv;
        public CelluleEntier2(string e, CelluleEntier2 p) { element = e; suiv = p; }
        public string AccesElement() { return element; }
        public CelluleEntier2 AccesSuivant() { return suiv; }
        public void Modifier(CelluleEntier2 nouveauptr) { suiv = nouveauptr; }
    }
}
