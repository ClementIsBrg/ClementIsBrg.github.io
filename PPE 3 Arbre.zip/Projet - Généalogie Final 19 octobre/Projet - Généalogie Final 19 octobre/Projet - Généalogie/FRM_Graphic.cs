﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;


namespace Projet___Généalogie
{
    public partial class FRM_Graphic : Form
    {
        private Graphics g;
        private Font font2 = new Font("Cooper Black", 12);
        private static int WEcran = Screen.PrimaryScreen.Bounds.Width;
        private Brush fontBrushW = Brushes.White;
        private Brush fontBrushB = Brushes.Black;
        private Point P = new Point(0, 0);
        private static string chemin;
        private static Bitmap ArbreGenealogique;
        public List<string> listeNomsDeBDD = new List<string>();
        private string appDirectory; //Variable d'environnement
        private string resourcesDirectory; //Chemin complet pour aller chercher le nom des fichiers des familles
        private List<Rectangle> lesRectangles = new List<Rectangle>();
        private Region myRegion = new Region();
        private GraphicsPath gp;
        private Point p = new Point(0, 0);

        //public car utilisé par les autres formulaires
        public static string SelectedDbName;//nom de la BDD    
        public static string chaineConnexion;// définition de la chaine de connexion nécessaire pour accéder à la base Mysql
        //public car utilisé par les autres formulaires

        public FRM_Graphic()
        {
            InitializeComponent();

            g = CreateGraphics(); // Créez un Graphics pour dessiner sur le formulaire                

            LoadFamilyNames();// Charger les noms de famille

            InitListeCoordonnees();//Initialise les coordonnées des rectangles
        }


        private void LoadFamilyNames()
        {

            appDirectory = Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath);//VARIABLE D'ENVIRONNEMENT
            resourcesDirectory = Path.Combine(appDirectory, "Resources");//VARIABLE D'ENVIRONNEMENT + "Resources"

            chemin = resourcesDirectory;
            ArbreGenealogique = new Bitmap(Path.Combine(chemin, "ArbreG.png"));//CHARGE L'IMAGE ArbreG.png dans le chemin combiné de la variable d'environnement + "resources"    

            if (Directory.Exists(resourcesDirectory))//Si le fichier FAMILLE existe, ajouter le fichier à une liste de string contenant le nom des fichiers
            {
                string[] familyDirectories = Directory.GetDirectories(resourcesDirectory);

                foreach (string familyDirectory in familyDirectories)
                {
                    string familyName = Path.GetFileName(familyDirectory);//Prend le nom du fichier
                    listeNomsDeBDD.Add(familyName);//Ajoute le nom du fichier à la liste de string
                }
            }


        }


        private void FRM_Graphic_Paint(object sender, PaintEventArgs e)
        {
            g.Clear(Color.LemonChiffon);
            g.DrawImage(ArbreGenealogique, P);//AFFICHE l'image de fond de l'arbre (ArbreGenealogique = image et P = position X et Y instanciées tout en haut)

            DessineRectangle();//fonction qui dessine chaque rectangle aux coordonnées renseignées
        }




        private void FRM_Graphic_MouseMove(object sender, MouseEventArgs e)
        {
            //Code pour dessiner le rectangle des coordonnées en haut à gauche du FRM_Graphic
            g.FillRectangle(Brushes.LemonChiffon, new Rectangle(WEcran - 120, 0, 100, 20));
            g.DrawString(e.X + "  *  " + e.Y, font2, fontBrushB, WEcran - 120, 0);
        }

        private void FRM_Graphic_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void FRM_Graphic_MouseDown(object sender, MouseEventArgs e)//Fonction quand on clique avec la souris (que le clic d'enfoncement, pas le relachement du clic)
        {
            int i = 0;
            p = new Point(e.X, e.Y);
            foreach (Rectangle unRectangle in lesRectangles)
            {
                gp = new GraphicsPath();
                gp.AddEllipse(unRectangle);//Ajoute un Ellipse de la même longueur que le rectangle
                myRegion = new Region(gp);
                if (myRegion.IsVisible(p))
                {
                    int index = lesRectangles.IndexOf(unRectangle);
                    if (index >= 0 && index < listeNomsDeBDD.Count)
                    {
                        string selectedDbName = listeNomsDeBDD[index];
                        SelectedDbName = selectedDbName;


                        FRM_Accueil frmAccueilInstance = new FRM_Accueil();//Créer une instance du FRM_Accueil


                        if (VerifierConnexionBaseDonnees())//Fonction qui vérifie si la base existe
                        {
                            frmAccueilInstance.Show();//Si la BDD existe, lancer le Formulaire Accueil
                            this.Hide();//Cacher le formulaire actuel (FRM_Graphic)
                        }
                        else
                        {                    //Message si la base n'existe pas, rester sur FRM_Graphic
                            MessageBox.Show("La connexion à la base de données a échoué. Cette base n'existe pas.");
                        }
                        break;
                    }
                }
                i++;
            }
        }

        private void FRM_Graphic_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Demandez à l'application de se fermer
            System.Windows.Forms.Application.Exit();

        }

        private void InitListeCoordonnees() //3Dessine les rectangles autour
        {
            lesRectangles.Add(new Rectangle(380, 877, 192, 95));//Exemple : 380 = X pos, 877 = Y pos, 192 = longueur, 95 = hauteur
            lesRectangles.Add(new Rectangle(210, 783, 192, 95));
            lesRectangles.Add(new Rectangle(172, 635, 192, 95));
            lesRectangles.Add(new Rectangle(172, 490, 192, 95));
            lesRectangles.Add(new Rectangle(249, 346, 192, 95));
            lesRectangles.Add(new Rectangle(346, 198, 192, 95));
            lesRectangles.Add(new Rectangle(540, 97, 192, 95));
            lesRectangles.Add(new Rectangle(812, 30, 192, 95));
            lesRectangles.Add(new Rectangle(1085, 96, 192, 95));
            lesRectangles.Add(new Rectangle(1278, 218, 192, 95));
            lesRectangles.Add(new Rectangle(1419, 346, 192, 95));
            lesRectangles.Add(new Rectangle(1517, 491, 192, 95));
            lesRectangles.Add(new Rectangle(1548, 661, 192, 95));
            lesRectangles.Add(new Rectangle(1504, 781, 192, 95));
            //  lesRectangles.Add(new Rectangle(1310, 871, 192, 95));
        }

        private void DessineRectangle()
        {                                   //.Count = nombre d'éléments dans listeNomsDeBDD
            for (int i = 0; i < listeNomsDeBDD.Count; i++)
            {
                Rectangle unRectangle = lesRectangles[i]; // Récupère le rectangle correspondant à l'indice i
                                                          //g.DrawRectangle(pen, new Rectangle(unRectangle.X, unRectangle.Y, unRectangle.Width, unRectangle.Height));
                                                          //g.DrawEllipse(pen, new Rectangle(unRectangle.X, unRectangle.Y, unRectangle.Width, unRectangle.Height));
                g.DrawString(listeNomsDeBDD[i], font2, fontBrushW, new Point(unRectangle.X + 10, unRectangle.Y + 38));
            }
        }

        private bool VerifierConnexionBaseDonnees()
        {
            bool connexionReussie = false;
            //Créer une chaine de connexion avec le nom de la BDD choisie dans le menu
            chaineConnexion = "Data Source=localhost;Database=" + SelectedDbName + "; User Id=root; Password=";

            using (MySqlConnection connection = new MySqlConnection(chaineConnexion))
            {
                try //TESTER si la BDD choisie existe en tentant une connexion
                {
                    connection.Open();
                    connexionReussie = true;
                    connection.Close();
                }
                catch (MySqlException) //Sinon La base n'existe pas
                {
                    connexionReussie = false;
                }
            }

            return connexionReussie;//Nécessaire car la fonction est un boolean, il faut retourner une valeur true ou false
        }

    }
}