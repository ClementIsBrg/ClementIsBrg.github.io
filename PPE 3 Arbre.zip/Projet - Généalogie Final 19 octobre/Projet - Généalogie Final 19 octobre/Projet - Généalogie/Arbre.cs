﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp;
using MySql.Data.MySqlClient;

namespace Projet___Généalogie
{
    public partial class Arbre : Form
    {
        private int[,] grille;
        private string[,] arbre;
        private Pen pen = new Pen(Brushes.Salmon);
        int aquiletour = 0;
        private Graphics g;
        private ListeChainee lc = new ListeChainee();
        int indice;
        private List<Personne> lesPersonnes = new List<Personne>();
        private List<Commune> lesCommunes = new List<Commune>();
        private List<Acte> lesActes = new List<Acte>();
        private Font font1 = new Font("Cooper Black", 10);
        private Font font2 = new Font("Cooper Black", 10);
        private Font font3 = new Font("Cooper Black", 10);
        private Brush fontBrushB = Brushes.Black;
        private Brush fontBrushR = Brushes.Salmon;
        private static int WEcran = Screen.PrimaryScreen.Bounds.Width;
        private static int HEcran = Screen.PrimaryScreen.Bounds.Height;
        private int Xdeb = 0;
        private int Ydeb = 50;
        private Point p = new Point(0, 0);
        private Point p1 = new Point(0, 50);
        KeyEventArgs touche;
        private static int ind_individu;// = gb.numeroindividu;
        private static int ind_pere; //= RechercheID(ind_individu.ToString());
        private static int ind_mere;// = RechercheID(ind_individu.ToString());
        private int TailleCaseI = (2 * 175);
        private int TailleCaseJ = 16;
        private int NbLigne = 64;
        private int NbColonne = 13;
        private bool afficherID = false;
        private bool affichernom = false;

        private static MySqlConnection cnx = new MySqlConnection(FRM_Graphic.chaineConnexion);



        public Arbre(List<Personne> lesP, int ind, MySqlConnection c)
        {
            InitializeComponent(); lesPersonnes = lesP; indice = ind; cnx = c; InitGrille(); InitArbre();
            ind_pere = RechercheID(lesPersonnes[indice].IdPere);
            ind_mere = RechercheID(lesPersonnes[indice].IdMere); ind_individu = ind_pere;

        }

        private void Arbre_MouseMove(object sender, MouseEventArgs e)
        {
            g.FillRectangle(Brushes.Ivory, new Rectangle(WEcran - 100, 0, 100, 20));
            g.DrawString(e.X + "  *  " + e.Y, font2, fontBrushB, WEcran - 100, 0);
            g.DrawString(WEcran + "  *  " + HEcran, font2, fontBrushR, WEcran - 200, 0);

        }
        private void Arbre_MouseClick(object sender, MouseEventArgs e)
        {
            int CaseDebutI = (int)(e.X / TailleCaseI);
            int CaseDebutJ = (int)((e.Y - Ydeb) / TailleCaseJ);

            if ((CaseDebutJ < NbLigne) && (CaseDebutI < NbColonne) && (CaseDebutJ >= 0) && (CaseDebutI >= 0) && arbre[CaseDebutJ, CaseDebutI] != "")
            {
                int clickedIndividu = int.Parse(arbre[CaseDebutJ, CaseDebutI]);

                // Créez un nouvel formulaire Arbre pour l'individu cliqué
                Arbre nouvelArbre = new Arbre(lesPersonnes, clickedIndividu, cnx);
                nouvelArbre.Show();

                AfficheArbre();
                EnchaineArbre();
                AfficheArbre(0, afficherID);
            }

        }






        private void Arbre_Load(object sender, EventArgs e)
        {
            g = CreateGraphics();
            lc.InitialiseListe(indice.ToString());

            // Ajoutez le code pour afficher l'arbre de la personne sélectionnée (ind_individu)
            EnchaineArbre();
            AfficheArbre(0, afficherID);
        }

        private void AfficheMenu()
        {
            string s;
            int x = Xdeb + 6, y = HEcran - 207, step_y = 20, largeur = 275, hauteur = 165, step_x = 2;
            g.Clear(Color.Ivory);
            pen.Width = 8.0F;
            pen.LineJoin = System.Drawing.Drawing2D.LineJoin.Bevel;
            if (aquiletour == 0)
                s = "Arbre ascendant paternel de ";
            else
                s = "Arbre ascendant maternel de ";
            g.DrawString(s + lesPersonnes[indice].Prenom + " " + lesPersonnes[indice].Nom + " (ID : " + lesPersonnes[indice].Id + ")", font1, fontBrushR, p);
            g.DrawRectangle(pen, new Rectangle(Xdeb + 4, HEcran - 210, 435, 200));
            g.DrawString("<ESC> écran précédent", font1, fontBrushB, new PointF(x, y));
            g.DrawString("<F7> capture d'écran", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<F8> imprimer les différentes captures d'écrans", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<F1> arbre des indices", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<F4> Active / Désactive Dates Lieux", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<F3> arbre des noms", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<BS> racine précédente", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<PP> ascendants paternels", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<PN> ascendants maternels", font1, fontBrushB, new PointF(x, y += step_y));
            g.DrawString("<Impr> impression arbre", font1, fontBrushB, new PointF(x, y += step_y));
        }

        private void Arbre_Paint(object sender, PaintEventArgs e) { g.Clear(Color.LemonChiffon); AfficheMenu(); }

        private void Arbre_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F1) || (e.KeyCode == Keys.F2) || (e.KeyCode == Keys.F3) || (e.KeyCode == Keys.F4)) { aquiletour = 0; ChoixTouchesFonctions(e); touche = e; }
            else
                switch (e.KeyCode)
                {
                    case Keys.Escape: Close(); break; //ferme la partie et affiche le menu
                    case Keys.Back:
                        if ((!lc.EstVide()) && (lc.tete.AccesSuivant() != null))
                        {
                            lc.SupprimerTete();
                            if (lc.tete != null) indice = int.Parse(lc.RetourneElementTete());//ind_individu
                            ChoixTouchesFonctions(touche);
                        }
                        break;
                    case Keys.PageDown: ind_individu = ind_mere; lc.InitialiseListe(ind_individu.ToString()); aquiletour = 1; ChoixTouchesFonctions(touche); break;
                    case Keys.PageUp: ind_individu = ind_pere; lc.InitialiseListe(ind_individu.ToString()); aquiletour = 0; ChoixTouchesFonctions(touche); break;
                    case Keys.F7: AjouterCapturesAuPDF(); break;
                    case Keys.F8: ImprimerFichierPDF(); break;
                }

        }
        private void ChoixTouchesFonctions(KeyEventArgs key)
        {
            switch (key.KeyCode)
            {
                case Keys.F1: EnchaineArbre(); AfficheArbre(0, afficherID); break;
                case Keys.F2: EnchaineArbre(); AfficheArbre(1, afficherID); break;
                case Keys.F3:
                    EnchaineArbre();
                    afficherID = !afficherID;
                    AfficheArbre(afficherID ? 1 : 0, afficherID); // Afficher l'ID si l'option est activée
                    break;
                case Keys.F4:
                    if (affichernom == false)
                        affichernom = true;
                    else
                        affichernom = false;
                    EnchaineArbre(); AfficheArbre(afficherID ? 1 : 0, afficherID); break; // Afficher l'ID si l'option est activée
            }
        }
        #region FONCTION CAPTURES ET IMPRESSION DE L'ARBRE AVEC UN FICHIER PDF (Valentin Prevot)
        private void ImprimerPDF(string pdfFileName)
        {
            try
            {
                // Ouvrez le fichier PDF avec le lecteur PDF par défaut et imprimez-le
                Process.Start(pdfFileName);
            }
            catch (Exception ex)
            {
                // Gérez les erreurs d'impression ici
                Console.WriteLine("Erreur lors de l'impression du PDF : " + ex.Message);
            }
        }


        private void ImprimerFichierPDF()// Utilisez cette fonction pour imprimer votre fichier PDF
        {
            string pdfFileName = "captures.pdf"; // Remplacez par le nom de votre fichier PDF
            ImprimerPDF(pdfFileName);
        }

        private void AjouterCapturesAuPDF()//Permet d'ajouter des captures d'écrans au fichier captures.pdf
        {
            // Capturez l'écran
            Bitmap captureScreen = CaptureScreen(); // Fonction pour capturer l'écran 



            // Créez un nouveau document PDF
            PdfDocument document = new PdfDocument();

            // Si le fichier PDF existant, copiez ses pages dans le nouveau document
            if (System.IO.File.Exists("captures.pdf"))
            {
                PdfDocument existingDocument = PdfReader.Open("captures.pdf", PdfDocumentOpenMode.Import);
                foreach (PdfPage page in existingDocument.Pages)
                {
                    document.AddPage(page);
                }
            }

            // Ajoutez une nouvelle page pour la capture d'écran
            PdfPage newPage = document.AddPage();
            newPage.Orientation = PageOrientation.Landscape;
            XGraphics gfx = XGraphics.FromPdfPage(newPage);

            // Convertissez la capture d'écran en un objet MemoryStream
            using (MemoryStream ms = new MemoryStream())
            {
                captureScreen.Save(ms, ImageFormat.Png);
                XImage image = XImage.FromStream(ms);

                // Dessinez l'image sur la nouvelle page PDF
                gfx.DrawImage(image, 0, 0, newPage.Width, newPage.Height);
            }

            // Enregistrez le document PDF
            document.Save("captures.pdf");
            document.Close();
            MessageBox.Show("Vous avez pris une capture d'écran.");

        }

        private Bitmap CaptureScreen()//Permet d'effectuer une capture d'ecran
        {
            // Capturez l'écran complet
            Rectangle screenBounds = Screen.PrimaryScreen.Bounds;
            Bitmap screenshot = new Bitmap(screenBounds.Width, screenBounds.Height);

            using (Graphics g = Graphics.FromImage(screenshot))
            {
                g.CopyFromScreen(screenBounds.Location, Point.Empty, screenBounds.Size);
            }

            return screenshot;
        }

        #endregion

        private void EnchaineArbre()
        {
            InitArbre();
            InitGrille();
            ContruireArbre(ind_individu, grille, arbre, 0);//ind_individu
        }
        private void ContruireArbre(int id, int[,] grille, string[,] arbre, int j) //parcours profondeur préfixe
        {
            int i = 0; int a = 0;
            if (lesPersonnes[id].Id == 0)
            {
                for (i = 0; ((i < grille.GetLength(0)) && (j < grille.GetLength(1)) && (grille[i, j] != 0)); i++) ;
                if ((i < grille.GetLength(0)) && (j < grille.GetLength(1))) { grille[i, j] = -1; arbre[i, j] = "0"; }
                j--;
                return;
            }
            for (i = 0; ((i < grille.GetLength(0)) && (j < grille.GetLength(1)) && (grille[i, j] != 0)); i++) ;
            if ((i < grille.GetLength(0)) && (j < grille.GetLength(1))) { grille[i, j] = -1; arbre[i, j] = id.ToString(); }
            j++;
            ContruireArbre(RechercheID(lesPersonnes[id].IdPere), grille, arbre, j);
            ContruireArbre(RechercheID(lesPersonnes[id].IdMere), grille, arbre, j);
        }
        private void AfficheArbre(int choix, bool afficherID)
        {
            ReinitP1();
            AfficheMenu();
            AfficheArcs();
            for (int i = 0; i < NbLigne; i++)
            {
                p1.Y = (i * TailleCaseJ) + Ydeb;
                for (int j = 0; j < NbColonne; j++)
                {
                    if (arbre[i, j] != "")
                    {
                        p1.X = (j * TailleCaseI) + Xdeb;
                        if (arbre[i, j] != "0")
                        {
                            int personneID = int.Parse(arbre[i, j]);
                            Personne personne = lesPersonnes[personneID];

                            string nomPrenom = personne.Nom + " " + personne.Prenom;
                            g.DrawString(nomPrenom, font2, fontBrushB, p1.X + 45, p1.Y);
                            if (affichernom == true)
                            {

                                #region lieu et date NS/DC

                                Acte acte = new Acte();

                                Commune commune = new Commune();

                                // recuperer la date de naissance de l'individu
                                if (acte != null)
                                {


                                    string dateActe = string.Empty;

                                    if (personne != null)
                                    {
                                        string query = "SELECT DATE_FORMAT(A.dateActe, '%d-%m-%Y') " +
                                                       "FROM liste_individu AS LI " +
                                                       "INNER JOIN acte AS A ON LI.idActe = A.id " +
                                                       "INNER JOIN personne AS P ON LI.idPersonne = P.id " +
                                                       "WHERE LI.idPersonne = @PersonneID AND A.idTypeActe = 1 ";

                                        using (MySqlConnection cnx = new MySqlConnection(FRM_Graphic.chaineConnexion))
                                        {
                                            cnx.Open();

                                            using (MySqlCommand cmd = new MySqlCommand(query, cnx))
                                            {
                                                cmd.Parameters.AddWithValue("@PersonneID", personne.Id);
                                                object result = cmd.ExecuteScalar();

                                                if (result != null)
                                                {
                                                    dateActe = result.ToString();
                                                }
                                            }
                                        }
                                    }

                                    g.DrawString(dateActe, font2, fontBrushB, p1.X, p1.Y + 20);
                                }

                                // recuperer la date de décès de l'individu
                                if (acte != null)
                                {


                                    string dateActe = string.Empty;

                                    if (personne != null)
                                    {
                                        string query = "SELECT DATE_FORMAT(A.dateActe, '%d-%m-%Y') " +
                                                       "FROM liste_individu AS LI " +
                                                       "INNER JOIN acte AS A ON LI.idActe = A.id " +
                                                       "INNER JOIN personne AS P ON LI.idPersonne = P.id " +
                                                       "WHERE LI.idPersonne = @PersonneID AND A.idTypeActe = 2 ";

                                        using (MySqlConnection cnx = new MySqlConnection(FRM_Graphic.chaineConnexion))
                                        {
                                            cnx.Open();

                                            using (MySqlCommand cmd = new MySqlCommand(query, cnx))
                                            {
                                                cmd.Parameters.AddWithValue("@PersonneID", personne.Id);
                                                object result = cmd.ExecuteScalar();

                                                if (result != null)
                                                {
                                                    dateActe = result.ToString();
                                                }
                                            }
                                        }
                                    }

                                    g.DrawString(dateActe, font2, fontBrushB, p1.X, p1.Y + 40);
                                }

                                // afficher la commune de naissance
                                if (commune != null)
                                {


                                    string communeNS = string.Empty;

                                    if (personne != null)
                                    {
                                        string query = "SELECT lieu.ville_slug AS CommuneNaissance FROM personne INNER JOIN liste_individu ON personne.id = liste_individu.idPersonne INNER JOIN acte ON liste_individu.idActe = acte.id INNER JOIN type_acte ON acte.idTypeActe = type_acte.id INNER JOIN lieu ON acte.idVille = lieu.ville_id WHERE personne.id = @PersonneID and idTypeActe=1;";

                                        using (MySqlConnection cnx = new MySqlConnection(FRM_Graphic.chaineConnexion))
                                        {
                                            cnx.Open();

                                            using (MySqlCommand cmd = new MySqlCommand(query, cnx))
                                            {
                                                cmd.Parameters.AddWithValue("@PersonneID", personne.Id);
                                                object result = cmd.ExecuteScalar();

                                                if (result != null)
                                                {
                                                    communeNS = result.ToString();
                                                }
                                            }
                                        }
                                    }

                                    g.DrawString(communeNS, font2, fontBrushB, p1.X + 100, p1.Y + 20);
                                }
                                // afficher la commune de décès
                                if (commune != null)
                                {


                                    string communeDC = string.Empty;

                                    if (personne != null)
                                    {
                                        string query = "SELECT lieu.ville_slug AS CommuneNaissance FROM personne INNER JOIN liste_individu ON personne.id = liste_individu.idPersonne INNER JOIN acte ON liste_individu.idActe = acte.id INNER JOIN type_acte ON acte.idTypeActe = type_acte.id INNER JOIN lieu ON acte.idVille = lieu.ville_id WHERE personne.id = @PersonneID and idTypeActe=2;";

                                        using (MySqlConnection cnx = new MySqlConnection(FRM_Graphic.chaineConnexion))
                                        {
                                            cnx.Open();

                                            using (MySqlCommand cmd = new MySqlCommand(query, cnx))
                                            {
                                                cmd.Parameters.AddWithValue("@PersonneID", personne.Id);
                                                object result = cmd.ExecuteScalar();

                                                if (result != null)
                                                {
                                                    communeDC = result.ToString();
                                                }
                                            }
                                        }
                                    }

                                    g.DrawString(communeDC, font2, fontBrushB, p1.X + 100, p1.Y + 40);
                                }
                                #endregion

                            }
                            if (afficherID) // Afficher l'ID 
                            {
                                g.DrawString((personne.Id).ToString(), font2, fontBrushB, p1.X, p1.Y);
                            }
                            else // Afficher l'indice
                            {
                                g.DrawString((personneID).ToString(), font2, fontBrushB, p1.X, p1.Y);
                            }

                        }
                    }
                }
            }
        }


        private void AfficheArbre()
        {
            string s1 = "", s2 = "";
            ReinitP1();
            AfficheMenu();
            AfficheArcs();
            for (int i = 0; i < NbLigne; i++) //NbLigne est déterminé en fonction du nombre de feuilles
            {
                p1.Y = (i * TailleCaseJ) + Ydeb;
                for (int j = 0; j < NbColonne; j++)
                {
                    if (arbre[i, j] != "") //case <> vide
                    {
                        p1.X = (j * TailleCaseI) + Xdeb;
                        if (arbre[i, j] != "0")
                        {
                            g.DrawString(lesPersonnes[int.Parse(arbre[i, j])].Nom + " " + lesPersonnes[int.Parse(arbre[i, j])].Prenom, font2, fontBrushB, p1.X, p1.Y);
                            g.DrawString("           ", font3, fontBrushR, p1.X, p1.Y + 20);
                            if ((s1.Trim().Length != 0) && (s2.Trim().Length != 0)) g.DrawString(s1 + " x " + s2, font3, fontBrushR, p1.X, p1.Y + 20);
                            else if ((s1.Trim().Length != 0) && (s2.Trim().Length == 0)) g.DrawString(s1, font3, fontBrushR, p1.X, p1.Y + 20);
                            else if ((s1.Trim().Length == 0) && (s2.Trim().Length != 0)) g.DrawString(" x " + s2, font3, fontBrushR, p1.X + 75, p1.Y + 20);
                        }
                    }
                }
            }
        }
        private int RechercheID(int id)
        {
            int i = 0;
            foreach (Personne unePersonne in lesPersonnes)
                if (unePersonne.Id != id) i++; else break;
            //while ((i < gb.TIndividus.Length) && (int.Parse(gb.TIndividus[i].ID) != int.Parse(id))) i++;
            return i;
        }
        private void ReinitP1() { p1 = new Point(0, Ydeb); p = new Point(0, 0); }

        private void InitGrille()
        {
            grille = new int[,] {{-1, -1, -1, -1, -1,  -1, -1, -1, -1, -1, -1, -1, -1 },
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //1
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //2
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //3
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //4
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //5
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //6
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //7
                                 {-1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //8
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //9
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //10
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //11
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //12
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //13
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //14
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //15
                                 {-1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //16
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //17
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //18
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //19
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //20                                 
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //21
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //22
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //23
                                 {-1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //24
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //25
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //26
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //27
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //28
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //29
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //30
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //31
                                 {0, -1, -1, -1, -1,  -1, -1, -1, -1, -1, -1, -1, -1 },  //32
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //1
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //2
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //3
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //4
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //5
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //6
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //7
                                 {-1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //8
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //9
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //10
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //11
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //12
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //13
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //14
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //15
                                 {-1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //16
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //17
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //18
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //19
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //20                                 
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //21
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //22
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //23
                                 {-1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //24
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //25
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //26
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //27
                                 {-1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1, -1 },   //28
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //29
                                 {-1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1, -1 },   //30
                                 {-1, -1, -1, -1, -1,  0, -1, -1, -1, -1, -1, -1, -1 },   //31
                                 {-1, -1, -1, -1, -1,  -1, -1, -1, -1, -1, -1, -1, -1 }};
        }

        private void InitArbre()
        {
            arbre = new string[,] { { "","", "", "", "",  "", "", "", "", "", "", "", ""},
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //1
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //2
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //3
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //4
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //5
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //6
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //7
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //8
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //9
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //10
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //11
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //12
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //13
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //14
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //15
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //16
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //17
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //18
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //19
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //20                                 
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //21
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //22
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //23
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //24
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //25
                                    {"", "", "", "", "",  "", "", "", "", "", "", "", ""},   //26
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //27
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //28
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //29
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //30
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},  //31
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},
                                     { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //1
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //2
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //3
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //4
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //5
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //6
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //7
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //8
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //9
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //10
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //11
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //12
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //13
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //14
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //15
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //16
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //17
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //18
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //19
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //20                                 
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //21
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //22
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //23
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //24
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //25
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //26
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //27
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //28
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //29
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},   //30
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""},  //31
                                    { "","", "", "", "",  "", "", "", "", "", "", "", ""}};  //32
        }

        private void AfficheArcs()
        {
            int x = 356, intervalle = 349, y = 0, intervalle_y = 80, step_y = 7;
            //parents * grands-parents (génération -1 à -2)
            g.DrawLine(pen, new Point(x, 320), new Point(x, 819));//307                  308,154,77,38

            //génération -2 à -3
            g.DrawLine(pen, new Point(x += intervalle, 192), new Point(x, 435));//147 154 401
            g.DrawLine(pen, new Point(x, 704), new Point(x, 947));//148

            //génération -3 à -4
            y = 128; intervalle_y = 0; step_y = 115;
            g.DrawLine(pen, new Point(x += intervalle, y), new Point(x, y + step_y));//67
            g.DrawLine(pen, new Point(x, 384), new Point(x, 384 + step_y));//68
            g.DrawLine(pen, new Point(x, 640), new Point(x, 640 + step_y));//67
            g.DrawLine(pen, new Point(x, 896), new Point(x, 896 + step_y));//68

            //génération -4 à -5
            y = 96; intervalle_y = 128; step_y = 51;
            g.DrawLine(pen, new Point(x += intervalle, y), new Point(x, y + step_y)); //27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//30
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//24
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26*/

            //génération -4 à -5
            y = 80; intervalle_y = 64; step_y = 19;
            g.DrawLine(pen, new Point(x += intervalle, y), new Point(x, y + step_y)); //27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//30
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//24
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26*/
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//30
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//24
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26*/
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//30
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//24
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26*/
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//28
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//30
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//27
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//24
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26
            g.DrawLine(pen, new Point(x, y += intervalle_y), new Point(x, y + step_y));//26*
        }


    }
}