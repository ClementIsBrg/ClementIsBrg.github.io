﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet___Généalogie
{
    public class Requête
    {

        /// <summary>
        /// Cette fonction retourne plusieurs lignes dans la variable curseur
        /// </summary>
        /// <param name="cnx"></param>
        /// <param name="sql"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public MySqlDataReader Exec_SQL_ExtractionDeDonnees(MySqlConnection cnx, string sql, string message)
        {//exemple avec req = select
            MySqlDataReader curseur = null;
            try
            {
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                cmd.CommandText = sql;
                curseur = cmd.ExecuteReader();
            }
            catch (Exception ex) { MessageBox.Show(message, ex.Message); }
            return curseur;
        }

        // <summary>
        /// Cette fonction retourne une seule ligne, une valeur, dans la variable nb
        /// </summary>
        /// <param name="cnx"></param>
        /// <param name="sql"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public int Exec_SQL_RetourneUneLigne(MySqlConnection cnx, string sql, string message)
        {//exemple avec req = select count
            int nb = -1;
            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                object t = cmd.ExecuteScalar();
                nb = int.Parse(cmd.ExecuteScalar().ToString());
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show(message, ex.Message); }
            return nb;
        }

        /// <summary>
        /// Fait appel à une procédure stockée, basée sur la table personne, écrite sous MySQL Workbench
        /// A utiliser avec les requêtes insert, upddate ou delete
        /// </summary>
        /// <param name="cnx"></param>
        /// <param name="procedure"></param>
        /// <param name="id"></param>
        /// <param name="nom"></param>
        /// <param name="prenom"></param>
        /// <param name="date_ns"></param>
        /// <param name="date_dc"></param>
        /// <param name="cat"></param>
        /// <param name="sous_cat"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public int Exec_SQL_MajDonneesPersonnes(MySqlConnection cnx, string req, int id, string nom, string prenom, int idpere, int idmere,int cat, string info, string message)
        {
            int i = -1;
            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = req;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("i", id);
                cmd.Parameters.AddWithValue("n", nom);
                cmd.Parameters.AddWithValue("p", prenom);              //PROCEDURE POUR LA TABLE PERSONNE
                cmd.Parameters.AddWithValue("idpere", idpere);
                cmd.Parameters.AddWithValue("idmere", idmere);
                cmd.Parameters.AddWithValue("idcat", cat);
                cmd.Parameters.AddWithValue("info", info);



                i = cmd.ExecuteNonQuery();
                cnx.Close();
            }
            catch (Exception ex) { cnx.Close(); MessageBox.Show(message, ex.Message); }
            return i;
        }

        public int Exec_SQL_MajDonneesActes(MySqlConnection cnx, string req,int id, DateTime dateActe, int idTypeActe, int IdVille, string message)
        {
            int i = -1;
            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = req;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("i", id);
                cmd.Parameters.AddWithValue("d", dateActe);
                cmd.Parameters.AddWithValue("ita", idTypeActe);              //PROCEDURE POUR LA TABLE ACTE
                cmd.Parameters.AddWithValue("iv", IdVille);
               
              



                i = cmd.ExecuteNonQuery();
                cnx.Close();
            }
            catch (Exception ex) { cnx.Close(); MessageBox.Show(message, ex.Message); }
            return i;
        }

        public int Exec_SQL_MajDonneesListe_Individu(MySqlConnection cnx, string req, int idPersonne, int idActe, int idTypeIndividu, string message)
        {
            int i = -1;
            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = req;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;;
                cmd.Parameters.AddWithValue("idp", idPersonne);
                cmd.Parameters.AddWithValue("ida", idActe);              //PROCEDURE POUR LA TABLE LISTEINDIVIDU
                cmd.Parameters.AddWithValue("iti", idTypeIndividu);





                i = cmd.ExecuteNonQuery();
                cnx.Close();
            }
            catch (Exception ex) { cnx.Close(); MessageBox.Show(message, ex.Message); }
            return i;
        }

        public int Exec_SQL_MajDonneesCategorie(MySqlConnection cnx, string req, int id, string nom, string message)
        {
            int i = -1;
            try
            {
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = req;
                cmd.CommandType = System.Data.CommandType.StoredProcedure; 
                cmd.Parameters.AddWithValue("icat", id);
                cmd.Parameters.AddWithValue("ncat", nom);

                i = cmd.ExecuteNonQuery();
                cnx.Close();
            }
            catch (Exception ex) { cnx.Close(); MessageBox.Show(message, ex.Message); }
            return i;
        }

        //requete ajout lieu
        public int Exec_SQL_MajDonneeslieu(MySqlConnection cnx, string req, int Idl, string Vn, string Vd_id, int Vp_id, string message)
        {
            int i = -1;
            try
            {
                cnx.Close();
                cnx.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = req;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("i", Idl);
                cmd.Parameters.AddWithValue("v", Vn);
                cmd.Parameters.AddWithValue("Did", Vd_id);              //PROCEDURE POUR LA TABLE lieu
                cmd.Parameters.AddWithValue("PiD", Vp_id);




                i = cmd.ExecuteNonQuery();
                cnx.Close();
            }

            catch (Exception ex) { cnx.Close(); MessageBox.Show(message, ex.Message); }

            return i;
        }

    }
}
