﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace GesEtu
{
    public partial class Accueil : Form
    {
        public Accueil() {InitializeComponent();}

        // définition de la chaine de connexion nécessaire pour accéder à la base SqlLite
        private static string chaineConnexion = "Data Source=localhost;Database=collectionInstruments; User Id=root; Password=root";
        
        // définition de l'objet connexion
        private static MySqlConnection cnx = new MySqlConnection(chaineConnexion);

        #region Controles fenêtre
        private void Accueil_Load(object sender, EventArgs e) { B_SelectPersonne_Click(sender, e); }

        private void LB_Etudiant_SelectedIndexChanged(object sender, EventArgs e)
        {
            const int LB_GETITEMDATA = 0x0199;
            int idliste = LB_Personne.SelectedIndex;
            int idtable = Program.SendMessage(LB_Personne.Handle, LB_GETITEMDATA, idliste, 0);
            try
            {
                cnx.Open();
                string sql = "SELECT * from INSTRUMENT WHERE id=" + idtable+";";
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                cmd.CommandText = sql;
                MySqlDataReader curseur = cmd.ExecuteReader();
                if (curseur.Read())
                {
                    // récupération des informations à partir de leur indice
                    TXT_Id.Text = ((int)curseur["id"]).ToString();
                    TXT_nm.Text = (string)curseur["nom"];
                    TXT_fam.Text = (string)curseur["famille"];
                    TXT_tpe.Text = (string)curseur["types"];
                    TXT_org.Text = (string)curseur["origin"];
                    TXT_cre.Text = (string)curseur["createur"];

                }
                curseur.Close();

               
                
                cnx.Close();
            }
            catch (Exception ex) { MessageBox.Show("Erreur LB_Etudiant_SelectedIndexChanged", ex.Message); }
        }
       
       
        private void B_Vide_Click(object sender, EventArgs e)
        {
            EffaceChamps();
            TXT_nm.Text = "NO_NAME";

        }
        #endregion


        #region Actions sur les tables : Les Requêtes

        private void B_Count_Click(object sender, EventArgs e)
        {
            cnx.Open();
            string sql = "SELECT count(*) from INSTRUMENT";
            MySqlCommand cmd = new MySqlCommand(sql, cnx);
            object t = cmd.ExecuteScalar();
            int nb = int.Parse(cmd.ExecuteScalar().ToString());
            MessageBox.Show("" + nb.ToString());
            cnx.Close();
        }
        private void B_SelectPersonne_Click(object sender, EventArgs e)
        {
            int idliste, idtable;
            const int LB_SETITEMDATA = 0x019A;
            LB_Personne.Items.Clear();

            try
            {
                cnx.Close();
                cnx.Open();
                // Envoi d'une requete SQL pour récupérer les Ecuries
                string sql = "SELECT * from INSTRUMENT ORDER BY id,nom;";
                MySqlCommand cmd = new MySqlCommand(sql, cnx);
                cmd.CommandText = sql;

                // Récupération des enregistrements 
                MySqlDataReader curseur = cmd.ExecuteReader();
                while (curseur.Read())
                {
                    // récupération des informations à partir de leur indice
                    int id = (int)curseur["id"];
                    string nom = (string)curseur["nom"];

                    idtable = id;
                    idliste = LB_Personne.Items.Add( " " + nom + " " );
                    Program.SendMessage(LB_Personne.Handle, LB_SETITEMDATA, idliste, idtable);
                }
                curseur.Close();
                cnx.Close();
            }
            catch(Exception ex) { MessageBox.Show("Erreur B_SelectPersonne_Click", ex.Message); }
        }
       
         
        
        

        private void B_Insert_Click(object sender, EventArgs e)
        {
            cnx.Close();
            cnx.Open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = cnx;
            cmd.CommandText = $@"INSERT into INSTRUMENT (nom,famille,types,origin,createur) VALUES  ('" + TXT_nm.Text + "','" + TXT_fam.Text + "','" + TXT_tpe.Text + "','" + TXT_org.Text + "','" + TXT_cre.Text + "');";
            cmd.ExecuteNonQuery();
            cnx.Close();
            RazControles();
            B_SelectPersonne_Click(sender, e);
            
       
        }
        private void B_Update_Click(object sender, EventArgs e)
        {
            cnx.Close();
            cnx.Open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = cnx;
            cmd.CommandText = $@"UPDATE INSTRUMENT set  nom = '" + TXT_nm.Text + "', famille ='" + TXT_fam.Text + "',types = '" + TXT_tpe.Text + "',origin = '" + TXT_org.Text + "',createur = '" + TXT_cre.Text + "'  where id = " + int.Parse(TXT_Id.Text) + ";";
            cmd.ExecuteNonQuery();
            cnx.Close();
            RazControles();
            B_SelectPersonne_Click(sender, e);
          
          

        }
        private void B_Delete_Click(object sender, EventArgs e)
        {
            cnx.Close();
            cnx.Open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = cnx;
            cmd.CommandText = $@"DELETE FROM INSTRUMENT WHERE id  = " + int.Parse(TXT_Id.Text) + "; ";
            cmd.ExecuteNonQuery();
            cnx.Close();
            RazControles();
            B_SelectPersonne_Click(sender, e);
           
          
        }
        #endregion

        #region Gestion des fonctions secondaires

        private void RazControles() {LB_Personne.Items.Clear(); EffaceChamps();}
        private void EffaceChamps()
        {
            TXT_Id.Clear();
            TXT_nm.Clear();
            TXT_fam.Clear();
            TXT_cre.Clear();
            TXT_org.Clear();
            TXT_tpe.Clear();




        }

        #endregion

        private void B_RazControles_Click(object sender, EventArgs e) {RazControles();}
    }
}