﻿namespace GesEtu
{
    partial class Accueil
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Personne = new System.Windows.Forms.ListBox();
            this.LBL_Id = new System.Windows.Forms.Label();
            this.TXT_Id = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.B_RazControles = new System.Windows.Forms.Button();
            this.B_SelectDepartement = new System.Windows.Forms.Button();
            this.B_SelectCommune = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.B_Vide = new System.Windows.Forms.Button();
            this.B_SelectPersonne = new System.Windows.Forms.Button();
            this.B_Delete = new System.Windows.Forms.Button();
            this.B_Update = new System.Windows.Forms.Button();
            this.B_Insert = new System.Windows.Forms.Button();
            this.B_Count = new System.Windows.Forms.Button();
            this.LBL_nm = new System.Windows.Forms.Label();
            this.TXT_nm = new System.Windows.Forms.TextBox();
            this.TXT_fam = new System.Windows.Forms.TextBox();
            this.TXT_tpe = new System.Windows.Forms.TextBox();
            this.TXT_org = new System.Windows.Forms.TextBox();
            this.TXT_cre = new System.Windows.Forms.TextBox();
            this.LBL_fam = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LB_Personne
            // 
            this.LB_Personne.BackColor = System.Drawing.Color.Moccasin;
            this.LB_Personne.FormattingEnabled = true;
            this.LB_Personne.Location = new System.Drawing.Point(310, 121);
            this.LB_Personne.Margin = new System.Windows.Forms.Padding(1);
            this.LB_Personne.Name = "LB_Personne";
            this.LB_Personne.Size = new System.Drawing.Size(208, 212);
            this.LB_Personne.TabIndex = 10;
            this.LB_Personne.SelectedIndexChanged += new System.EventHandler(this.LB_Etudiant_SelectedIndexChanged);
            // 
            // LBL_Id
            // 
            this.LBL_Id.AutoSize = true;
            this.LBL_Id.BackColor = System.Drawing.Color.Moccasin;
            this.LBL_Id.Location = new System.Drawing.Point(73, 121);
            this.LBL_Id.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.LBL_Id.Name = "LBL_Id";
            this.LBL_Id.Size = new System.Drawing.Size(16, 13);
            this.LBL_Id.TabIndex = 1;
            this.LBL_Id.Text = "Id";
            // 
            // TXT_Id
            // 
            this.TXT_Id.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_Id.Enabled = false;
            this.TXT_Id.Location = new System.Drawing.Point(114, 118);
            this.TXT_Id.Margin = new System.Windows.Forms.Padding(1);
            this.TXT_Id.Name = "TXT_Id";
            this.TXT_Id.Size = new System.Drawing.Size(183, 20);
            this.TXT_Id.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.groupBox1.Controls.Add(this.B_RazControles);
            this.groupBox1.Controls.Add(this.B_SelectDepartement);
            this.groupBox1.Controls.Add(this.B_SelectCommune);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.B_Vide);
            this.groupBox1.Controls.Add(this.B_SelectPersonne);
            this.groupBox1.Controls.Add(this.B_Delete);
            this.groupBox1.Controls.Add(this.B_Update);
            this.groupBox1.Controls.Add(this.B_Insert);
            this.groupBox1.Controls.Add(this.B_Count);
            this.groupBox1.Font = new System.Drawing.Font("Candara", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(564, 35);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox1.Size = new System.Drawing.Size(200, 394);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Requêtes table Personne Base Personnes";
            // 
            // B_RazControles
            // 
            this.B_RazControles.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_RazControles.Location = new System.Drawing.Point(39, 348);
            this.B_RazControles.Margin = new System.Windows.Forms.Padding(1);
            this.B_RazControles.Name = "B_RazControles";
            this.B_RazControles.Size = new System.Drawing.Size(130, 32);
            this.B_RazControles.TabIndex = 21;
            this.B_RazControles.Text = "RAZ Contrôles";
            this.B_RazControles.UseVisualStyleBackColor = true;
            this.B_RazControles.Click += new System.EventHandler(this.B_RazControles_Click);
            // 
            // B_SelectDepartement
            // 
            this.B_SelectDepartement.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_SelectDepartement.Location = new System.Drawing.Point(39, 297);
            this.B_SelectDepartement.Margin = new System.Windows.Forms.Padding(1);
            this.B_SelectDepartement.Name = "B_SelectDepartement";
            this.B_SelectDepartement.Size = new System.Drawing.Size(130, 32);
            this.B_SelectDepartement.TabIndex = 20;
            this.B_SelectDepartement.Text = "Charge table département";
            this.B_SelectDepartement.UseVisualStyleBackColor = true;
            // 
            // B_SelectCommune
            // 
            this.B_SelectCommune.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_SelectCommune.Location = new System.Drawing.Point(35, 253);
            this.B_SelectCommune.Margin = new System.Windows.Forms.Padding(1);
            this.B_SelectCommune.Name = "B_SelectCommune";
            this.B_SelectCommune.Size = new System.Drawing.Size(133, 32);
            this.B_SelectCommune.TabIndex = 19;
            this.B_SelectCommune.Text = "Charge table Commune";
            this.B_SelectCommune.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-144, 220);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Nom Commune Naissance";
            // 
            // B_Vide
            // 
            this.B_Vide.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Vide.Location = new System.Drawing.Point(32, 180);
            this.B_Vide.Margin = new System.Windows.Forms.Padding(1);
            this.B_Vide.Name = "B_Vide";
            this.B_Vide.Size = new System.Drawing.Size(136, 32);
            this.B_Vide.TabIndex = 17;
            this.B_Vide.Text = "Vide";
            this.B_Vide.UseVisualStyleBackColor = true;
            this.B_Vide.Click += new System.EventHandler(this.B_Vide_Click);
            // 
            // B_SelectPersonne
            // 
            this.B_SelectPersonne.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_SelectPersonne.Location = new System.Drawing.Point(32, 219);
            this.B_SelectPersonne.Margin = new System.Windows.Forms.Padding(1);
            this.B_SelectPersonne.Name = "B_SelectPersonne";
            this.B_SelectPersonne.Size = new System.Drawing.Size(136, 32);
            this.B_SelectPersonne.TabIndex = 18;
            this.B_SelectPersonne.Text = "Charge table Personne";
            this.B_SelectPersonne.UseVisualStyleBackColor = true;
            this.B_SelectPersonne.Click += new System.EventHandler(this.B_SelectPersonne_Click);
            // 
            // B_Delete
            // 
            this.B_Delete.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Delete.Location = new System.Drawing.Point(32, 138);
            this.B_Delete.Margin = new System.Windows.Forms.Padding(1);
            this.B_Delete.Name = "B_Delete";
            this.B_Delete.Size = new System.Drawing.Size(136, 32);
            this.B_Delete.TabIndex = 16;
            this.B_Delete.Text = "Delete";
            this.B_Delete.UseVisualStyleBackColor = true;
            this.B_Delete.Click += new System.EventHandler(this.B_Delete_Click);
            // 
            // B_Update
            // 
            this.B_Update.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Update.Location = new System.Drawing.Point(32, 103);
            this.B_Update.Margin = new System.Windows.Forms.Padding(1);
            this.B_Update.Name = "B_Update";
            this.B_Update.Size = new System.Drawing.Size(136, 32);
            this.B_Update.TabIndex = 15;
            this.B_Update.Text = "Update";
            this.B_Update.UseVisualStyleBackColor = true;
            this.B_Update.Click += new System.EventHandler(this.B_Update_Click);
            // 
            // B_Insert
            // 
            this.B_Insert.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Insert.Location = new System.Drawing.Point(32, 69);
            this.B_Insert.Margin = new System.Windows.Forms.Padding(1);
            this.B_Insert.Name = "B_Insert";
            this.B_Insert.Size = new System.Drawing.Size(136, 32);
            this.B_Insert.TabIndex = 14;
            this.B_Insert.Text = "Insert";
            this.B_Insert.UseVisualStyleBackColor = true;
            this.B_Insert.Click += new System.EventHandler(this.B_Insert_Click);
            // 
            // B_Count
            // 
            this.B_Count.Font = new System.Drawing.Font("Cambria", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Count.Location = new System.Drawing.Point(32, 34);
            this.B_Count.Margin = new System.Windows.Forms.Padding(1);
            this.B_Count.Name = "B_Count";
            this.B_Count.Size = new System.Drawing.Size(136, 32);
            this.B_Count.TabIndex = 13;
            this.B_Count.Text = "Count";
            this.B_Count.UseVisualStyleBackColor = true;
            this.B_Count.Click += new System.EventHandler(this.B_Count_Click);
            // 
            // LBL_nm
            // 
            this.LBL_nm.AutoSize = true;
            this.LBL_nm.BackColor = System.Drawing.Color.Moccasin;
            this.LBL_nm.Location = new System.Drawing.Point(73, 175);
            this.LBL_nm.Name = "LBL_nm";
            this.LBL_nm.Size = new System.Drawing.Size(27, 13);
            this.LBL_nm.TabIndex = 14;
            this.LBL_nm.Text = "nom";
            // 
            // TXT_nm
            // 
            this.TXT_nm.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_nm.Location = new System.Drawing.Point(114, 175);
            this.TXT_nm.Name = "TXT_nm";
            this.TXT_nm.Size = new System.Drawing.Size(183, 20);
            this.TXT_nm.TabIndex = 15;
            // 
            // TXT_fam
            // 
            this.TXT_fam.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_fam.Location = new System.Drawing.Point(114, 217);
            this.TXT_fam.Name = "TXT_fam";
            this.TXT_fam.Size = new System.Drawing.Size(183, 20);
            this.TXT_fam.TabIndex = 16;
            // 
            // TXT_tpe
            // 
            this.TXT_tpe.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_tpe.Location = new System.Drawing.Point(114, 263);
            this.TXT_tpe.Name = "TXT_tpe";
            this.TXT_tpe.Size = new System.Drawing.Size(183, 20);
            this.TXT_tpe.TabIndex = 17;
            // 
            // TXT_org
            // 
            this.TXT_org.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_org.Location = new System.Drawing.Point(114, 306);
            this.TXT_org.Name = "TXT_org";
            this.TXT_org.Size = new System.Drawing.Size(183, 20);
            this.TXT_org.TabIndex = 18;
            // 
            // TXT_cre
            // 
            this.TXT_cre.BackColor = System.Drawing.Color.Moccasin;
            this.TXT_cre.Location = new System.Drawing.Point(114, 344);
            this.TXT_cre.Name = "TXT_cre";
            this.TXT_cre.Size = new System.Drawing.Size(404, 20);
            this.TXT_cre.TabIndex = 19;
            // 
            // LBL_fam
            // 
            this.LBL_fam.AutoSize = true;
            this.LBL_fam.BackColor = System.Drawing.Color.Moccasin;
            this.LBL_fam.Location = new System.Drawing.Point(69, 217);
            this.LBL_fam.Name = "LBL_fam";
            this.LBL_fam.Size = new System.Drawing.Size(39, 13);
            this.LBL_fam.TabIndex = 20;
            this.LBL_fam.Text = "Famille";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Moccasin;
            this.label3.Location = new System.Drawing.Point(73, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "types";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Moccasin;
            this.label4.Location = new System.Drawing.Point(73, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "origin";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Moccasin;
            this.label5.Location = new System.Drawing.Point(65, 347);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "createur";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(821, 455);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 24;
            // 
            // Accueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::GesEtu.Properties.Resources.gfdhkd;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(854, 467);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LBL_fam);
            this.Controls.Add(this.TXT_cre);
            this.Controls.Add(this.TXT_org);
            this.Controls.Add(this.TXT_tpe);
            this.Controls.Add(this.TXT_fam);
            this.Controls.Add(this.TXT_nm);
            this.Controls.Add(this.LBL_nm);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TXT_Id);
            this.Controls.Add(this.LBL_Id);
            this.Controls.Add(this.LB_Personne);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "Accueil";
            this.Text = "Gestion des Personnes";
            this.Load += new System.EventHandler(this.Accueil_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LB_Personne;
        private System.Windows.Forms.Label LBL_Id;
        private System.Windows.Forms.TextBox TXT_Id;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button B_SelectPersonne;
        private System.Windows.Forms.Button B_Delete;
        private System.Windows.Forms.Button B_Update;
        private System.Windows.Forms.Button B_Insert;
        private System.Windows.Forms.Button B_Count;
        private System.Windows.Forms.Button B_Vide;
        private System.Windows.Forms.Button B_SelectCommune;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button B_SelectDepartement;
        private System.Windows.Forms.Button B_RazControles;
        private System.Windows.Forms.Label LBL_nm;
        private System.Windows.Forms.TextBox TXT_nm;
        private System.Windows.Forms.TextBox TXT_fam;
        private System.Windows.Forms.TextBox TXT_tpe;
        private System.Windows.Forms.TextBox TXT_org;
        private System.Windows.Forms.TextBox TXT_cre;
        private System.Windows.Forms.Label LBL_fam;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
    }
}

